# TCP-UDP-rproxy-ui

[![CI](https://github.com/max3584/TCP-UDP-rproxy-ui/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/max3584/TCP-UDP-rproxy-ui/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/max3584/TCP-UDP-rproxy-ui)](https://github.com/max3584/TCP-UDP-rproxy-ui/releases/latest)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![Node.js](https://img.shields.io/badge/node-%3E%3D22.23.4-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Renovate](https://img.shields.io/badge/renovate-enabled-brightgreen?logo=renovatebot)](https://github.com/max3584/TCP-UDP-rproxy-ui/issues?q=is%3Aissue+is%3Aopen+%22Dependency+Dashboard%22)

日本語: [README.md](README.md)

A web UI for managing the forwarding rules of [rproxy-api](https://github.com/max3584/rproxy-api) (Next.js, sign-in with Keycloak or tokens, rules stored in MariaDB).
Versions are numbered independently of rproxy-api (the release notes state the minimum rproxy-api version the UI needs; see [docs/en/RELEASING.md](docs/en/RELEASING.md)).

New here? Start with [docs/en/GUIDE.md](docs/en/GUIDE.md) (a path through installing, first setup, sign-in, daily use, operations and troubleshooting).

## Screenshots

![Dashboard (TCP / UDP counts and states, rules needing attention, the table of all rules)](docs/images/dashboard.en.png)

| Rule details (L7 routes, statistics) | Adding a rule (the L7 (HTTP) tab) |
|---|---|
| ![Rule details](docs/images/rule-detail.en.png) | ![Adding a rule](docs/images/rule-new.en.png) |
| **Change history** | **Phone width (375px) and the menu** |
| ![Change history](docs/images/history.en.png) | <img src="docs/images/mobile-dashboard.en.png" width="48%" alt="Dashboard at phone width"> <img src="docs/images/mobile-menu.en.png" width="48%" alt="The open menu"> |

The data is documentation sample data (192.0.2.0/24, 198.51.100.0/24, 2001:db8::/32, example.com). To retake them, run `npm run build && npm run screenshots` (`scripts/screenshots/`; the API is replaced with sample data, so MariaDB, rproxy-api and Keycloak are not needed).

## Installation (Debian / Ubuntu)

It can be installed from the same apt repository as rproxy-api (`rproxy-ui`, a single package for any CPU).
Node.js 22.23.4 or later is required (24.22.1 or later on 24, 26.12.1 or later on 26: the releases with the fix for the bundled Brotli flaw CVE-2026-111497; 23 and 25 get no fix). Next.js 16 needs 20.9, and undici 8, used for Unix sockets, needs 22.19.0. Older releases get a warning at startup. Debian 13's standard nodejs is 20 and Ubuntu 24.04's is 18, which is not enough, so first install nodejs from [NodeSource](https://github.com/nodesource/distributions) with a fixed major version (24 below). An apt pin keeps the distribution's nodejs from being chosen.

```shell
NODE_MAJOR=24
sudo install -d -m 0755 /etc/apt/keyrings
sudo curl -fsSLo /etc/apt/keyrings/nodesource.asc https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key
echo "deb [signed-by=/etc/apt/keyrings/nodesource.asc] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
  | sudo tee /etc/apt/sources.list.d/nodesource.list
printf 'Package: nodejs\nPin: origin deb.nodesource.com\nPin-Priority: 600\n' \
  | sudo tee /etc/apt/preferences.d/nodejs
sudo apt update && sudo apt install nodejs
node --version      # v24.x.x
apt policy nodejs   # the Candidate must come from deb.nodesource.com
```

- The steps are the same on Debian 13 and Ubuntu 24.04 (NodeSource's `nodistro` does not depend on the distribution). For 22, use `NODE_MAJOR=22` (22.23.4 or later)
- The same steps work on arm64 (rproxy-ui is one package for all CPUs, and on arm64 it runs with NodeSource's nodejs). On a Raspberry Pi, a 64-bit OS is recommended
- With the pin in `/etc/apt/preferences.d/nodejs` (priority 600), `apt install nodejs` replaces an already installed distribution nodejs with NodeSource's, and `apt upgrade` never goes back to the distribution's. NodeSource's nodejs includes npm (the distribution's `npm` package is not needed)
- `apt upgrade` only moves within the same major version. To change the major version, change `NODE_MAJOR`, rewrite `nodesource.list`, and run `sudo apt update && sudo apt install nodejs`

Then install rproxy-ui.

```shell
sudo curl -fsSLo /usr/share/keyrings/rproxy-archive-keyring.gpg https://max3584.github.io/rproxy-api/rproxy-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/rproxy-archive-keyring.gpg] https://max3584.github.io/rproxy-api stable main" \
  | sudo tee /etc/apt/sources.list.d/rproxy-api.list
sudo apt update && sudo apt install rproxy-ui
```

- The settings are in `/etc/rproxy-ui/rproxy-ui.env` (600). Fill in `NEXTAUTH_URL`, `KEYCLOAK_*` (without Keycloak, tokens: "Token sign-in (without Keycloak)" below) and `DB_*`, then start it with `sudo systemctl enable --now rproxy-ui` (installing alone does not start it)
- `NEXTAUTH_SECRET` is generated at install time. If rproxy-api is on the same host, its API URL and its token file (`RPROXY_API_TOKEN_FILE=/etc/rproxy/tokens`, when it holds one token per line) are filled in too
- The `rproxy-ui` user joins the group `rproxy` shared with rproxy-api (created at install time if missing; the unit has `SupplementaryGroups=rproxy`), so it reads rproxy-api's group-readable files (token file, certificates, the control API's Unix socket, owned by `rproxy-api:rproxy` or `root:rproxy`) in place instead of copying them. A token copied into `RPROXY_API_TOKEN` by an earlier version keeps being used
- It listens on `127.0.0.1:3000` by default (`HOSTNAME` / `PORT`). To expose it, put an rproxy static rule in front of it (TLS termination, routing by server name, `allow_from`; see "Static rules and exposing the dashboard" in the rproxy-api README)
- Create the DB tables with `/usr/share/rproxy-ui/db/schema.sql` (see [db/README.en.md](db/README.en.md)), or with `node /usr/share/rproxy-ui/db/migrate.mjs` ("migrate.mjs" in db/README.en.md)
- `server.js` in `/usr/lib/rproxy-ui` (the Next.js standalone output) runs as the `rproxy-ui` user. Logs are in `journalctl -u rproxy-ui`
- The UI and rproxy-api have independent version numbers (their release tags differ). The UI needs rproxy-api v0.3.5 or later. The UI version and each node's rproxy-api version are shown at the bottom of the sidebar (the menu on narrow screens) and in "Versions" on the dashboard. When rproxy-api is too old or its version is unknown (releases before v0.3.18 do not report it), the dashboard shows a notice (a newer minor than the UI knows is only reported for information). The versions are also logged for each node at startup

## Kubernetes

The container image `ghcr.io/max3584/rproxy-ui` and the Helm chart `oci://ghcr.io/max3584/charts/rproxy-ui` (an external DB or a bundled MariaDB, a migration Job, backups, read-only views of rproxy-gateway Gateways' rproxy). See [docs/en/KUBERNETES.md](docs/en/KUBERNETES.md).

## Development

First, run the development server:

```bash
npm ci        # install dependencies with npm (package-lock.json)
npm run dev
```

Required information:

+ NEXTAUTH settings
+ Database settings (`DB_PORT` defaults to 3306 when omitted)
+ Keycloak settings (a confidential client. Roles are read from the realm roles in the access token's `realm_access.roles`; see "Roles" below)
+ The URL and token of the rproxy-api control API (`RPROXY_API_TOKEN` is needed only when rproxy is started with `--token-file`)
  + If the rproxy tokens have permissions (YAML), make the UI's token `admin` (a token in the one-per-line format is already `admin`). From rproxy-api v0.4.23 (rproxy-api #401), a token without `admin` may only change the rules, overlays and rule sets it created (others get `403 not_owner`), and the UI's "API rules" screen and resending on several nodes change rules other tokens created with the UI's token. A setup that uses neither and only changes the rules the UI restored may use `rules:read` (list and details), `rules:write` (add, change and delete) and `allow_restored: true` instead (global settings need `admin`. Add `allow_restored` only on rproxy-api v0.4.23 or later, and remove it before going back: v0.4.22 and earlier do not read the token file at all when it has an unknown field, so every token stops working). `metrics:read` is not used (`GET /capabilities` can be read with any token).
    With `allow_listen_ports`, rules whose listen ports are outside that range cannot be created, changed or deleted from the UI.
    If a scope is missing, the screen shows "The rproxy token used by the UI does not have permission for this operation" (it is also logged by the UI).
    Creating or changing rules with ACME certificates from the UI also needs `acme:write` (see "Obtaining certificates with ACME" below).

Environment:
```.env.local
NEXTAUTH_URL="http://[hostname]:[port]"
NEXTAUTH_SECRET="secret"

# database data
DB_HOST="[hostname]"
DB_PORT=3307
DB_DATABASE="[database]"
DB_USER="[username]"
DB_PASSWORD="[password]"
# TLS to the DB ("TLS to the DB" in the README). Writing DB_SSL_CA turns TLS on without DB_SSL
# DB_SSL=true
# DB_SSL_CA="/etc/rproxy-ui/db-ca.pem"

# Keycloak
KEYCLOAK_CLIENT_ID="[client_id]"
KEYCLOAK_CLIENT_SECRET="[client_secret]"
KEYCLOAK_ISSUER="https://[keycloak-host]/realms/[realm]"
# signing in with tokens instead of (or as well as) Keycloak (README, "Token sign-in (without Keycloak)")
# RPROXY_UI_AUTH="token"                 # keycloak (default), token or both
# RPROXY_UI_TOKENS_FILE="/home/me/rproxy-ui-tokens.yaml"   # made with npm run token:new -- --name me --role admin --file ...

# rproxy
RPROXY_API_URL="http://127.0.0.1:8080"
RPROXY_API_TOKEN="[token]"
# read the token from a file (RPROXY_API_TOKEN wins; the first non-empty line not starting with #; a changed file is used from the next request)
# RPROXY_API_TOKEN_FILE="/etc/rproxy/tokens"
# connect to an https:// control API with a client certificate (mTLS; rproxy-api v0.4 --tls-client-auth). The CA verifies rproxy's certificate (default: the OS CAs)
# RPROXY_API_TLS_CERT="/etc/rproxy-ui/tls/client.pem"
# RPROXY_API_TLS_KEY="/etc/rproxy-ui/tls/client.key"
# RPROXY_API_TLS_CA="/etc/rproxy-ui/tls/rproxy-ca.pem"
# usage accounting (see "Usage"; needs db/migrations/010_usage.sql and 011_usage_attr.sql): interval (seconds, 0 turns it off) and days to keep
# RPROXY_UI_USAGE_SECS=300
# RPROXY_UI_USAGE_HOURLY_DAYS=32
# RPROXY_UI_USAGE_DAILY_DAYS=400
# several rproxy instances (see "Several rproxy instances (nodes and groups)"). When set, RPROXY_API_URL / RPROXY_API_TOKEN are not used
# RPROXY_UI_NODES="/etc/rproxy-ui/nodes.yaml"
# sessions (see "Security"): length from sign-in (seconds, default 8 hours) and how often roles are checked again with Keycloak (seconds, 0 turns it off)
# RPROXY_UI_SESSION_MAX_AGE=28800
# RPROXY_UI_ROLE_REFRESH_SECS=300
```

`RPROXY_API_URL` is an `http://` / `https://` URL, or `unix:/run/rproxy/api.sock` (the Unix socket of rproxy-api's `RPROXY_API_SOCKET`; the HTTP Host is `localhost`).
By default rproxy-api creates the Unix socket with mode 660, so add the user that runs the UI to the `RPROXY_API_SOCKET_GROUP` group (the token is still required, as with TCP).

The Keycloak realm can be created from `keycloak/realm-rproxy-dev.json` (load it in the admin console with "Create realm" → "Resource file").
The file contains no client secret and no users, so after loading it, check the secret under "Credentials" of the client `rproxy-ui` and set it as `KEYCLOAK_CLIENT_SECRET`. The URLs are for the con0 development environment (`http://con0.dev.home:3001`).
The file is for development (no password policy or OTP, http URIs). To base production on it, change it as in "3. Keycloak" of [docs/en/PRODUCTION.md](docs/en/PRODUCTION.md).

Register `${NEXTAUTH_URL}/api/auth/callback/keycloak` in "Valid redirect URIs" of the Keycloak client.

## Token sign-in (without Keycloak)

To run without Keycloak, with only the UI, MariaDB and rproxy (the minimal setup), users sign in with access tokens an administrator issues (NextAuth's Credentials; #179).

| `RPROXY_UI_AUTH` | Sign-in |
|---|---|
| `keycloak` (default) | Keycloak only, as before (without `RPROXY_UI_AUTH`, no `KEYCLOAK_ISSUER` and a `RPROXY_UI_TOKENS_FILE` mean `token`) |
| `token` | Tokens only. No `KEYCLOAK_*` needed |
| `both` | The sign-in page (`/signin`) has a token field and a "Sign in with Keycloak" button |

The token file (`RPROXY_UI_TOKENS_FILE`, YAML) holds only the tokens' SHA-256 (never the plain tokens).

```yaml
tokens:
  - name: admin            # up to 64 letters, digits, . _ - starting with a letter or digit (unique)
    sha256: 9f86d0...      # the token's SHA-256 (64 hex digits). Make tokens with rproxy-ui-token (below)
    role: admin            # admin (RPROXY_UI_ADMIN_ROLE) or user (RPROXY_UI_USER_ROLE)
  - name: alice
    sha256: 2c26b4...
    role: user
    sub: 0b6f2c1e-...      # optional: the owner of the rules and the history's auth_id (default token:<name>); a Keycloak sub makes them that person's rules
```

- Make tokens with `rproxy-ui-token` (`rproxy-ui-token` with the .deb, `npm run token -- ...` in the repository, `node rproxy-ui-token.mjs` in the image). The token is shown once; the file gets only its sha256 (created 0600 when missing; replaced by a rename).
  ```shell
  sudo rproxy-ui-token new --name admin --role admin --file /etc/rproxy-ui/tokens.yaml --owner rproxy-ui
  sudo rproxy-ui-token list --file /etc/rproxy-ui/tokens.yaml
  sudo rproxy-ui-token remove --name admin --file /etc/rproxy-ui/tokens.yaml
  rproxy-ui-token new --name admin --role admin --stdout    # writes no file: prints the token and its tokens: row (Kubernetes Secret)
  ```
- The file is the UI user's, with no group or other access (600, 400). A root-owned file, like a Kubernetes Secret volume (root's, group fsGroup, 440), may be group-readable. A file with another owner or mode is not read and the UI does not start (if that happens while it runs, it keeps running and lets no token in). The same goes for mistakes in it (unknown keys, a plain `token:`, a repeated name or sha256, ...).
- The file is read again when it changes (no restart). Token sessions look at it on every check (whatever `RPROXY_UI_ROLE_REFRESH_SECS` is): when the row is removed, its sha256 changes (a replaced token), or its `role` or `sub` changes, the session ends at the next check (pages go to the sign-in, the API answers 401).
- `role: user` gets the `RPROXY_UI_USER_ROLE` role. With `RPROXY_UI_USER_ROLE` empty (the default) there are no users, so `role: user` tokens cannot use the UI (403 `no_role`; a warning at start). The limits for users (`RPROXY_UI_USER_*`) apply as for Keycloak users (`RPROXY_UI_USER_CERTS_BY_SUB` uses the token's sub).
- Sessions last `RPROXY_UI_SESSION_MAX_AGE`, as with Keycloak (from the sign-in; using the UI does not extend them), with the same cookie (httpOnly, SameSite=Lax, Secure when `NEXTAUTH_URL` is https://). The token itself is in no cookie and no log (the session keeps the row's name and a mark derived from its sha256).
- The token's sha256 is compared with every row in constant time. More than 5 wrong tokens from one source in 15 minutes make that source's wrong tokens get 429 (`Retry-After`) for 15 minutes (`RPROXY_UI_TOKEN_LOCKOUT_ATTEMPTS`, `RPROXY_UI_TOKEN_LOCKOUT_SECS`; default 5 and 900 seconds). A right token is accepted even while the source is locked out (so someone sending wrong tokens cannot lock out other users who share the source). A success does not reset the count. IPv6 counts per /64, and each UI process counts on its own. Behind an HTTP proxy (nginx, an Ingress, a Gateway), list its addresses as narrowly as possible in `RPROXY_UI_TRUSTED_PROXIES` (comma-separated CIDRs): X-Forwarded-For is read from the right and the first address that is not a trusted proxy is the source (a wide range lets clients in it pick their source with a forged X-Forwarded-For). Without it everyone counts as the proxy's one source, and a request with X-Forwarded-For logs a warning once. rproxy in front (L4) adds no X-Forwarded-For and needs nothing.
- The lockout only marks and logs sources of wrong tokens (429). As it still accepts a right token, it does not limit or slow guessing: the protection is the token's entropy alone. Always make tokens with `rproxy-ui-token` (256 random bits). If you make them yourself, use at least 128 random bits (e.g. `openssl rand -base64 32`), never a password or a memorable string (its strength cannot be checked from the sha256 in the file).
- The sign-in request (`POST /api/auth/callback/token`) needs NextAuth's CSRF token, and one from another site is refused with 403 (the `Sec-Fetch-Site` / `Origin` check of the API). The sign-in page works under the CSP (nonce).
- Signing out only removes the UI's session (nothing is sent to Keycloak).

## Roles (permissions)

Keycloak roles (`role` for tokens) decide who can do what (the API routes check on every request).

| Role | What it can do |
|---|---|
| `rproxy-admin` | List, view, change and delete the rules of all users (the list and details show the owner (Keycloak ID)). Can use any listen port |
| `rproxy-user` | Create, list, change and delete only their own rules (with limits on file paths and destinations; see "Limits for users" below). Only when a user role is set with `RPROXY_UI_USER_ROLE` |
| Neither | Neither the screens nor the API can be used (403; "You do not have permission" is shown). With `RPROXY_UI_USER_ROLE` empty (the default), everyone without `rproxy-admin` is here |

- Roles are read from the access token's `realm_access.roles` (realm roles). To use client roles, change the claim location (dot-separated), e.g. `RPROXY_UI_ROLES_CLAIM=resource_access.rproxy-ui.roles`.
- The role names are set by `RPROXY_UI_ADMIN_ROLE` (default `rproxy-admin`) and `RPROXY_UI_USER_ROLE` (empty by default). To let users in, set `RPROXY_UI_USER_ROLE=rproxy-user` and assign that role.
- **The default changed in v0.4.9**: with `RPROXY_UI_USER_ROLE` empty (the default), people without `rproxy-admin` cannot use it (403 `no_role`). Up to v0.4.8, empty meant anyone who could sign in was treated as `rproxy-user`. If you let users in without roles, set `RPROXY_UI_USER_ROLE=rproxy-user` and assign that role before upgrading.
- Writing e.g. `RPROXY_UI_USER_PORTS=1024-65535` restricts the listen ports `rproxy-user` can use (outside the range: 403 `port_not_allowed`; `rproxy-admin` is not restricted). There is no restriction by default.
- With several rproxy instances, `RPROXY_UI_USER_NODES=node1,node2` limits the nodes `rproxy-user` can change (see "Several rproxy instances (nodes and groups)" below).
- Roles are read at sign-in and checked again with Keycloak every `RPROXY_UI_ROLE_REFRESH_SECS` (default 300 seconds; see "Security" below). A role removed in Keycloak takes effect after that interval at the latest.

### Limits for users (file paths and destinations)

For the rules of `rproxy-user` (people without `rproxy-admin`), the API routes check the following (the form only makes the file fields read-only and shows notes). `rproxy-admin` is not limited, as before.

- **Fields naming server files cannot be written** (403 `file_not_allowed`): `cert_file`, `chain_file` and `key_file` of `tls.certificates[]`, `ca_file` and `chain_file` of `tls.client_auth`, `ca_file`, `cert_file`, `chain_file` and `key_file` of `tls.upstream` and `tls.routes[].upstream`, the files of an L7 service's `tls`, `users_file` of `basic_auth`, `client_secret_file`, `cookie_secret_file` and `ca_file` of `oidc`: every `*_file` field (also in middlewares written as JSON). rproxy can use any key it can read, so a user terminating TLS on another port with the dashboard's key could steal an administrator's cookie.
- **TLS certificates are picked by stored name**: certificates administrators stored with rproxy-api v0.4.2's certificate API (`PUT /certs/{name}`, `features.cert_store`) are used as `{"cert": "<name>"}` in `tls.certificates[]`. "+ Add a stored certificate" in the form offers the names from `/api/forward/certs` (rproxy's `GET /certs`; the UI token needs `certs:read`; names, SANs and expiry only). Name prefixes such as `RPROXY_UI_USER_CERTS=tenant-,shared-` limit the names users can pick (others: 403 `cert_not_allowed`; empty (the default) means every name). The prefixes are compared as plain string prefixes without looking for a separator, so they must end with `-`, `.` or `_` (`tenant-a` would also match `tenant-ab-www`; other endings stop the UI at startup; the same holds for the prefixes of `RPROXY_UI_USER_CERTS_BY_*`). If the dashboard's certificate is in the certificate API, always leave it out this way. The node asked with `?target=` must also be inside `RPROXY_UI_USER_NODES`.
  - **Assignments per user or role** (#160): `RPROXY_UI_USER_CERTS` is shared by all users, so a tenant-a user could pick `tenant-b-www` and terminate TLS with it on their own port on the same IP (cookies are not separated by port). To separate tenants, assign prefixes with `RPROXY_UI_USER_CERTS_BY_ROLE=tenant-a:tenant-a-,tenant-b:tenant-b-` (Keycloak role:prefix) or `RPROXY_UI_USER_CERTS_BY_SUB=<sub>:alice-` (Keycloak `sub`:prefix). Separate entries with commas; repeat a role or `sub` to add prefixes (a role name may contain `:`; the prefix is after the last `:`).
  - Users with an assignment can pick only the prefixes assigned to their `sub` and roles together; `RPROXY_UI_USER_CERTS` does not apply to them. When either assignment is set, users without one can pick nothing (they do not fall back to `RPROXY_UI_USER_CERTS`). The shared `RPROXY_UI_USER_CERTS` applies only when neither assignment is set (the default; unchanged).
  - The assignment is checked for the `/api/forward/certs` list and on every path that takes certificate names (add, modify, plan, import, revert, copy, move, per-node overrides). Names already on the user's own rule can stay as long as they are unchanged.
- **OIDC middlewares cannot be added or changed** (403 `middleware_not_allowed`): rproxy also connects to the `token_endpoint` and `jwks_uri` the `issuer`'s discovery returns, which the UI cannot check. The same setting already there can stay (secret files cannot be written either, so users could not create one anyway).
- **Response caches (cache) stay within limits and cannot share** (#175): rproxy's memory is shared by all users, so a user's cache may have `max_memory` up to `RPROXY_UI_USER_CACHE_MAX_MEMORY` (bytes; KiB, MiB and GiB may be written, as in `16MiB`; 16 MiB by default) and `max_entries` up to `RPROXY_UI_USER_CACHE_MAX_ENTRIES` (1024 by default); over them is 403 `cache_limit`. The limits are per cache middleware, not a total per user. Left out, they are compared as rproxy's defaults (`max_memory` 64 MiB, `max_entries` 1024), so with the default limit `max_memory` must be written (a cache newly added in a user's form starts with the limits filled in). `share_after_auth` and `share_credentials` cannot be used, as they could share each user's answers after authentication administrators set up (403 `middleware_not_allowed`). A setting already there can stay only under the same name with the same values; a sharing one also only while the routes using it (name, match, the destination `service` or `to`, and the middlewares in front of the cache with their settings) do not grow, so it cannot be copied or moved to another route, name or rule. Changing the servers of the approved service itself is allowed (administrators approved sharing on that service).
- **Destinations** (`remote_addr`, `targets`, the target health check (`health_check.port`), the destinations of `tls.routes[]`, the `url` of L7 services, a route's `to`, `address` of `forward_auth`, `issuer` of `oidc`, and the destinations of per-node overrides) (403 `target_not_allowed`):
  - URLs are read strictly (for everyone): the host is a name, IPv4 or `[IPv6]` (no zone ID), the port only digits from 1 to 65535, no userinfo (`@`). Unreadable URLs get 400 `invalid` before saving; an unreadable URL already stored is 403 for users.
  - With CIDRs, IP addresses and host names such as `RPROXY_UI_USER_TARGETS=10.0.0.0/8,2001:db8::/32,backend.example.com,*.svc.example.com` (`*.example.com` is every name below it), only those. A name can be used when it matches, or when every address it resolves to is inside the CIDRs. By default (empty) there is no allow-list (only the destinations below are refused). Setting it is recommended in production.
  - Refused by default: loopback (`127.0.0.0/8`, `::1`), link-local (`169.254.0.0/16`, including the cloud metadata `169.254.169.254`, and `fe80::/10`), unspecified (`0.0.0.0/8`, `::`), multicast, broadcast and `fd00:ec2::254`. A CIDR inside such a range in the allow-list (e.g. `127.0.0.1/32`) makes it usable (a broad one such as `0.0.0.0/0` does not).
  - Always refused (even when allowed): the addresses and ports of rproxy's control API (the URLs of `RPROXY_API_URL` and `RPROXY_UI_NODES`, and the reserved addresses in each rproxy's `GET /interfaces`), this UI (`PORT` and `HOSTNAME`, `NEXTAUTH_URL`) and the database (what `DB_HOST` resolves to, and `DB_PORT`). For something listening on loopback, the other addresses of that host are refused too.
  - Write anything else to protect (a DB on another host, replicas, management services) as CIDRs or CIDR:port, e.g. `RPROXY_UI_PROTECTED_TARGETS=10.0.0.5:3306,10.96.0.0/12,[fd00::/8]:5432` (refused even when allowed). On Kubernetes the IPs of Pods such as the DB change when they are replaced, so write the Pod and Service CIDRs, or limit traffic from rproxy with a NetworkPolicy (with `DB_HOST` a Service name, only the Service IP is refused, not connecting to the Pod IP directly).
  - Host names are resolved on the UI's host and every address they resolve to is checked (names that do not resolve are refused). This cannot stop the name pointing elsewhere when rproxy resolves it again later (DNS rebinding), so put only names administrators own in the allow-list.
  - Destinations of per-node overrides are compared as a separate place from the rule's (moving a value between the rule and an override is checked as new).
- **Values already there can stay**: when changing an own rule, file paths, certificate names and destinations already on the current rule can be saved again unchanged (compared as pairs of field location and value; reordering arrays or renaming services and middlewares keeps the same values). Only new or changed values are refused. Replacing on import and reverting compare with the current rule; new rules (add, import of a new rule, copy or move to another node) have no previous values, so everything is checked. Users' rules from before the upgrade keep running, so administrators should review the file paths and destinations of users' rules.
- **Paths of rules users do not own are hidden**: when static rules (rules of rproxy's settings file) are shown to users (dashboard, details), the `*_file` values, the files of certificate expiry and those paths in error texts become `<hidden>`.
- State-changing APIs (`POST /api/forward/*`) refuse requests from other sites with 403 `csrf` (when `Sec-Fetch-Site` is not same-origin, or the host of `Origin` (else `Referer`) matches none of the request's `Host`, `X-Forwarded-Host` and `NEXTAUTH_URL`), as CSRF protection on top of the SameSite=Lax cookie. A reverse proxy in front should pass `Host` or `X-Forwarded-Host`, or set `NEXTAUTH_URL` to the URL users open.
  - Requests with neither `Sec-Fetch-Site` nor `Origin` / `Referer` also get 403 `csrf` (from v0.4.10; current browsers always send one of them with a POST from the page). A script that calls the API with a sign-in cookie (not a documented use) should send `Origin: <the origin of NEXTAUTH_URL>`. The keepalived endpoints (`/api/forward/ha/*`, a bearer token) do not go through this check and keep working. A reverse proxy in front must not drop `Origin`, `Referer` or `Sec-Fetch-*`.
- The `auth_id` in the history (`forward_rules_log`) is the user who performed the operation (the administrator, if an administrator changed someone else's rule).

## Security

### Response headers

The UI adds these headers to every response (pages, API and static files; `proxy.ts`, `components/securityheaders.ts`). It sends no `X-Powered-By`.

| Header | Value |
|---|---|
| `Content-Security-Policy` | `default-src 'self'; script-src 'self' 'nonce-<per request>' 'strict-dynamic'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self' <origin of KEYCLOAK_ISSUER>; frame-ancestors 'none'` |
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `camera=(), microphone=(), geolocation=(), payment=(), usb=()` |
| `Cross-Origin-Opener-Policy` | `same-origin` |
| `Cross-Origin-Resource-Policy` | `same-origin` |
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains` (only when `NEXTAUTH_URL` is `https://`) |

- Only scripts carrying the per-request nonce run (the production HTML of Next.js 16 has inline `<script>`s, so `'self'` alone is not possible). `'unsafe-inline'` in `style-src` is for `style` attributes in the screens.
- The Keycloak origin in `form-action` comes from `KEYCLOAK_ISSUER` (the sign-in form moves on to Keycloak).
- Under `next dev` (development), `'unsafe-eval'` is added to `script-src` and `ws:`/`wss:` to `connect-src`.
- rproxy in front works at L4 (TCP and TLS termination) and cannot add HTTP headers. The UI adds them itself, so nothing needs to add headers in front (if you put an HTTP reverse proxy in front, do not add the same headers twice).

### TLS to the DB

When the DB is on another host, use TLS between the UI and the DB (`components/dbtls.ts`; `db/migrate.mjs` reads the same variables).

| Variable | Meaning |
|---|---|
| `DB_SSL` | `true` uses TLS and checks the DB's certificate (without `DB_SSL_CA`, Node.js's bundled public CAs (the Mozilla list) plus `NODE_EXTRA_CA_CERTS`; the OS CA store is not used; the name is compared with `DB_HOST`). Default `false` |
| `DB_SSL_CA` | File with the CA (PEM) that checks the DB's certificate. Writing it turns TLS on without `DB_SSL` (the `rproxy-ui` user must be able to read it) |
| `DB_SSL_VERIFY` | `false` skips the certificate check (testing only; not recommended) |

- Wrong values and an unreadable CA stop the UI at startup (the reason is in `journalctl -u rproxy-ui`).
- On the MariaDB side, enforce TLS with `require_secure_transport=ON` or `ALTER USER 'rproxy_ui'@'%' REQUIRE SSL` for the UI's user.
- A MariaDB on the same host (`DB_HOST=127.0.0.1`) does not need TLS.

### Sessions

- A sign-in lasts `RPROXY_UI_SESSION_MAX_AGE` (seconds, default 28800 = 8 hours), counted from when Keycloak actually authenticated the user (the ID token's `auth_time`); using the UI does not extend it. After that, users sign in again.
  - The authorization request carries `max_age=<RPROXY_UI_SESSION_MAX_AGE>`, so even with a live Keycloak SSO session, Keycloak asks for authentication again when it is older than that (a silent SSO sign-in does not extend the 8 hours).
  - Set the realm's "SSO Session Max" in Keycloak to at most `RPROXY_UI_SESSION_MAX_AGE` (`keycloak/realm-rproxy-dev.json` uses 8 hours).
- Every `RPROXY_UI_ROLE_REFRESH_SECS` (seconds, default 300; `0` turns it off, and then a role removed or a user disabled in Keycloak does not reach the UI until the session ends, up to `RPROXY_UI_SESSION_MAX_AGE`) the UI asks Keycloak's token endpoint again with the refresh token received at sign-in and replaces the roles with those of the new access token.
  - When Keycloak refuses (the user was disabled, the SSO session ended, the session was removed in the admin console), the UI session becomes invalid at once (the screens go to sign-in, the API answers 401).
  - Only `invalid_grant` and 400, 401 and 403 count as a refusal. When Keycloak is unreachable or answers 408, 429, 5xx or 404 (a wrong `KEYCLOAK_ISSUER`; logged), the current roles stay and the UI asks again every minute. Three intervals (15 minutes by default) after the last successful check, the session becomes invalid.
  - Idle for longer than Keycloak's "SSO Session Idle" (30 minutes by default), the refresh token expires and users sign in again the next time they open the UI.
- Signing out also sends the refresh token to Keycloak's end_session endpoint (`/protocol/openid-connect/logout`), ending the Keycloak SSO session too. If that fails (e.g. Keycloak is unreachable), the UI sign-out still completes but the Keycloak SSO session remains (the UI logs `Keycloak の SSO のセッションを終わらせられませんでした`; remove the session in the Keycloak admin console if needed).
- Sessions from before this version (without the time of sign-in) are not accepted; sign in once again after the update.

## L7 (HTTP) rules

With rproxy-api v0.3.1 or later (`features.http` in `GET /capabilities` is true), choosing "Route by L7 (HTTP)" in the "Basic" tab of a TCP rule
lets you edit, in the "L7 (HTTP)" tab, the routes (`match` expressions as in Traefik; common conditions can be assembled by selection), services (targets and weights), middlewares (redirect, rate limit, CrowdSec, etc.; only the kinds rproxy supports) and the response when nothing matches.
The profiles "HTTPS reverse proxy (L7)" and "HTTP→HTTPS redirect (port 80, L7)" serve as templates. Switching between L4 and L7 is only possible at creation (rproxy cannot switch it with PATCH).
"Block sources banned by CrowdSec (L4)" in the "Advanced" tab can be used when the rproxy settings file has `global.crowdsec` (rproxy-api v0.3.2 or later).

For building a production environment (apt, DB users and privileges, Keycloak, publishing over HTTPS, updates and backups), see [docs/en/PRODUCTION.md](docs/en/PRODUCTION.md).

Table definitions and migrations are in `db/` (see [db/README.en.md](db/README.en.md)). On existing environments, apply `db/migrations/005_ranges_and_tls.sql` (columns for port ranges and TLS).
The HTTP API contract with rproxy-api is `../rproxy-api/docs/API.md`.

## Gateway API L7 and TLS fields

The rproxy-api fields for the Gateway API (rproxy-api #237; editable only when `features` of `GET /capabilities` reports them) can be created and edited in the form too.
With an rproxy that cannot use them, the fields are hidden, and values a rule already has are kept with a read-only note and sent as they are. The L7 view on the rule details shows them as well.

| Field | Where | features |
|---|---|---|
| Route time limits (whole request, one attempt to a backend) | Routes in the L7 tab | `route_timeouts` in `http_options` |
| Replace the Host, CORS, mirror (percentage or fraction) | Middleware kinds (`replace_host`, `cors`, `mirror`) | `middlewares` |
| Copies a mirror sends at once (`max_in_flight` of `mirror`, 1-10000, default 64; rproxy-api v0.4.20) | "Copies in flight at once" of `mirror` (kept read-only and sent as is with an rproxy that lacks it) | `http_stream_limits` |
| Append headers (`add` in `request` / `response` of `headers`) | JSON of `headers` | `headers_add` in `http_options` |
| Redirect status code (301, 302, 303, 307, 308) | `redirect_scheme`, `redirect_regex` | `redirect_status` in `http_options` |
| Retry on status codes (`500`, `502-504`) | `retry` | `retry_status` in `http_options` |
| Middlewares per backend (only `headers`, `replace_host` and path rewrites) | Backend rows of a service | `server_middlewares` in `http_options` |
| Backends answering with a fixed status code (for their share by weight) | Backend kind "Answer with a status code" | `server_status` in `http_options` |
| HTTP version towards the backends (`http1`, `h2`, `h2c`, `auto`; h2 or h2c for gRPC) | Service | `protocol` in `services` |
| Backend TLS per service (server name, CA, SAN, client certificate, no verification) | Service | `tls` in `services` |
| Several destinations and balancing per server name | "Several destinations" of the per-name backends in the TLS tab | `tls_route_targets` |
| TLS to the backend per server name (`tls.routes[].upstream`; BackendTLSPolicy; rproxy-api v0.4.7) | "TLS to the backend" on each row of the per-name backends in the TLS tab | `tls_route_upstream` |

TLS to the backend per server name can be set only on names rproxy terminates (not marked "Do not terminate") in TCP terminate rules, and those names use it instead of the rule's "Re-encrypt to the backend with TLS" (the fields are not mixed). Choose "Same as the rule" (left out), "Plain text for these names" (`{}`; plain text for these names even when the rule re-encrypts) or "Re-encrypt with settings for these names" (server name to verify, CA, no verification, client certificate with its intermediate CAs and private key; the same fields as the rule's). It is shown on the per-name backends of the details page too. Values set by rproxy-gateway are not lost on save.

Before saving, the form checks the same rules as rproxy (a URL or a status code, `h2` with https:// backends and `h2c` with http:// backends, the kinds of per-backend middlewares, the mirror's service, CORS origins, combinations of the service TLS, which names may have TLS to the backend and how its client certificate, private key and intermediate CAs go together, and so on).

## Response cache (cache)

The rproxy-api `cache` middleware (rproxy-api #340; only when `features.middlewares` of `GET /capabilities` has `cache`) can be created and edited as the middleware kind "Response cache" in the L7 tab.
It keeps GET responses in memory and answers from there without asking the backend for the time to keep (`ttl`, 100ms to 24h, required). It is meant to cut requests to the backend when many clients fetch the same JSON every few seconds.

| Field | Setting | Default |
|---|---|---|
| Time to keep | `ttl` | (required) |
| Time to serve an expired answer when the backend fails | `stale_on_error` | `0s` |
| Largest body kept (bytes, up to 64 MiB) | `max_body` | 1 MiB |
| Most answers kept | `max_entries` | 1024 |
| Memory limit (bytes) | `max_memory` | 64 MiB |
| Request headers in the key | `vary` | none |
| Statuses kept (200, 203, 204, 300, 301, 308, 404, 410) | `status` | `[200]` |
| Share answers for requests with Cookie or Authorization too | `share_credentials` | false |
| Share answers after sign-in too | `share_after_auth` | false |
| Response header with the result (HIT, MISS, STALE, BYPASS; can be left out; not `Connection`, `Content-Length`, `Transfer-Encoding`, `Age`, `Vary`, `Set-Cookie` and the like) | `header` | `X-Cache` |

Before saving, the form checks the same rules as rproxy: in a route, `ip_allow`, `geoip`, `crowdsec`, `basic_auth`, `forward_auth` and `oidc` cannot come after `cache` (answers from the cache would not pass them), `basic_auth`, `forward_auth` or `oidc` before it needs `share_after_auth` (`oidc` also needs `share_credentials`, as the session cookie comes with every request; rproxy only warns in `--check-config`, but without it no request uses the cache, so the UI stops before saving), and a route takes one `cache`.
With an rproxy that cannot use it, the kind cannot be chosen, and existing `cache` settings are kept read-only.
"HTTP requests" on the details page shows the hits, misses, stale answers and bypasses, and the share answered from the cache (per route, the counts per middleware).

## Multiple targets

"Add backend" in the "Basic" tab lets a rule have multiple backends, with a choice of "Load balancing" (rproxy-api v0.3.3 or later; L4 TCP / UDP rules).

| Load balancing | Behavior |
|---|---|
| Round robin | Rotates in turn in proportion to the weights |
| Least connections | Sends to the target with the smallest current connections (sessions for UDP) ÷ weight |
| Failover | Uses only the first live target from the top (when an upper target comes back, new connections go back to it) |

- Targets marked "Backup" are used only when all non-backup targets are down.
- A health check (checked by a TCP connection; interval, timeout, port) can be added. For UDP rules, the TCP port to check is required. Even without a health check, rproxy takes a target that failed to connect out of rotation for a while.
- The details screen shows the state of each target (up / down, connections) when rproxy returns it.
- For L7 rules, the same three can be chosen as the service's "Load balancing" (failover goes through the servers from the top).
- Per-target connection caps (`max_connections`; rproxy-api v0.4.19, `features.target_max_connections`): the "Cap" of a target row (empty: no cap). A target at its cap is skipped like a down one, and when every target is full new connections are refused (counted in "Refused by limits"). With failover, targets fill up to their caps from the top. Caps can also be set on the several destinations per server name in the TLS tab and on the servers of L7 services (requests handled at once; not on status entries). In the targets field of per-node overrides, write `max=200`. The details screen shows "Connections / cap" (also for the targets of a server name; requests in progress for L7) and a "Cap" badge on full targets (for a rule with a single target and no health check, rproxy does not report up / down, so the state column is "-"), and rules refusing because of caps (every live target full, or every target full when none is live; an L7 service with a status entry is not refusing, as that entry answers) appear under "Rules needing attention" on the dashboard. Caps are per node, so group rules are checked node by node and the refusing nodes are named, and the "All" view of the details shows the total connections apart from "cap N per node". With an rproxy that does not support caps, the values are kept read-only and sent as they are.

## Listening on IPv4 and IPv6 at the same time

"Additional listen addresses" in the "Basic" tab lets the same port (range) be listened on at other addresses as well (rproxy-api v0.3.3 or later; up to 16).
You can list a representative IPv4 address together with a GUA IPv6 address, or specify `0.0.0.0` and `::` together. Statistics and logs are combined into one rule. The list shows "203.0.113.5:443 and 1 more (2001:db8::5)".

## Passing some server names through without termination (SNI passthrough)

In a rule that terminates TLS (including L7 rules), names set to "Do not terminate" under "Backends per server name" in the TLS tab are not terminated by rproxy; the connection is passed to the target as is, ClientHello included (the target's certificate is used; rproxy-api v0.3.3 or later).
For example, on `:443` rproxy can terminate cdn and gitlab and route them at L7, while passing registry and `**.tenant.example.com` straight to Kubernetes (with cert-manager certificates).

- One line can hold several server names separated by commas (rproxy's `server_names`).
- `*.example.com` matches exactly one level, `**.example.com` matches any number of levels (neither matches `example.com` itself). When several match, the order is: exact match → `*.` → `**.` (longer first) → the line higher up.
- In L7 rules, only "Do not terminate" lines can be used (other names are routed by L7 routes). "Disconnect" under "Connections matching no server name" cannot be used either.
- `allow_from`, CrowdSec and statistics also apply to passthrough connections.

## Accepting PROXY protocol from a front end, and client IP handling per server name

Two fields of rproxy-api v0.4.13 (`../rproxy-api/docs/en/SOURCE-IP.md`). They can be edited only when rproxy says it supports them in the `features` of `GET /capabilities`; with an rproxy that does not, a value that is already set is kept read-only and sent as is (saving does not remove it).

| Field | Where | `features` |
|---|---|---|
| Accept PROXY protocol (the rule's `proxy_protocol`) | "Accept PROXY protocol" on the "Advanced" tab | `proxy_protocol_in` |
| Client IP handling per server name (`tls.routes[].source_ip`) | "Client IP" on each row of "Backends per server name" on the TLS tab | `route_source_ip` |

- **Accept PROXY protocol**: when a load balancer, another rproxy or a Kubernetes Gateway in front of rproxy sends a PROXY protocol (v1 / v2) header, the address in the header is treated as the real client (used for `allow_from`, GeoIP, CrowdSec, limits, logs, `X-Forwarded-For` and the `source_ip` towards the backend). TCP rules only.
  - In "Front ends whose headers are trusted" (`from`), write the address of the hop right in front (the TCP peer), one CIDR or IP per line (up to 64; it cannot be empty, and `0.0.0.0/0` / `::/0` are not allowed; checked with rproxy's rules before saving). rproxy refuses connections from other peers that start with a header.
  - Unchecking "Require the header" (`required`, on by default) lets connections from a front end without a header through with the front end's address.
  - It is shown under "Advanced" on the details page and as the "PROXY in" badge in the list. Unchecking it and saving removes it from rproxy too (`proxy_protocol: {}` in the `PATCH`).
- **Client IP handling per server name**: only for names whose TLS is not terminated (the names of sni rules, and names marked "Do not terminate" in terminate rules, including those of L7 rules), how the client IP is passed to that name's backend can be chosen from `proxy`, `proxy_v1` and `proxy_v2` (`proxy_v1` cannot be chosen for UDP sni). Empty means the rule's source IP handling. `transparent` is per rule only.
  - Example: the L7 rule on `:443` stays L7, and only `**.tenant.example.com`, passed through to Kubernetes, gets `proxy_v2`.
  - Unlike the rule's source IP handling, it can be changed after creation (from the next connection, without cutting connections). It is shown as a "Client IP" badge on the backends per server name on the details page.

## TCP relay timeouts (idle_timeout, half_close_timeout)

Fields of L4 TCP rules in rproxy-api v0.4.20 (#353; "Relay timeouts and keepalive" in rproxy-api's docs/en/API.md). They can be edited under "TCP relay timeouts" on the "Advanced" tab only when rproxy reports `features.tcp_idle_timeout` in `GET /capabilities`. With an rproxy that does not, a value that is already set is kept read-only and sent as is (saving does not remove it). They are not shown for UDP (its idle timeout is `udp_idle_secs`) or for L7 rules (they follow `global.http.timeouts` in rproxy's settings file).

- "Connection carrying nothing" (`idle_timeout`, default `1h`): when nothing is carried in either direction for longer than this, rproxy resets both sides and closes them.
- "After one side has finished sending" (`half_close_timeout`, default `1m`): after one side has finished sending (half-closed), the connection is closed when the other direction carries nothing for longer than this.
- Write durations such as `30s`, `10m` or `1h`. `0s` is no limit, anything else is at least `1s` (checked with rproxy's rules before saving). Empty is the default; a value equal to the default (`60m` and so on) is left out.
- TCP keepalive probes do not extend them, so give connections that stay silent for long (DB connection pools, SSH, MQTT, etc.) a longer value or `0s`, and set `half_close_timeout` to `0s` or a longer value for clients that wait long for a reply after they finish sending (`nc -N`, backup tools, etc.). To behave as up to v0.4.19, set both to `0s`.
- They are also written to the DB `options` column, so a rule restored from the UI's DB after rproxy restarts has the same values (`0s` included; rproxy-api v0.4.20 or later). Emptying a field and saving sends the default (`1h`, `1m`) to rproxy.
- They are shown under "Advanced" on the details page (left out means "Default (1h)"), with the before and after values in the change history, and in the drift (several rproxy instances). Export and import keep them.

## Time to connect to a target (connect_timeout)

`connect_timeout` of L4 TCP rules in rproxy-api (v0.4.3; "Time to connect to a target" in rproxy-api's docs/en/API.md). It can be edited under "Time to connect to a target" on the "Advanced" tab only when rproxy reports `features.db_connect_timeout` in `GET /capabilities` (rproxy-api v0.4.21 or later). It is not shown for UDP or for L7 rules (the services' `timeouts.connect` on the L7 tab).

- How long a TCP connection to a target may take. Past it the attempt counts as a failure and, if there are other targets, the next one is tried. Empty means rproxy's default (`5s` with other targets, otherwise `30s`).
- Write it like `1500ms` or `3s`, from `100ms` to `10m` (checked with rproxy's rules before saving). Within one cluster, `1s`-`3s` is a reasonable value.
- It is also written to the DB `options` column, so a rule restored from the UI's DB after rproxy restarts has the same value. Up to v0.4.20, rproxy-api does not read `connect_timeout` from the UI's DB and does not restore a row with this key at all (the rule disappears at a restart), so with an rproxy that reports only `features.connect_timeout` the value is kept read-only and sent as is, and setting or changing it through the API (import, revert, copy and move included) is refused with 400 `unsupported`.
- For a group, every node of the placement is checked (the nodes are asked in parallel). The form field, too, can be edited only when every node reports `features.db_connect_timeout`, and it names the nodes that cannot restore it or cannot be reached. Re-creating (replace, revert, a move to an overlapping placement) checks before the current rule is deleted.
- While a node of the placement cannot be reached, `connect_timeout` cannot be set or changed until it is back (502 `unreachable`, because whether it can restore the value cannot be checked). Removing it, and changing other fields while keeping the current value, still work.
- If a node added to a group later, or downgraded, does not report `features.db_connect_timeout`, restarting that node does not bring back the rules with `connect_timeout`. "rproxy features & settings" (`/system`, administrators) shows a warning with the number of such rules placed on that node. Upgrade rproxy-api to v0.4.21 or later, or empty `connect_timeout` of those rules.
- Emptying the field and saving sends `0s` (remove) to rproxy.
- It is shown under "Advanced" on the details page (left out means "Default (5s with other targets, otherwise 30s)"), with the before and after values in the change history, and in the drift (several rproxy instances). Export and import keep it.

## Routing UDP by server name (DTLS, QUIC)

UDP rules can also choose the target by the server name in the first packet when the TLS tab's mode is set to "sni" (from rproxy v0.3.8). rproxy v0.3.18 or later reports its version, so "sni" is not offered when it is older than v0.3.8 (an older rproxy that does not report its version still gets the choice, with a note that v0.3.7 or earlier refuses it when you save). Nothing is terminated, so no certificate is needed (the target has it). You can start from the profiles "Route HTTP/3 (QUIC) by server name (UDP 443)" and "Route TURN DTLS by server name (UDP 5349)".

- Only DTLS and QUIC (HTTP/3, etc.) can be routed. UDP whose packets carry no server name, such as IKE (IPsec), WireGuard, RTP and games, gets the "when nothing matches" handling (send to the basic target / drop).
- It cannot be combined with an L7 rule that accepts HTTP/3 (http3) on the same address and port (the form warns about this).
- QUIC connection migration (changes of the client's address) is not followed, and for ECH connections the real server name cannot be read.

## Obtaining certificates with ACME

From rproxy-api v0.3.21, rproxy can obtain certificates with ACME (Let's Encrypt and others) and renew them itself before they expire (`../rproxy-api/docs/en/ACME.md`).
On the TLS / DTLS tab, choose "terminate", then "+ Add ACME certificate" and give the resolver and the names (separated by commas or spaces). ACME certificates can sit next to file certificates.

- Accounts, DNS providers, resolvers, the names they may obtain (`allowed_names`) and the secrets (DNS API keys and so on) are written in `global.acme` of rproxy's settings file (`RPROXY_CONFIG`). From rproxy-api v0.4.22 they can also be changed on "Global settings" (`/global`) when the settings file does not set them (see "rproxy features & settings" below; secrets are only named as files).
  The screen reads only the resolver names, their challenges and the allowed names from rproxy's `GET /acme` (rproxy does not return secrets either) and lets you choose. Creating or deactivating accounts and renewing right away (`POST /acme/...`) are not on the screen (use rproxy's Unix socket).
- They can be chosen only for TCP termination, when rproxy supports ACME (`features.acme` of `GET /capabilities`) and it has `global.acme` (in the settings file, or from v0.4.22 an API value). With an older rproxy, ACME certificates are kept read-only and the screen says "This rproxy does not support ACME".
- Before saving, the names are checked with rproxy's rules: wildcards (`*.example.com`) only with a `dns-01` resolver, and names only within the `allowed_names` of the resolver's account (and DNS provider). When rproxy refuses (`400 invalid`), the reason is explained on the screen too.
- The UI's token needs the `acme:write` scope (without it rproxy refuses with 403, and the screen says so).
- Until the certificate is issued, rproxy serves a self-signed stand-in (`rproxy ACME placeholder`). The certificate section of the rule details shows the state (pending, valid, renewing, failed), the expiry, the renewal time (and the CA's renewal window (ARI) when it gives one), the next attempt, the last error, and whether the stand-in is being served.
- For dns-01 resolvers, the form shows the DNS provider type (PowerDNS, generic REST, RFC 2136, acme-dns; unknown types are shown by name) and a note (with acme-dns a new name is not issued until its CNAME is created). When a helper process (`rproxy-api acme-helper`) holds the secrets, the form says so (the secrets themselves are never shown).
- Certificates that cannot be obtained or keep failing to renew are listed under "Needs attention" on the dashboard (the reason and the next attempt; the days left when renewals keep failing within 14 days of expiry). The list shows "ACME failed" / "ACME pending" badges.
- Export and import write and read ACME certificates (`{"acme": "<resolver>", "domains": [...]}`) as they are.

## v0.4 rule settings (limits, bandwidth, GeoIP, labels)

The rproxy-api v0.4 settings (`../rproxy-api/docs/API.md`, "v0.4 settings") are edited on the "Limits & GeoIP" tab of the form. Only the items that rproxy reports in `GET /capabilities` `features` can be edited; on an rproxy that cannot run them the tab only explains (a value already set is kept read-only and sent as it is). All of them are optional and change without cutting connections.

| Item | What it does |
|---|---|
| Labels (`labels`) | Marks such as `tenant=act` (up to 16). They do not change behaviour; rproxy shows them in logs and `/metrics`, and the UI uses them for usage reports |
| L4 limits (`limits`) | Concurrent connections (UDP: sessions) of the whole rule and per source, new connections per source, UDP datagrams per source. Connections over a limit are closed before TLS and counted as "Refused by limits" |
| Bandwidth limits (`bandwidth`) | Upload and download of the whole rule and per source (like `10Mbps`). TCP waits, UDP drops what is over |
| GeoIP (`geoip`) | Allow and deny lists of countries (ISO 3166-1 alpha-2) and ASes. Needs `global.geoip` (MaxMind mmdb) in rproxy's settings file. L7 rules can also use the `geoip` middleware |
| Passive health checks (`outlier_detection`) | Ejects targets that keep failing for a while (L4 rules). L7 rules set it per service on the "L7 (HTTP)" tab |

- Values are checked with the same rules as rproxy before saving (ranges, units, combinations; rproxy decides in the end). They are also stored in the DB `options` column in rproxy's API shape, so a restarted rproxy comes back with the same contents.
- When rproxy reports `features.dry_run`, the add and edit screens show "Show the difference". Before saving, it asks rproxy with `?dry_run=true` what would change on each node (create or update, whether it changes without cutting connections or recreates the listener, and each field before and after) without changing the DB or rproxy.
- The detail screen shows the settings, the count refused by limits, when counting started (`counters_since`), which targets are ejected and how often, and rproxy's `conditions` (Gateway API style status), when rproxy reports them.
- "rproxy features & settings" (`/system`) shows, read-only and per node, the rproxy-api version, the v0.4 feature flags, which `global.performance` keys of the settings file take effect, and the settings file state. Performance and control API hardening are changed in rproxy's settings file and arguments (not from the UI; GeoIP databases and ACME can also be changed on "Global settings" from rproxy-api v0.4.22). The settings file path and error text, the binary's SHA-256 and the reasons a node cannot be reached are shown to administrators only (users see that there is an error or a failure); users limited by `RPROXY_UI_USER_NODES` see only their nodes (the same applies to the dashboard's settings file notice).
- "Global settings" (`/global`; administrators only; opened from `/system`) shows, through rproxy-api v0.4.19's `GET /config/global`, each item of the process-wide settings with its value in force, where it comes from (settings file / environment / API / default) and how it changes (at once / needs a restart). Items written in the settings file or the environment are read-only ("Fixed by the settings file"; also when an API value is kept but not in force), and items read only at the start are shown only. Items left out that take effect at once (`udp_max_sessions`, `http.timeouts` and so on; which ones can be changed follows rproxy's `settable` and `unix_only` and the path to the node (Unix socket or TCP)) are sent with `PATCH /config/global` by "Apply" after "Check the changes" (`?dry_run=true`) shows what changes ("Clear the API value" goes back to the default). With several rproxy instances it shows each node, and choosing a group sends to every node of it (if any node refuses, or its answer times out and the outcome is unknown, the nodes already changed are put back, and the result per node, put back or not, is shown). The `write_stall`, `upgraded_idle` and `http2_max_streams` fields of `http.timeouts` (rproxy-api v0.4.20; `http2_max_streams` is sent as a number from 1 to 10000, not a duration) are shown only when every chosen node reports `features.http_stream_limits` (names already in the API value are shown even on an rproxy without it, so replacing the whole item does not drop them). The contents of items that need a restart are not shown. rproxy stores the values in the database table `rproxy_global` (migration 013), so they survive a restart. Items that guard security (`trusted_proxies`, `access_log`, `crowdsec`; rproxy's `unix_only`) are accepted only over rproxy's Unix socket, so they cannot be changed on a node reached over TCP (to change them, set the UI's url of that node to the socket of rproxy-api's `RPROXY_API_SOCKET` (`unix:/…`)). An access log set through the API must be a file directly in the node's rproxy-api `RPROXY_API_ACCESS_LOG_DIR` (there is no default: without it, access logs cannot be set through the API; use a directory only for rproxy's access logs). While rproxy has not read the stored values at the start (`loaded: false`: the database cannot be reached or a row cannot be read), the screen shows a warning and nothing can be applied. The UI's token needs rproxy's `admin` scope. With an rproxy without `features.global_api` no items are shown.
- `geoip` (GeoIP databases) and `acme` on "Global settings" (rproxy-api v0.4.22, #345): they can be changed as live items only on nodes that report `features.global_api_geoip` and `features.global_api_acme` (on an older rproxy without them they stay read-only as "needs a restart", with their contents hidden). Both are security-related items (`unix_only`), so they can be changed only on nodes reached over the Unix socket.
  - `geoip` has the fields `country_db`, `asn_db`, `check_interval` and `log_country`. The databases must be regular files directly in the node's rproxy-api `RPROXY_API_GEOIP_DIR` (geoipupdate's `DatabaseDirectory`); the screen checks that they are absolute paths of file names in one directory (after resolving `//`, `.` and `..` textually; rproxy refuses files outside the directory, and links, with `403 protected_file`).
  - `acme` has fields for accounts (names are letters, digits, `-` and `_`, up to 64 characters; `directory`, `contact` (`mailto:`), `allowed_names`, EAB, `ca_file`), DNS providers (`powerdns`, `http`, `rfc2136`, `acme_dns`; `allowed_names` and only the fields the type uses: no `zones` for `acme_dns`, `ttl` only for `powerdns` and `rfc2136`; `http` needs both `add` and `remove`), resolvers, `storage`, `http01_listen`, `dns_servers`, `rate_limit` and so on. There are no fields for secret values: secrets are only named as files directly in the node's rproxy-api `RPROXY_API_ACME_DIR` (all the files in the same directory; `storage` is the default or a directory under it), and the account key (`key_file`) cannot be set (rproxy creates it in `storage`). The credentials of an `http` provider are only inserted from the contents of `secret_file` as `{secret}` into a header or the body: headers named like credentials may only be `{secret}` or `<Scheme> {secret}` (`Bearer {secret}`). URLs end up in logs, so `{secret}`, query parameters named like credentials and users cannot go in the URL (the same rules as rproxy; the screen refuses before sending).
  - rproxy returns the secret-related values of `acme` (file locations, headers, bodies, a URL's user, path and query) as `***`, and the UI hides them again in the same way before passing them to the screen. The fields show `***` as is, so when changing `acme`, enter those fields again (file locations, and also `eab.kid` and `tsig_key_name`, whose names contain `key` or `secret`; the item is replaced as a whole, and neither the screen nor the UI server sends anything while `***` remains).
  - Refusals are explained on the screen: `409 in_use` (removing databases, resolvers or names rules use, or an `http01_listen` that overlaps another listener), `403 protected_file` (files outside the directory), `409 limit` (too many listeners for `http01_listen`). When a settings file reload removed something rules use and the previous value is kept (`kept`), and when the API value is not in force because the settings file wins (`shadowed`), the item's notes say so.
  - When some nodes of a group refuse, the nodes that applied it are put back as for the other items. But when rproxy returns the previous `acme` value hidden, it cannot be put back, so the UI first runs a dry run on every node and changes nothing if any of them refuses. If a node still refuses during the apply, the nodes that applied it are reported as "could not be put back".
- To protect the control API with client certificates (mTLS), set `RPROXY_API_TLS_CERT` and `RPROXY_API_TLS_KEY` (and `RPROXY_API_TLS_CA` to verify rproxy's certificate), or `tls_cert`, `tls_key` and `tls_ca` in `nodes.yaml` for several rproxy instances (`https://` URLs only; when the token file entry has only `client_cert`, no token is needed). With `RPROXY_API_TLS_*` and an `http://` or `unix:` `RPROXY_API_URL`, the token would travel in plain text, so the UI does not start (and sends no request).
- When rproxy temporarily locks the UI out after repeated authentication failures (`429 locked_out`), the screen and the log say to check the token and certificate (the lockout ends by itself).

## Usage

| Screen | Contents |
|---|---|
| Dashboard (`/`) | Whether rproxy is reachable, the number of rules (including static rules), a card per TCP / UDP (donut of running, failed, missing and unknown, connections, total connections, rx / tx, TLS failures, denied), the TLS breakdown, rules that need attention, and a table of all rules (filter by protocol, state and search; select a row to open its details; static rules are marked "Static" and rules that restrict the source are marked "IP restricted"). Refreshes automatically every 5 seconds (can be toggled) |
| New rule (`/rules/new`) | The add form |
| Rule details (`/rules/{tcp\|udp}/{listen address}/{port}`) | Settings, live state and statistics. "Edit" and "Delete" (not available for static rules) |
| Edit (details URL + `/edit`) | The change form |
| Import (`/rules/import`) | Load rules from YAML / JSON (see "Export and import" below) |
| Change history (`/history`) | History of adding, changing and deleting rules, and reverting to an earlier version (see "Change history and revert" below). The rule details screen also shows the history of that rule |
| Usage (`/usage`) | Traffic report per month or day (grouped by owner, label, node or rule) with CSV, and traffic over time (see "Usage" below) |
| rproxy features & settings (`/system`) | Per node: the rproxy-api version, v0.4 feature flags, which `global.performance` keys take effect, the settings file state (read-only) |
| Global settings (`/global`) | Each item of rproxy's `global` with its value in force, where it comes from and how it changes, and changing the items the API may set (apply after checking the changes; administrators only) |

rx is the number of bytes from the client to the target, tx from the target to the client (cumulative since rproxy started the rule; reset to 0 when rproxy restarts).
"Refused" is the number of connections dropped because they were outside the allowed sources (allow_from), or because of the setting that drops connections matching no server name (unmatched: reject).

Static rules are the rules in the file rproxy loads at startup (`RPROXY_STATIC_RULES` / `--static-rules`; "Static rules" in `../rproxy-api/docs/API.md`) and are not stored in the DB.
They are shown on the dashboard and details screens to anyone who is signed in, but cannot be changed or deleted from the screens (edit the file and restart rproxy).

**Overlays on static rules** (rproxy-api v0.4.23's `GET` / `PUT` / `DELETE /rules/{key}/overlay`, `features.static_overlay`; UI #193): under "Overlay" in a static rule's details you can add, leaving the file's rule as it is, http routes, services and middlewares (when the rule has `http`) or per-server-name destinations (`tls.routes`; when the TLS mode is sni, or terminate without http and client authentication). It is shown only on nodes that return `features.static_overlay`.

- Overlay routes only see requests that match none of the file's routes (a higher priority does not take requests of the file's routes). Server names likewise only those that match none of the file's `tls.routes` (names under the file's `*.example.com` cannot be used).
- Editing uses the same fields as the "L7 (HTTP)" tab, and the file's services and middlewares can be chosen by name (marked "settings file"). Names the file has cannot be used in the overlay (`409 overlay_conflict`; also reported before saving). "When no route matches" and HTTP/3 are the file's.
- Saving replaces the whole overlay and sends the `ETag` from when it was opened as `If-Match`. If someone else changed it first, it is `412`, and "Reload" shows the current overlay.
- States: applied, not applied (`not_applied`: after a reload the static rule is gone, changed shape, or no longer validates merged; the overlay is kept and applies again when the file allows it), and items left out because the file now has the same name (`shadowed`). A note is shown when it could not be stored in the database (`persisted: false`).
- Permissions: it can be changed by people who may use the node (`RPROXY_UI_USER_NODES`) and the rule's whole port range (`RPROXY_UI_USER_PORTS`). Non-administrators cannot write file paths (`403 file_not_allowed`; existing values stay hidden in the same place), their destinations are checked against the allow list, and they cannot use the file's services and middlewares that hold (or use something that holds) secret files (a service's client key, an OIDC secret, a `users_file`) (`409 file_in_use`; the UI refuses it even when the UI's token is an rproxy admin; such items are shown as "holds secret files" and cannot be chosen). `basic_auth`'s `user_header` and `forward_auth`'s `response_headers` cannot name forwarding headers such as `X-Forwarded-For` (`400`).
- Non-administrators cannot use the settings file's **services** from an overlay at all (even without secret files; `403 file_service_not_allowed`; they cannot be chosen in the form either). An overlay route reaches such a service without the file routes' middlewares (authentication and so on), and its targets are outside the user's allow list (`RPROXY_UI_USER_TARGETS`). The same goes for file services reached through file middlewares (`mirror`, `errors`) or per-target middlewares (followed transitively, as rproxy does for overlays). The exception is a file `forward_auth` (the administrator's SSO or authentication): it can be attached to your own routes, since it only adds an auth check, so the service it asks is not counted. Define your own service in the overlay (its targets are checked against the allow list). The settings file's **middlewares** without secrets can be used. Administrators can use any of them as before.
- Non-administrators can change, remove or resend **only overlays they created** (`403 overlay_not_owner`). Overlays created by an administrator, another user, or directly through the rproxy API are read-only for them. rproxy's `created_by` is always the UI's token, so the creator is taken from the UI database (`created_by` in `forward_rule_overlays`). Without that row it is taken from the UI's history (each `OVERLAY` row keeps rproxy's `created_at`; the operator of the first row with the same `created_at` after the latest removal row, resend rows excluded), and without that history only administrators can change it.
- When creating one (no overlay yet), the UI sends `If-None-Match: *` (rproxy-api #399). If someone else created one between the read and the save, it is `412`, and "Reload" shows the current overlay (nothing is overwritten). rproxy refuses this race from rproxy-api v0.4.23; earlier versions ignore the header, and the UI only checks beforehand that there is none (one created just after that check can be overwritten).
- Several rproxy instances: static rules come from each node's own settings file, so overlays are per node too (never grouped; `target` is a node name, and even a group with a single node is `400 target_required`; only the node of the details page is changed).
- Storage: the UI keeps the desired state of overlays in its own database table `forward_rule_overlays` (migration 015). The row is written first and then sent to rproxy; if rproxy clearly refuses (4xx) the previous row is put back, and on success it is aligned with the form rproxy answered. On a timeout or no connection rproxy may have applied it, so the new row stays. Removing also deletes the row first, puts it back when rproxy refuses, and keeps it deleted with a warning on a timeout. Without 015, or when the UI cannot write it, the UI refuses before sending anything to rproxy (`overlay_db` and so on). rproxy follows the UI token's `persist` and stores overlays in the database's `rproxy_rule_overlays` (migration 014). With a normal UI token (no `persist`) rproxy does not store them and loses them on restart (the UI does not read that table).
- Drift and resend (#197): the UI compares `forward_rule_overlays` with rproxy's current overlays and shows a missing or different one under "Rules needing attention" on the dashboard and under "Overlay" in the details (also counted in the node list's drift; administrators see all, others only their own). "Resend from the UI database" in the details (for whoever may change it) or "Resend all N drifted overlays" on the dashboard (administrators only; a node tab resends that node only) sends it to rproxy again (`If-None-Match: *` when missing, `If-Match` when different). Right before a resend, one a user wrote last (`created_by_admin` 0) is checked again as its creator (with no previous content, so values only kept because they were already there are refused too; nothing is checked with an empty `RPROXY_UI_USER_ROLE`; allow list with names resolved again, protected destinations, allowed nodes and ports, file services, secret files, forwarding headers; if the rules changed after it was saved, it is not sent). A resend is recorded in the history as a resend of "Overlay on a static rule" (`OVERLAY`), and the UI database is aligned with the form rproxy answered.
- Overlays are per node. Each node keeps only its own rows; even in an act / stb group the act's overlays are not copied to the stb. The automatic act / stb resend and "Sync this node" resend that node's own rows after the same check (one refused by the check, or whose creator is unknown, is not sent and is shown as "Refused when checked again as its creator"). Overlay drift is shown on the act / stb screen but is not part of the promotion check (`ha/ready`): like keys used by API rules it is for information only, so an overlay rproxy refuses never stops keepalived from promoting. If the UI database cannot be read, the rule checks go on.
- Overlays whose node was removed from the settings, or whose static rule left the settings file, are listed for administrators under "Rules needing attention" on the dashboard as "Overlays left only in the UI database", and "Remove from the UI database only" (`overlay-forget`; nothing is sent to rproxy; refused while the static rule still exists) deletes them.
- Changes are recorded in the history as "Overlay on a static rule" (`OVERLAY`; they cannot be reverted).

The form is divided into tabs.

| Tab | Contents |
|---|---|
| Basic | Profile (templates by use case), protocol, listen address, port (the end of a range is optional), target |
| L7 (HTTP) | Routes, services, middlewares and "When no route matches" (L7 rules; TCP, when rproxy supports L7) |
| TLS / DTLS | passthrough / sni / terminate (DTLS for UDP), backends per server name (with the client IP handling for names whose TLS is not terminated, and the TLS to the backend for names rproxy terminates) and "Connections matching no server name" (Send to the default backend / Disconnect), certificates, TLS options (minimum version and cipher suites; TCP terminate), client certificate verification (mTLS), ALPN, re-encryption to the backend (for L7 rules, "TLS to https:// backends": no re-encryption choice; the server name to verify, CA and client certificate used when a backend URL is https://. Services with their own TLS to the backend use theirs instead) |
| Mail (STARTTLS) | STARTTLS for SMTP / IMAP / POP3 (only for TCP with "terminate") |
| Limits & GeoIP | Labels, L4 limits, bandwidth limits, GeoIP, passive health checks (rproxy-api v0.4; see "v0.4 rule settings" above) |
| Advanced | Source IP handling (source_ip), UDP idle timeout, TCP relay timeouts (idle_timeout, half_close_timeout; L4 TCP), time to connect to a target (connect_timeout; L4 TCP), allowed sources (allow_from), accept PROXY protocol (proxy_protocol; TCP) |

- A profile only fills the form with the recommended settings from `../rproxy-api/docs/PROFILES.md`. Enter the addresses and certificate paths for your environment.
- The certificate, private key and CA paths are paths on the rproxy-api server. If they cannot be read, you get a `tls_config` error.
- rproxy-api only reads certificate, private key, CA and secret (htpasswd and so on) files owned by the OS user it runs as (`rproxy-api` with the package), so nobody can name another user's key and connect or listen with that identity. Read access for the `rproxy` group is fine, but files the group or others can write, and keys or secrets anyone can read, are refused too (for example `chown rproxy-api:rproxy`, `chmod 0640`; 0600 or 0640 for keys). With another owner or such a mode rproxy refuses the file, and the screen explains why and how to fix it.
- Specify certificates as files (obtained with certbot, cert-manager or similar) or with ACME (from rproxy-api v0.3.21; see "Obtaining certificates with ACME" below).
  For files, rproxy checks whether the files changed every 60 seconds (rproxy's `RPROXY_CERT_CHECK_SECS`) and reloads renewed certificates automatically, so you do not need to edit the rule on every renewal.
- Intermediate CAs (optional) go in one PEM file, ordered from the CA that issued the server certificate toward the root (the root is not needed). If the order is wrong, rproxy rejects it with `tls_config`.
  For client certificate verification, specify the root CA (trust anchor) in the CA file and the intermediate CA that issued the client certificates as the intermediate CA. Intermediate CAs can also be specified for the client certificate sent to the target.
- A port range (e.g. `8000-8001`) forwards each port in turn starting from the target port. The upper limit is rproxy's `max_range_ports` (default 20000). The range and the source IP handling cannot be changed after creation (TLS settings can be changed).
- WebRTC media cannot connect if DTLS is terminated. Use a passthrough range rule.
- Allowed sources (allow_from) take one entry per line, a CIDR (`172.16.0.0/16`, `fd00::/8`) or a single IP (up to 64). If empty, everything is allowed.
  TCP connections from outside the range are dropped before TLS (in rules that accept PROXY protocol, connections from a front end are judged by the header's client), and for UDP, datagrams from sources outside the range are discarded. On save they are normalized, e.g. `10.0.0.5` → `10.0.0.5/32`.
- "Connections matching no server name" can be chosen only for sni (TCP / UDP) or TCP terminate with backends per server name. "Disconnect" drops connections with an unmatched name or without SNI (with terminate, they are dropped without completing the handshake).

## Rules created through the rproxy API

Rules created by calling the rproxy API directly (CI, scripts, Kubernetes controllers; not in the UI's DB) appear with an "API" badge on administrators' (`rproxy-admin`) dashboards and detail screens (#76; users do not see them).

- rproxy-api v0.4 stores the rules created with a `persist: true` token in its own table `rproxy_rules` (`db/migrations/009_rproxy_rules.sql`, in the UI's DB) and reports `origin: "api"` with the creating token and time. The UI reads rproxy's `GET /rules` and `rproxy_rules`, and shows stored rules that are not running in rproxy as "missing". Rules that are not stored show "API (not stored)" (they disappear when rproxy restarts).
- Edit and delete go through the rproxy API (`PATCH` / `DELETE`); nothing goes into the UI's DB or history, and there is no pause, copy or resend. Changes to and deletion of a stored rule (`origin: "api"`) are written to `rproxy_rules` by rproxy even though the UI's token has no `persist` (rproxy decides by the rule's origin). Only when rproxy could not store it (`persisted: false` in the answer) does the UI say a restart brings back the earlier contents. "Show the difference" works when rproxy reports `features.dry_run`.
- Rules of a rule set (`ruleset`, applied as a whole with `PUT /rulesets/{name}` by e.g. a Kubernetes controller) show a "Set: name" badge and are read-only (rproxy also refuses changing them one by one with `409 owned`).
- When an API rule or a rule-set rule in rproxy uses the same key as a UI rule (so the UI rule is not running), the detail screen warns. rproxy prefers the UI's table at startup; delete one of them or change the key.
  Until then, changes, resumes, resends and diffs of the UI rule are not sent to rproxy (`409 shadowed`), and pausing or deleting it changes only the UI's DB (operations on the UI rule never change or delete the API rule). The automatic act / stb resend skips that key too and only reports it as overlapping an API rule (promotion is not blocked). Users other than administrators do not see the destination, statistics, state, creating token or rule-set name of the rule running under that key.
- With several rproxy instances, match rproxy's `RPROXY_NODE_NAME` with the node names in `RPROXY_UI_NODES` (the `node` column of `rproxy_rules`). The per-node views (`db/node-view.mjs`) also create an `rproxy_rules` view that can write only that node's rows.

## Pausing a rule

"Pause" on the rule details screen (or on the row in the list) stops a rule without deleting it. "Resume" runs it again with the same contents.

- Pausing keeps the rule in the DB and removes it from rproxy (the listener closes and existing connections are cut). Paused rules are not created even when rproxy restarts (from rproxy-api v0.3.5; it reads `"enabled": false` in the DB's `options` and skips them).
- Paused rules can still be edited (only the DB changes, and the rule is created with those contents on resume). Deleting also touches only the DB.
- The list, details and dashboard show "Paused" and count them separately.
- Pause and resume are recorded in the history as "Changed" (the difference shows whether it is paused).
- Exports add `enabled: false` to paused rules (importing restores them as paused). This field is only valid within the UI's export format.
- "Replace" on import and reverting from the history keep the current paused / running state (only the contents change). Reverting a deleted rule recreates it in the state of that version (paused if it was paused).

## Export and import

"Export (JSON)" on the dashboard writes your rules (for `rproxy-admin`, the rules of all users) as JSON (for UI backups and migration).

```json
{"format": "rproxy-ui-export", "version": 1, "exported_at": "...", "rules": [{"protocol": "tcp", "listen_addr": "0.0.0.0", ...}]}
```

- The fields of each rule have the same names as in rproxy's API and settings file (`remote_addr`, `tls`, `http`, `targets`, `proxy_protocol`, `tls.routes[].source_ip`, etc.). Fields with default values (`source_ip: proxy`, `udp_idle_secs` for TCP, `tls` for passthrough, etc.) are omitted. Paused rules get `enabled: false`.
- The leading `format` distinguishes the file from an rproxy settings file. rproxy does not know this field, so even if the exported file is placed as `RPROXY_CONFIG`, it is not loaded by mistake but rejected (when moving to a settings file, use the contents of `rules` and remove paused rules and `enabled`).
- `rproxy-admin` can export only a specific user's rules with `/api/forward/export?owner=<user ID>`.

"Import" (`/rules/import`) loads a UI export (JSON) or an rproxy settings file (YAML / JSON; `version: 1` and `rules:`, or an array of rules). It can also be used to move rules written in a settings file under UI management.

1. "Check" validates each rule the same way as adding it from the screen, and shows the results (add / same key exists / error) in a table. Nothing is changed yet.
2. For rules whose key (protocol, listen address, port) already exists, you can choose "Replace" per row (skipped if not chosen).
   The same key as another user's rule, the same key as an rproxy static rule, and keys that overlap within the loaded content are errors.
3. "Import" adds / replaces the rules one by one. If it fails partway, the successful ones remain (the result is shown per row).

- `global` (CrowdSec, trusted_proxies, etc.) is an rproxy-side setting, so it is skipped.
- On replace, a rule that differs in source IP handling, port range or L4 / L7 is deleted and recreated (existing connections are cut).
- The `RPROXY_UI_USER_PORTS` restriction applies to imports as well.
- Additions and replacements are recorded in the history, the same as operations from the screen.

## Change history and revert

"History" (`/history`) shows the history of adding, changing and deleting rules (when, who, what). Changes show the difference from the previous version (target, TLS mode, allowed sources, etc.).
You can filter by protocol, listen address, port, operation and period (`rproxy-admin` can also filter by the user who performed the operation). The rule details screen also shows the history of that rule.

- What you can see: users see the history they performed and the history of the rules they currently own. `rproxy-admin` sees everything.
  - **Earlier owners' versions are visible too**: history rows have no owner column, and rules are matched by key (protocol, listen address, port and, with nodes configured, the node / group). A user who creates a rule with the key of a rule someone else deleted also sees the versions from when the other person owned it (who performed it, targets, stored certificate names, file paths, allowed sources, labels and so on; nothing is hidden) as "history of the rules they currently own", and "Revert to this version" can create the same contents (the user limits check them like new values). To hide old versions between users, an administrator deletes them from `forward_rules_log` with the DB's admin user (e.g. `DELETE FROM forward_rules_log WHERE protocol = 'tcp' AND src_addr = '0.0.0.0' AND src_port = 8443 AND updated_at < '2026-10-01'`).
- "Revert to this version" restores the contents at that point. For change and add rows it restores the contents after that operation; for delete rows, the contents just before deletion.
  If the rule still exists it is replaced (a version that differs in source IP handling, port range or L4 / L7 is recreated); if it was deleted it is recreated. Reverts are also recorded in the history.
- rproxy static rules are not in the DB, so they do not appear in the history (a revert is not possible when a static rule with the same key exists). Changes of overlays on static rules (`OVERLAY`) do appear (they cannot be reverted).
- The history is the DB's `forward_rules_log`. No columns were added, so no migration is needed.

## Usage (traffic accounting)

rproxy's statistics (connections, rx / tx) go back to 0 when rproxy restarts, so every `RPROXY_UI_USAGE_SECS` (default 300 seconds, 0 turns it off) the UI reads each node's `GET /rules` and stores the difference from the previous reading in the DB (#101; `db/migrations/010_usage.sql`; without it nothing is collected).

- Stored per rule and node hourly (`usage_hourly`, `RPROXY_UI_USAGE_HOURLY_DAYS` days, default 32) and daily (`usage_daily`, `RPROXY_UI_USAGE_DAILY_DAYS` days, default 400); months add up the daily rows. Buckets follow UTC. The UI deletes old rows.
- When rproxy v0.4's `stats.counters_since` (when counting started) changes, the counters were reset and the current values are added in full (a live upgrade (handoff) keeps it, so counting continues). Older rproxy versions are told apart by `started_at`.
- Each row records the rule's owner at that time (the user who created the UI rule), node / group, labels (`labels`) and origin (UI, static, API). When the owner or marks change (someone else creates a rule with the same key on the same day, an administrator reassigns it, labels change), new traffic goes to a separate row and earlier traffic is never moved to the new owner (`db/migrations/011_usage_attr.sql`).
- Why collection failed (for example a node's rproxy could not be reached) is shown to administrators only (users see that it failed). The CSV puts `'` before values a spreadsheet would read as a formula (`=`, `+`, `-`, `@`, `|`, `%` after leading spaces, full-width `＝`, `＋`, `－`, `＠` and so on).
- Rule details and the dashboard show a traffic chart (24 hours, 7 days, 30 days, 12 months; rx and tx stacked, also as a table. "Summary" is the traffic over time, totals per hour for 24 hours, per day for 7 and 30 days and per month for 12 months; "Detailed" shows the period's total per listening port as vertical bars, largest first (the top 20, the rest as "Others"; the table has them all). A rule's own chart shows the traffic over time only), and "Usage" (`/usage`) shows a report per month or day (grouped by owner, a label key, node or rule) with CSV export. Administrators see all rules, users only their own.
- With several UI instances, each collection runs in only one of them (a DB lock).

## Several rproxy instances (nodes and groups)

One UI can manage several rproxy instances (**nodes**) (#98; this version lays the foundation). Nodes that carry the same rules form a **group** (active / standby is a group too; showing the roles comes in a later version).
A rule belongs to a node or a group. Adding, changing, deleting, pausing, resuming, importing and reverting a group's rule is sent to every node of the group. If one node fails, the change is undone on the nodes that succeeded and the DB is left unchanged (the response's `nodes` has the result per node).

Without `RPROXY_UI_NODES`, the UI works as before with the single rproxy of `RPROXY_API_URL` / `RPROXY_API_TOKEN` (no change to the settings or the DB; the screens look the same).

```yaml
# /etc/rproxy-ui/nodes.yaml (RPROXY_UI_NODES=/etc/rproxy-ui/nodes.yaml; YAML or JSON)
nodes:
  - name: node1                      # up to 32 lowercase letters, digits or _ (node and group names must all differ)
    url: http://10.0.0.11:8080       # http(s):// or unix:/run/rproxy/api.sock
    token_file: /etc/rproxy-ui/tokens/node1   # tokens are read from files (never stored in the DB)
    # tls_cert: /etc/rproxy-ui/tls/node1.pem  # client certificate (mTLS) for an https:// url (with tls_key; tls_ca is rproxy's CA)
    # tls_key: /etc/rproxy-ui/tls/node1.key
  - name: node2
    url: http://10.0.0.12:8080
    token_file: /etc/rproxy-ui/tokens/node2
groups:
  - name: ha
    nodes: [node1, node2]
    mode: active_standby             # single (default) or active_standby
    vip: 192.0.2.10                  # the active_standby VIP (optional; may be a list; see "act / stb" below)
    auto_resend: true                # the UI resends to a drifted stb automatically (default true; #109)
default_target: ha                   # chosen first on the add screen (optional; automatic with one node)
```

- The file is checked when the UI starts; if it is wrong, the reason is logged and the UI does not start. Restart the UI after changing it. The user running the UI (`rproxy-ui` with the .deb) must be able to read the token files.
- With two or more nodes, the add screen has a "Node / group" choice, and the list and the detail show the node / group. A group rule's state is the worse one (failed > missing > unknown > running); connections and traffic are summed.
- The dashboard and the rule detail get "All / per node" tabs (no tabs with a single node). A node's tab shows that node's state, connections, rx / tx, denied, HTTP request counts and certificate expiry; "All" shows the totals and a table comparing the nodes (act and stb traffic side by side; on the dashboard also reachability, rules, failures and drift counts).
- **Drift**: the rule running on each node (`GET /rules`) is compared with the UI's definition (the DB), and differing fields (destination, TLS, allow_from, etc.; runtime figures are not compared) are shown as "Drift". "Resend to this node" on a node's tab of the rule detail sends the UI's definition to that node only (differences PATCH cannot fix (source IP handling, port range, L4 / L7) recreate the rule; a rule missing on the node is created; a paused rule still running is removed). Only the rule's owner and admins can use it, and the history records "Resend" (`RESEND`) with the node.
- **act / stb**: in an active_standby group, the node whose `GET /interfaces` has the VIP is shown as act, the others as stb. The VIP is the group's `vip`, or, without it, the rule's listen address (when it is not `0.0.0.0`, `::` or loopback). stb does not hold the VIP, so rules usually listen on `0.0.0.0` (without `ip_nonlocal_bind` stb cannot bind the VIP); setting `vip` is recommended. A warning is shown when no node or several nodes hold the VIP.
- The dashboard's rproxy settings-file warning covers every node, each prefixed with the node name. The node list also shows when each node was last applied to (from the history).
- **Per-node overrides**: even for a group rule, "Settings for this node only (override)" on a node's tab of the rule detail changes the listen address (and the additional listen addresses), the destination (one destination or multiple targets) and the allowed sources, and can pause the rule on that node only (TLS, L7, source IP handling and the port range stay the same across the group). Saving applies it to that node only, right away, and the history records "Node override" (`OVERRIDE`) with the node. Drift checks and resends compare with the overridden contents. The per-node views apply the overrides too, so a restarted rproxy comes back with the same contents. Exports carry them as `overrides` (a UI-export-only field), and importing into a group restores them.
- **Copy / move**: "Copy / move" on the rule detail creates the same rule on another node or group (move deletes the original). Copying to a destination sharing nodes gives 409 `target_conflict`; moving there deletes the original first and then creates the rule (restoring the original if that fails). Overrides are kept only for nodes that are also in the destination; when placing the rule on a node, that node's override becomes the rule's contents. The history records the add (and, for a move, the delete).
- **Per node**: "Pause all / Resume all" on a node's tab of the dashboard pauses or resumes all of that node's rules (rules on that node as a whole, group rules on that node only). The scope (node / group) can be chosen next to "Export".
- **Syncing before an act / stb promotion** (#109): so that a stb that drifted from act (= the DB definition) is not promoted as is,
  - the UI checks active_standby groups every `RPROXY_UI_HA_SYNC_SECS` (30 seconds by default; 0 stops it) and resends drifted / missing rules automatically (the history records "Resend" by `system`). `auto_resend: false` on a group only shows the drift. After 3 failures in a row the dashboard shows a warning. With several UIs running, a DB lock makes only one of them run each check.
  - endpoints for keepalived (instead of a Keycloak session, they take a token from `RPROXY_UI_HA_TOKEN_FILE` (one per line) as `Authorization: Bearer`; 404 when it is not set; 401 without a bearer token; 500 `ha_token_file` when the file cannot be read (the path and the reason go to the UI's log only)): `GET /api/forward/ha/ready?node=` (200 when in sync, 503 with the details otherwise) and `POST /api/forward/ha/notify?node=&state=MASTER` (resends to the node right after it is promoted).
  - scripts and an example configuration are in `contrib/keepalived/` (`/usr/share/doc/rproxy-ui/examples/keepalived/` with the .deb). The track_script lowers the priority only on 503 and does nothing when the UI cannot be reached (if act fails, the stb is promoted even when not in sync).
  - the "act / stb" screen (`/ha`; administrators only; opened from the dashboard's node list) shows each group's act and whether each node is in sync, and "Sync this node" resends. It also guides going back to the original act (failback). keepalived moves the VIP.
- **Node-scoped roles**: `RPROXY_UI_USER_NODES=node1,node2` limits the nodes `rproxy-user` can change (a group only when all its nodes are listed; otherwise 403 `node_not_allowed`; the add screen's choices are limited too). `rproxy-admin` is not restricted. No restriction by default.
- Rules with the same key (protocol, address, port) can be put on nodes / groups that share no node (otherwise 409 `target_conflict`).
- Apply `db/migrations/006_nodes.sql`, `007_log_node.sql` (the node of a resend in the history) and `008_overrides.sql` (per-node overrides; recreate the per-node views afterwards) and `009_rproxy_rules.sql` (rproxy-api v0.4 API rules) before using it (a `target` column in `forward_rules` and `forward_rules_log`, and the `forward_rule_targets` table). Existing rules belong to `default`: name a node `default` in the file, or move them with `UPDATE forward_rules SET target = 'node1' WHERE target = 'default'`.

### Restoring at rproxy startup (a view per node)

rproxy reads the whole `forward_rules` at startup, so each node gets its own database containing a view named `forward_rules` with only the rows of that node and of the groups containing it (rproxy is not changed).
`db/node-view.mjs` prints the SQL (`/usr/share/rproxy-ui/db/node-view.mjs` with the .deb). Run it as an administrator who can read the UI's tables.

```bash
node db/node-view.mjs node1 --database rproxy --host 10.0.0.11 --password '<password>' | mariadb -u root -p
# rproxy on node1: RPROXY_DATABASE_URL=mysql://rproxy_node1:<password>@<DB host>/rproxy_node_node1
```

The view filters through `forward_rule_targets` (rewritten by the UI to match the file), so changing groups needs no new view (run it only for a node you add). See `db/README.en.md`.

## Backup and restore

The source of truth for the UI's rules is the DB's `forward_rules` (the history is `forward_rules_log`). Besides the DB, back up `/etc/rproxy-ui/rproxy-ui.env` (`NEXTAUTH_SECRET`, `KEYCLOAK_CLIENT_SECRET`, `DB_PASSWORD`, `RPROXY_API_TOKEN`) and `/etc/rproxy` on the rproxy side.
How to take backups (`mariadb-dump --single-transaction`, a systemd timer example), the restore order, checks after restoring (comparing rproxy's `GET /rules` with the DB), moving to a new host, and running rproxy alone when the DB is broken are described in [docs/en/BACKUP.md](https://github.com/max3584/rproxy-api/blob/master/docs/en/BACKUP.md) of rproxy-api.
"Export (JSON)" also works as a copy of the rules (see "Export and import" above).

## Tests

```bash
npm test
```

The list of tests, and how to run the E2E tests that use a real MariaDB and rproxy-api (`RUN_E2E=1`), are in [docs/en/TESTING.md](docs/en/TESTING.md).
