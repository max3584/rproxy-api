-- 現在のテーブル定義（MariaDB）。migrations/ をすべて適用した結果と同じ内容に保つこと。
-- rproxy-api が読む列: protocol, src_addr, src_port, src_port_end, dist_addr, dist_port, source_ip, udp_idle_secs, options
-- （複数のノードでは、rproxy はノードごとのデータベースの forward_rules ビューを読む。db/node-view.mjs）
-- options は {"tls": ..., "starttls": ..., "starttls_required": ..., "allow_from": [...]} の JSON（allow_from は省略できる）。rproxy は未知のキーを拒否するので、ほかのキーを入れないこと

CREATE TABLE IF NOT EXISTS forward_rules (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  auth_id       VARCHAR(255) NOT NULL COMMENT 'IdP（Keycloak）の sub',
  target        VARCHAR(32)  NOT NULL DEFAULT 'default' COMMENT 'ノードかグループの名前（RPROXY_UI_NODES）',
  protocol      VARCHAR(3)   NOT NULL COMMENT 'tcp / udp（小文字）',
  src_addr      VARCHAR(45)  NOT NULL COMMENT '待ち受け IP アドレス',
  src_port      INT          NOT NULL,
  src_port_end  INT          NULL COMMENT 'ポート範囲の終わり（単一ポートなら NULL）',
  dist_addr     VARCHAR(253) NOT NULL COMMENT '転送先 IP アドレスまたはホスト名',
  dist_port     INT          NOT NULL,
  source_ip     VARCHAR(16)  NOT NULL DEFAULT 'proxy' COMMENT 'proxy / proxy_v1 / proxy_v2 / transparent',
  udp_idle_secs INT          NOT NULL DEFAULT 30,
  options       JSON         NULL COMMENT 'TLS / STARTTLS / allow_from の設定（既定なら NULL）',
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_forward_rules_target_listen (target, protocol, src_addr, src_port),
  KEY idx_forward_rules_auth_id (auth_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS forward_rules_log (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  auth_id       VARCHAR(255) NULL COMMENT '操作した利用者（IdP の sub）',
  target        VARCHAR(32)  NOT NULL DEFAULT 'default',
  node          VARCHAR(32)  NULL COMMENT '送り直したノード（RESEND のときだけ）',
  protocol      VARCHAR(3)   NOT NULL,
  src_addr      VARCHAR(45)  NOT NULL,
  src_port      INT          NOT NULL,
  src_port_end  INT          NULL,
  dist_addr     VARCHAR(253) NOT NULL,
  dist_port     INT          NOT NULL,
  update_action VARCHAR(8)   NOT NULL COMMENT 'ADD / UPDATE / DELETE / RESEND / OVERRIDE',
  updated_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_ip     VARCHAR(16)  NOT NULL DEFAULT 'proxy',
  udp_idle_secs INT          NOT NULL DEFAULT 30,
  options       JSON         NULL,
  PRIMARY KEY (id),
  KEY idx_forward_rules_log_listen (protocol, src_addr, src_port),
  KEY idx_forward_rules_log_auth_id (auth_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ノード → そのノードが読む target（自分の名前と、自分を含むグループ）。UI が RPROXY_UI_NODES に合わせて書き直す
CREATE TABLE IF NOT EXISTS forward_rule_targets (
  node   VARCHAR(32) NOT NULL COMMENT 'ノードの名前',
  target VARCHAR(32) NOT NULL COMMENT 'そのノードが読む target（ノード自身か、ノードを含むグループ）',
  PRIMARY KEY (node, target)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- グループのルールの、ノードごとの上書き（#98）。options は forward_rules.options に JSON_MERGE_PATCH で重ねる差分
CREATE TABLE IF NOT EXISTS forward_rule_overrides (
  rule_id   INT UNSIGNED NOT NULL COMMENT 'forward_rules.id',
  node      VARCHAR(32)  NOT NULL COMMENT 'ノードの名前',
  src_addr  VARCHAR(45)  NULL COMMENT '待ち受けアドレス（上書きしなければ NULL）',
  dist_addr VARCHAR(253) NULL COMMENT '転送先（上書きしなければ NULL。複数の宛先にするときは空文字）',
  dist_port INT          NULL,
  options   JSON         NULL COMMENT 'forward_rules.options に重ねる差分',
  PRIMARY KEY (rule_id, node),
  CONSTRAINT fk_forward_rule_overrides_rule FOREIGN KEY (rule_id) REFERENCES forward_rules (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- rproxy-api が API で作ったルール（rproxy-api v0.4 の #144）。書くのは rproxy だけで、UI は読むだけ（変えるときは rproxy の API）。
-- 列は rproxy-api の docs/DESIGN-v0.4.md 11. と同じ。node は rproxy の RPROXY_NODE_NAME（UI のノードの名前と揃える）
CREATE TABLE IF NOT EXISTS rproxy_rules (
  node        VARCHAR(255) NOT NULL,   -- どの rproxy のルールか（RPROXY_NODE_NAME、既定はホスト名）
  protocol    VARCHAR(3)   NOT NULL,
  listen_addr VARCHAR(45)  NOT NULL,
  listen_port INT UNSIGNED NOT NULL,
  spec        JSON         NOT NULL,   -- POST /rules の本文と同じ形（RuleRequest）
  spec_version INT UNSIGNED NOT NULL DEFAULT 1,
  created_by  VARCHAR(255) NOT NULL,   -- トークンの名前
  created_at  DATETIME(3)  NOT NULL,
  updated_by  VARCHAR(255) NOT NULL,
  updated_at  DATETIME(3)  NOT NULL,
  PRIMARY KEY (node, protocol, listen_addr, listen_port)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- rproxy-api が persist: true のトークンで PUT したルールの組（rproxy-api v0.4.2 の #241。migration 012）。書くのは rproxy だけで、
-- 1 つの組を 1 行（rules は組のルールの配列）。列は rproxy-api の docs/API.md の「ルールの組の保存」と同じ
CREATE TABLE IF NOT EXISTS rproxy_rule_sets (
  node         VARCHAR(255)    NOT NULL,   -- どの rproxy の組か（RPROXY_NODE_NAME、既定はホスト名）
  name         VARCHAR(253)    NOT NULL,   -- 組の名前
  generation   BIGINT UNSIGNED NOT NULL,   -- 呼ぶ側の世代（PUT の本文の generation）
  etag         VARCHAR(64)     NOT NULL,
  owner        VARCHAR(255)    NOT NULL,   -- 組の持ち主のトークンの名前
  rules        JSON            NOT NULL,   -- 組のルール（POST /rules の本文と同じ形の配列）
  spec_version INT UNSIGNED    NOT NULL DEFAULT 1,
  updated_by   VARCHAR(255)    NOT NULL,   -- トークンの名前
  updated_at   DATETIME(3)     NOT NULL,
  PRIMARY KEY (node, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 利用量の集計（UI #101。migration 010）。UI が rproxy の統計の差分を貯める（時刻は UTC）
-- ルール・ノードごとの最後に見た数（差分を取るため。counters_since・started_at が変われば数え直したとみなす）
CREATE TABLE IF NOT EXISTS usage_counters (
  node           VARCHAR(255)    NOT NULL,
  protocol       VARCHAR(3)      NOT NULL,
  listen_addr    VARCHAR(45)     NOT NULL,
  listen_port    INT UNSIGNED    NOT NULL,
  counters_since BIGINT          NULL COMMENT 'rproxy の stats.counters_since（v0.4。Unix 秒）',
  started_at     BIGINT          NULL COMMENT 'rproxy の started_at（counters_since がない古い rproxy で使う）',
  rx_bytes       BIGINT UNSIGNED NOT NULL,
  tx_bytes       BIGINT UNSIGNED NOT NULL,
  connections    BIGINT UNSIGNED NOT NULL COMMENT 'stats.total_connections',
  sampled_at     DATETIME(3)     NOT NULL,
  PRIMARY KEY (node, protocol, listen_addr, listen_port)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1 時間ごとの通信量（hour は UTC の時の始まり）。owner・target・labels・origin はそのときのルールの持ち主と印
-- （持ち主・印が変われば attr の違う別の行。migration 011）
CREATE TABLE IF NOT EXISTS usage_hourly (
  hour        DATETIME        NOT NULL,
  node        VARCHAR(255)    NOT NULL,
  protocol    VARCHAR(3)      NOT NULL,
  listen_addr VARCHAR(45)     NOT NULL,
  listen_port INT UNSIGNED    NOT NULL,
  attr        CHAR(64)        NOT NULL DEFAULT '' COMMENT '持ち主・置き場所・origin・ラベルの SHA-256（migration 011）',
  target      VARCHAR(32)     NULL COMMENT 'UI のノード／グループ（UI のルールのとき）',
  owner       VARCHAR(255)    NULL COMMENT 'UI のルールの持ち主（Keycloak の sub）',
  origin      VARCHAR(16)     NOT NULL COMMENT 'dynamic（UI）・static・api',
  labels      JSON            NULL,
  rx_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  tx_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  connections BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (hour, node, protocol, listen_addr, listen_port, attr),
  KEY usage_hourly_rule (protocol, listen_addr, listen_port, hour),
  KEY usage_hourly_owner (owner, hour)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 1 日ごとの通信量（day は UTC の日付）。月ごとはこの表をまとめる
CREATE TABLE IF NOT EXISTS usage_daily (
  day         DATE            NOT NULL,
  node        VARCHAR(255)    NOT NULL,
  protocol    VARCHAR(3)      NOT NULL,
  listen_addr VARCHAR(45)     NOT NULL,
  listen_port INT UNSIGNED    NOT NULL,
  attr        CHAR(64)        NOT NULL DEFAULT '' COMMENT '持ち主・置き場所・origin・ラベルの SHA-256（migration 011）',
  target      VARCHAR(32)     NULL,
  owner       VARCHAR(255)    NULL,
  origin      VARCHAR(16)     NOT NULL,
  labels      JSON            NULL,
  rx_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  tx_bytes    BIGINT UNSIGNED NOT NULL DEFAULT 0,
  connections BIGINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (day, node, protocol, listen_addr, listen_port, attr),
  KEY usage_daily_rule (protocol, listen_addr, listen_port, day),
  KEY usage_daily_owner (owner, day)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
