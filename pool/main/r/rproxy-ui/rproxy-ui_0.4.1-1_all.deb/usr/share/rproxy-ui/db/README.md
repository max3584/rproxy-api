# データベース（MariaDB）

English: [README.en.md](README.en.md)

UI と rproxy-api が共有するテーブルの定義。

| ファイル | 内容 |
|---|---|
| `schema.sql` | 現在のテーブル定義。新しく環境を作るときはこれだけを流せばよい |
| `migrations/001_initial.sql` | 初期状態（`source_ip` / `udp_idle_secs` 追加前）の定義 |
| `migrations/002_source_ip_udp_idle.sql` | `source_ip`、`udp_idle_secs` 列の追加と `protocol` の小文字化 |
| `migrations/003_auth_id_to_keycloak.sql` | `auth_id` を Auth0 の sub から Keycloak の sub に置き換えるテンプレート（一度だけ手動で実行） |
| `migrations/004_log_auth_id.sql` | `forward_rules_log` に操作した利用者（`auth_id`）の列を追加 |
| `migrations/005_ranges_and_tls.sql` | 両テーブルにポート範囲の終わり（`src_port_end`）と TLS / STARTTLS の設定（`options`）の列を追加 |
| `migrations/006_nodes.sql` | 複数の rproxy（#98）：両テーブルに `target` 列、キーを `(target, protocol, src_addr, src_port)` に、`forward_rule_targets` 表を追加。`RPROXY_UI_NODES` を使わない 1 台の環境では適用しなくても動く |
| `migrations/007_log_node.sql` | 複数の rproxy（#98）：`forward_rules_log` に送り直したノード（`node`）の列を追加。`RPROXY_UI_NODES` を使うときに必要 |
| `migrations/008_overrides.sql` | 複数の rproxy（#98）：グループのルールのノードごとの上書き（`forward_rule_overrides`）。適用したらノードごとのビューを `node-view.mjs` で作り直す |
| `migrations/010_usage.sql` | 利用量の集計（#101）：`usage_counters`（差分を取るための最後に見た数）・`usage_hourly`・`usage_daily`。書くのも読むのも UI だけ。適用しなければ集計しない |
| `migrations/011_usage_attr.sql` | 利用量の行を持ち主・印ごとに分ける（UI v0.4.0 のセキュリティレビュー M1）：`usage_hourly`・`usage_daily` に `attr` 列を足し、主キーに入れる。010 を適用した環境では UI を上げる前に適用する |
| `migrations/009_rproxy_rules.sql` | rproxy-api v0.4 が API で作ったルールを保存する `rproxy_rules`（#76。書くのは rproxy だけ）。複数の rproxy では適用したらノードごとのビューを作り直す |
| `migrations/012_rproxy_rule_sets.sql` | rproxy-api v0.4.2 が `persist: true` のトークンのルールの組を保存する `rproxy_rule_sets`（rproxy-api #241。書くのは rproxy だけ。組ごとに 1 行）。適用しなくても動く（組を保存しないだけ）。複数の rproxy では適用したらノードごとのビューを作り直す |
| `node-view.mjs` | ノードごとのデータベースと `forward_rules` ビュー・読み取りだけの DB ユーザーの SQL を出す（下の「複数の rproxy（ノードごとのビュー）」） |

既存の環境では `002` から順に適用する。`schema.sql` を変えたときは、同じ変更をする migration も追加すること。

```bash
mariadb -h <host> -P <port> -u <admin> -p <database> < db/migrations/002_source_ip_udp_idle.sql
```

## テーブル

- `forward_rules`：転送ルール。`(target, protocol, src_addr, src_port)` で一意（`006` より前は `(protocol, src_addr, src_port)`）。`auth_id` は IdP（Keycloak）の `sub`。
  - `target`：ルールを置くノードかグループの名前（`RPROXY_UI_NODES`。既定 `default`）。`RPROXY_UI_NODES` を使わないときは UI はこの列を読み書きしない（すべて `default`）。
  `protocol` は小文字の `tcp` / `udp`、IPv6 の `src_addr` は圧縮表記（例 `::1`）で保存する。
  - `src_port_end`：ポート範囲の終わり。単一ポートなら NULL。範囲ルールのキーは先頭の `src_port`（範囲の重なりは rproxy が拒否する）。
  - `options`：TLS / STARTTLS / 接続を許可する送信元 / L7 の設定の JSON。形は必ず `{"tls": <TLS>, "starttls": "smtp" | "imap" | "pop3" | null, "starttls_required": bool, "allow_from": [<CIDR>, ...], "http": <L7>, "crowdsec": bool, "targets": [<宛先>, ...], "balance": "round_robin" | "least_conn" | "failover", "health_check": {"interval", "timeout", "port"}, "extra_listen_addrs": [<IP>, ...], "enabled": false}`
    （`<TLS>` は `../rproxy-api/docs/API.md` の「TLS」と同じ。`allow_from` は正規化した CIDR（`10.0.0.5/32` など）で、空なら省く。
    `<L7>` は API.md の「v0.3 の設定」のルールの `http` で、L7 のルールだけに付く（そのルールの `dist_addr` は `''`、`dist_port` は `0`）。rproxy は未知のキーを拒否して読み込むので、ほかのキーを足さないこと。
    `crowdsec`（L4 で CrowdSec の判定に入っている接続元を切る。rproxy-api v0.3.2 から）は true のときだけ付ける。
    `targets`（宛先を複数にしたとき。`<宛先>` は `{"addr", "port", "weight"?, "backup"?}`。rproxy-api v0.3.3 から）は宛先が複数のときだけ付け、
    `balance`（既定の `round_robin` なら省く）と `health_check` も `targets` があるときだけ付ける。そのルールの `dist_addr` は `''`、`dist_port` は `0`
    （rproxy は `targets` と `remote_addr` を一緒に受け付けないため。一覧に出す先頭の宛先は `targets[0]`）。
    `extra_listen_addrs`（同じポートで追加で待ち受ける IP アドレスの配列、最大 16 件。rproxy-api v0.3.3 から）は空なら省く。
    `enabled`（UI での一時停止）は `false` のときだけ書く。rproxy-api v0.3.5 から、rproxy は起動時にこの行を作らない（rproxy の API には送らない項目）。
    v0.4 の `labels`・`limits`・`bandwidth`・`geoip`・`outlier_detection`（rproxy-api の docs/API.md の「v0.4 の設定」と同じ形）は使うときだけ書く（rproxy-api v0.4 から読める）。
    `<TLS>` の `routes[]` は `server_name` か `server_names`（どちらか一方）と、true のときだけ `passthrough` を持つ（rproxy-api v0.3.3 から）。
    passthrough で既定値のまま、STARTTLS なし、allow_from なし、http なし、crowdsec なし、宛先が 1 つのルールは NULL を保存する。列の型は変わらないので、migration は不要。
  - rproxy の固定ルール（`--static-rules` のファイル）はこのテーブルに入らない。
- `forward_rules_log`：追加・変更・削除の履歴。`update_action` は `ADD` / `UPDATE` / `DELETE`、`auth_id` は操作した利用者（`004` より前の行は NULL）。
  各行はその操作のあとのルールの内容（`DELETE` は削除する前の内容）を持つので、UI の「変更の履歴」はこの行から前の版との違いを出し、「この版に戻す」でその内容に戻す（インポート・巻き戻しの操作も同じく記録する）。

- `forward_rule_targets`：ノード → そのノードが読む `target`（ノード自身と、そのノードを含むグループ）。UI が `RPROXY_UI_NODES` の内容に合わせて書き直す（`RPROXY_UI_NODES` があるときだけ）。ノードごとのビューがこれで絞り込む。
- `forward_rule_overrides`：グループのルールの、ノードごとの上書き（`rule_id`・`node` で一意。ルールを消すと一緒に消える）。`src_addr`・`dist_addr`・`dist_port` は上書きするときだけ値を持ち（複数の宛先にするときの `dist_addr` は `''`）、`options` は `forward_rules.options` に `JSON_MERGE_PATCH` で重ねる差分（`allow_from`・`extra_listen_addrs`・`targets`・`balance`・`health_check`・`enabled`。null はキーを消す）。
  `forward_rules_log` にも `target` 列がある。上書きの変更は `update_action` が `OVERRIDE` で、`node` にそのノード、内容はそのノードで動かす内容（巻き戻しはできない）。1 つのノードへの送り直しは `update_action` が `RESEND` で、`node`（007）にそのノードを残す（内容は送ったルール）。

- `rproxy_rules`（009）：rproxy-api v0.4 が、`persist: true` のトークンで API から作った・変えたルールを保存する（`(node, protocol, listen_addr, listen_port)` で一意。`spec` は `POST /rules` の本文と同じ形の JSON、`created_by` / `updated_by` はトークンの名前）。書くのは rproxy だけで、UI は読んで管理者のダッシュボードに「API」のルールとして出す（変えるときは rproxy の API）。
  `node` は rproxy の `RPROXY_NODE_NAME`（既定はホスト名）。複数の rproxy では UI の `RPROXY_UI_NODES` のノードの名前と揃える。rproxy は起動時に自分の `node` の行を UI のテーブルのあとに復元し、同じキーが両方にあれば UI の行を使う。

- `rproxy_rule_sets`（012）：rproxy-api v0.4.2 が、`persist: true` のトークンで `PUT /rulesets/{name}` した組を保存する（`(node, name)` で一意。`rules` は組のルールの配列（各要素は `POST /rules` の本文の形）、`owner` は組の持ち主のトークンの名前、`generation`・`etag` は組の世代）。書くのは rproxy だけ。rproxy は起動時に自分の `node` の行を `rproxy_rules` のあとに戻す。

- `usage_counters`・`usage_hourly`・`usage_daily`（010）：利用量の集計。UI が rproxy の統計を取り、`usage_counters` に最後に見た数（と `counters_since`・`started_at`）、その差を `usage_hourly`（`hour` は UTC の時の始まり）と `usage_daily`（`day` は UTC の日付）に、ルール・ノードごとに足す。各行の `owner`・`target`・`labels`・`origin` はそのときのルールの持ち主と印で、主キーの `attr`（011。それらの SHA-256）が違えば別の行になる（同じ日に持ち主が変わっても、前の分の持ち主を書き換えない）。古い行は UI が消す（`RPROXY_UI_USAGE_HOURLY_DAYS`・`RPROXY_UI_USAGE_DAILY_DAYS`）。

## DB ユーザー

UI 用のユーザーには両テーブルへの読み書き権限を与える。

```sql
CREATE USER 'rproxy_ui'@'10.0.0.%' IDENTIFIED BY '<password>';
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.forward_rules     TO 'rproxy_ui'@'10.0.0.%';
GRANT SELECT, INSERT                 ON rproxy.forward_rules_log TO 'rproxy_ui'@'10.0.0.%';
-- RPROXY_UI_NODES を使うとき
GRANT SELECT, INSERT, DELETE         ON rproxy.forward_rule_targets TO 'rproxy_ui'@'10.0.0.%';
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.forward_rule_overrides TO 'rproxy_ui'@'10.0.0.%';
-- 利用量の集計（010）
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.usage_counters TO 'rproxy_ui'@'10.0.0.%';
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.usage_hourly   TO 'rproxy_ui'@'10.0.0.%';
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.usage_daily    TO 'rproxy_ui'@'10.0.0.%';
-- rproxy-api v0.4 の API のルールを見せるとき（009。UI は読むだけ）
GRANT SELECT                         ON rproxy.rproxy_rules TO 'rproxy_ui'@'10.0.0.%';
GRANT SELECT                         ON rproxy.rproxy_rule_sets TO 'rproxy_ui'@'10.0.0.%';
```

rproxy-api は起動時に `forward_rules` を読むだけなので、読み取り専用のユーザーを使う。
読む列は `protocol`、`src_addr`、`src_port`、`src_port_end`、`dist_addr`、`dist_port`、`source_ip`、`udp_idle_secs`、`options`
（`src_port_end` / `options` がない古いテーブルでも既定値で読み込む）。

```sql
CREATE USER 'rproxy'@'127.0.0.1' IDENTIFIED BY '<password>';
GRANT SELECT ON rproxy.forward_rules TO 'rproxy'@'127.0.0.1';
-- rproxy-api v0.4 で API のルールを保存するとき（009。rproxy の RPROXY_DATABASE_URL のユーザー）
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.rproxy_rules TO 'rproxy'@'127.0.0.1';
GRANT SELECT, INSERT, UPDATE, DELETE ON rproxy.rproxy_rule_sets TO 'rproxy'@'127.0.0.1';
```

（例ではデータベース名を `rproxy` としている。`DB_DATABASE` に合わせて読み替えること。）

## 複数の rproxy（ノードごとのビュー）

`RPROXY_UI_NODES` で複数のノードを使うときは、rproxy ごとにデータベースを分け、その中に `forward_rules` という名前のビューを作る。
ビューは UI のテーブルのうち、そのノードの行と、そのノードを含むグループの行だけを、そのノードの上書き（`forward_rule_overrides`）を重ねて、rproxy が読む列だけで出す（rproxy の `SELECT ... CAST(src_port AS SIGNED) ... FROM forward_rules` はビューにもそのまま通る）。
rproxy の DB ユーザーにはビューの読み取りだけを渡す（ビューは作った人の権限で元のテーブルを読む `SQL SECURITY DEFINER`。作った人のアカウントを消さないこと）。

```bash
node db/node-view.mjs node1 --database rproxy --host 10.0.0.11 --password '<password>' | mariadb -u root -p
```

出る SQL（`--view-database` の既定は `rproxy_node_<ノード名>`、`--user` は `rproxy_<ノード名>`、`--host` は `127.0.0.1`。`--password` がなければ CREATE USER は出さない）:

```sql
CREATE DATABASE IF NOT EXISTS `rproxy_node_node1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE OR REPLACE SQL SECURITY DEFINER VIEW `rproxy_node_node1`.`forward_rules` AS
  SELECT r.`protocol`, COALESCE(o.`src_addr`, r.`src_addr`) AS `src_addr`, r.`src_port`, r.`src_port_end`, COALESCE(o.`dist_addr`, r.`dist_addr`) AS `dist_addr`, COALESCE(o.`dist_port`, r.`dist_port`) AS `dist_port`, r.`source_ip`, r.`udp_idle_secs`, CASE WHEN o.`options` IS NULL THEN r.`options` ELSE JSON_MERGE_PATCH(COALESCE(r.`options`, '{}'), o.`options`) END AS `options`
    FROM `rproxy`.`forward_rules` r
    LEFT JOIN `rproxy`.`forward_rule_overrides` o ON o.`rule_id` = r.`id` AND o.`node` = 'node1'
   WHERE r.`target` IN (SELECT t.`target` FROM `rproxy`.`forward_rule_targets` t WHERE t.`node` = 'node1');
CREATE USER IF NOT EXISTS 'rproxy_node1'@'10.0.0.11' IDENTIFIED BY '<password>';
GRANT SELECT ON `rproxy_node_node1`.`forward_rules` TO 'rproxy_node1'@'10.0.0.11';
CREATE OR REPLACE SQL SECURITY DEFINER VIEW `rproxy_node_node1`.`rproxy_rules` AS
  SELECT `node`, `protocol`, `listen_addr`, `listen_port`, `spec`, `spec_version`, `created_by`, `created_at`, `updated_by`, `updated_at`
    FROM `rproxy`.`rproxy_rules`
   WHERE `node` = 'node1'
  WITH CHECK OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON `rproxy_node_node1`.`rproxy_rules` TO 'rproxy_node1'@'10.0.0.11';
CREATE OR REPLACE SQL SECURITY DEFINER VIEW `rproxy_node_node1`.`rproxy_rule_sets` AS
  SELECT `node`, `name`, `generation`, `etag`, `owner`, `rules`, `spec_version`, `updated_by`, `updated_at`
    FROM `rproxy`.`rproxy_rule_sets`
   WHERE `node` = 'node1'
  WITH CHECK OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON `rproxy_node_node1`.`rproxy_rule_sets` TO 'rproxy_node1'@'10.0.0.11';
```

`rproxy_rules`（009。rproxy-api v0.4 が API のルールを保存する）は、そのノードの行だけを書けるビューにする（`WITH CHECK OPTION` でほかのノードの行は書けない。その rproxy の `RPROXY_NODE_NAME` をノードの名前にする）。009 を適用していなければ `--without-rproxy-rules` で出さない。`rproxy_rule_sets`（012。rproxy-api v0.4.2 がルールの組を保存する）も同じく自分のノードの行だけのビューにする。012 を適用していなければ `--without-rproxy-rule-sets` で出さない（`--without-rproxy-rules` でも出さない）。**012 を適用する前にビューを作り直すときは `--without-rproxy-rule-sets` を付ける**（付けないとない表のビューで止まる）。

その rproxy は `RPROXY_DATABASE_URL=mysql://rproxy_node1:<password>@<DB のホスト>/rproxy_node_node1` にする。
グループの構成を変えても `forward_rule_targets` を UI が直すので、ビューは作り直さなくてよい。ノードを足したときだけ、そのノードの分を流す。

## バックアップ

両テーブルを `mariadb-dump --single-transaction` で取る。取り方・戻す順番（DB ユーザーと migration を含む）・戻した後の確認は rproxy-api の [docs/BACKUP.md](https://github.com/max3584/rproxy-api/blob/master/docs/BACKUP.md)。
