# TCP-UDP-rproxy-ui

[![CI](https://github.com/max3584/TCP-UDP-rproxy-ui/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/max3584/TCP-UDP-rproxy-ui/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/max3584/TCP-UDP-rproxy-ui)](https://github.com/max3584/TCP-UDP-rproxy-ui/releases/latest)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![Node.js](https://img.shields.io/badge/node-%3E%3D22.23.4-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Renovate](https://img.shields.io/badge/renovate-enabled-brightgreen?logo=renovatebot)](https://github.com/max3584/TCP-UDP-rproxy-ui/issues?q=is%3Aissue+is%3Aopen+%22Dependency+Dashboard%22)

English: [README.en.md](README.en.md)

[rproxy-api](https://github.com/max3584/rproxy-api) の転送ルールを管理する Web UI（Next.js、Keycloak かトークンでサインイン、ルールは MariaDB に保存）。
バージョンは rproxy-api と別々に進める（UI が動くのに必要な rproxy-api の最小の版はリリースノートに書く。docs/RELEASING.md）。

## 画面

![ダッシュボード（TCP / UDP の件数と状態、要確認のルール、全ルールの表）](docs/images/dashboard.ja.png)

| ルールの詳細（L7 のルート・統計） | ルールの追加（L7 (HTTP) のタブ） |
|---|---|
| ![ルールの詳細](docs/images/rule-detail.ja.png) | ![ルールの追加](docs/images/rule-new.ja.png) |
| **変更の履歴** | **スマホの幅（375px）とメニュー** |
| ![変更の履歴](docs/images/history.ja.png) | <img src="docs/images/mobile-dashboard.ja.png" width="48%" alt="スマホの幅のダッシュボード"> <img src="docs/images/mobile-menu.ja.png" width="48%" alt="開いたメニュー"> |

中のデータは文書用のサンプル（192.0.2.0/24・198.51.100.0/24・2001:db8::/32・example.com）。撮り直すには `npm run build && npm run screenshots`（`scripts/screenshots/`。API をサンプルのデータに差し替えるので、MariaDB・rproxy-api・Keycloak は要らない）。

## インストール（Debian / Ubuntu）

rproxy-api と同じ apt リポジトリから入れられる（`rproxy-ui`、CPU を問わない 1 つのパッケージ）。
Node.js 22.23.4 以上（24 なら 24.22.1 以上、26 なら 26.12.1 以上。組み込みの Brotli の脆弱性 CVE-2026-111497 の直った版。23・25 は直らない）が要る（Next.js 16 は 20.9、Unix ソケットに使う undici 8 は 22.19.0 から）。古い版で動かすと起動時に警告を出す。Debian 13 の標準の nodejs は 20、Ubuntu 24.04 は 18 で足りないので、先に [NodeSource](https://github.com/nodesource/distributions) の nodejs をメジャー版を指定して入れる（下は 24）。apt の pin で、ディストリの nodejs は選ばれないようにする。

```shell
NODE_MAJOR=24
sudo install -d -m 0755 /etc/apt/keyrings
sudo curl -fsSLo /etc/apt/keyrings/nodesource.asc https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key
echo "deb [signed-by=/etc/apt/keyrings/nodesource.asc] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
  | sudo tee /etc/apt/sources.list.d/nodesource.list
printf 'Package: nodejs\nPin: origin deb.nodesource.com\nPin-Priority: 600\n' \
  | sudo tee /etc/apt/preferences.d/nodejs
sudo apt update && sudo apt install nodejs
node --version      # v24.x.x
apt policy nodejs   # 候補（Candidate）が deb.nodesource.com のものになっていること
```

- Debian 13・Ubuntu 24.04 とも同じ手順（NodeSource の `nodistro` は配布物を問わない）。22 にするなら `NODE_MAJOR=22`（22.23.4 以上）
- `/etc/apt/preferences.d/nodejs` の pin（優先度 600）で、ディストリの nodejs をすでに入れていても `apt install nodejs` が NodeSource のものに置き換え、`apt upgrade` でもディストリの nodejs には戻らない。NodeSource の nodejs は npm を含む（ディストリの `npm` パッケージは要らない）
- `apt upgrade` で上がるのは同じメジャー版の中だけ。メジャー版を変えるときは `NODE_MAJOR` を変えて `nodesource.list` を書き直し、`sudo apt update && sudo apt install nodejs`

そのあと rproxy-ui を入れる。

```shell
sudo curl -fsSLo /usr/share/keyrings/rproxy-archive-keyring.gpg https://max3584.github.io/rproxy-api/rproxy-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/rproxy-archive-keyring.gpg] https://max3584.github.io/rproxy-api stable main" \
  | sudo tee /etc/apt/sources.list.d/rproxy-api.list
sudo apt update && sudo apt install rproxy-ui
```

- 設定は `/etc/rproxy-ui/rproxy-ui.env`（600）。`NEXTAUTH_URL`、`KEYCLOAK_*`（Keycloak なしならトークン。下の「トークンでのサインイン（Keycloak なし）」）、`DB_*` を書いてから `sudo systemctl enable --now rproxy-ui` で起動する（インストールしただけでは起動しない）
- `NEXTAUTH_SECRET` はインストール時に生成する。同じホストに rproxy-api があれば、API の URL と、そのトークンファイル（`RPROXY_API_TOKEN_FILE=/etc/rproxy/tokens`。1 行に 1 トークンの書き方のとき）も入れる
- `rproxy-ui` ユーザーは rproxy-api と共有するグループ `rproxy` に入る（なければインストール時に作る。ユニットの `SupplementaryGroups=rproxy`）。rproxy-api のファイル（`rproxy-api:rproxy` や `root:rproxy` でグループが読めるトークンファイル・証明書・制御 API の Unix ソケット）を、コピーせずにそのまま読める。前の版で `RPROXY_API_TOKEN` にコピーしたトークンはそのまま使う
- 既定の待ち受けは `127.0.0.1:3000`（`HOSTNAME` / `PORT`）。外から見せるときは rproxy の固定ルール（TLS の終端とサーバ名での振り分け、`allow_from`）を前に置く（rproxy-api の README「固定ルールと、ダッシュボードの公開」）
- DB のテーブルは `/usr/share/rproxy-ui/db/schema.sql`（`db/README.md`）で作る（`node /usr/share/rproxy-ui/db/migrate.mjs` でもよい。`db/README.md` の「migrate.mjs」）
- `/usr/lib/rproxy-ui` の `server.js`（Next.js の standalone 出力）を `rproxy-ui` ユーザーで動かす。ログは `journalctl -u rproxy-ui`
- UI と rproxy-api の版は別々に進む（リリースのタグはずれる）。UI には rproxy-api v0.3.5 以降が要る。UI の版と各ノードの rproxy-api の版はサイドバー（狭い幅ではメニュー）の下とダッシュボードの「バージョン」に出る。rproxy-api が古い・版が分からない（v0.3.18 より前は版を返さない）ときはダッシュボードに注意が出る（UI が知らない新しいマイナーのときは知らせるだけ）。起動時にも各ノードの版をログに出す

## Kubernetes

コンテナイメージ `ghcr.io/max3584/rproxy-ui` と Helm chart `oci://ghcr.io/max3584/charts/rproxy-ui`（外の DB か同梱の MariaDB、migration の Job、バックアップ、rproxy-gateway の Gateway の rproxy を読むだけで見る）。手順は [docs/KUBERNETES.md](docs/KUBERNETES.md)。

## 開発

First, run the development server:

```bash
npm ci        # 依存は npm（package-lock.json）で入れる
npm run dev
```

各種必要な情報

+ NEXTAUTH 設定情報
+ Database 設定情報（`DB_PORT` を省略した場合は 3306）
+ Keycloak 設定情報（Confidential クライアント。ロールは realm ロールをアクセストークンの `realm_access.roles` から読む。下の「ロール」）
+ rproxy-api の制御 API の URL とトークン（`RPROXY_API_TOKEN` は rproxy を `--token-file` 付きで起動した場合のみ必要）
  + rproxy のトークンを権限付き（YAML）にする場合、UI のトークンには `rules:read`（一覧・詳細）と `rules:write`（追加・変更・削除）のスコープが要ります。`metrics:read` は使いません（`GET /capabilities` はどのトークンでも読めます）。
    `allow_listen_ports` を付けると、その範囲の外の待ち受けポートのルールは UI から作成・変更・削除できません。
    スコープが足りないと、画面に「UI が使う rproxy のトークンに、この操作の権限がありません」と出ます（UI のログにも残ります）。
    ACME の証明書を使うルールを UI から作成・変更するには、さらに `acme:write` が要ります（下の「ACME で証明書を取る」）。

enviroment:
```.env.local
NEXTAUTH_URL="http://[hostname]:[port]"
NEXTAUTH_SECRET="secret"

# database data
DB_HOST="[hostname]"
DB_PORT=3307
DB_DATABASE="[database]"
DB_USER="[username]"
DB_PASSWORD="[password]"
# DB への接続を TLS にするとき（README の「DB への接続（TLS）」）。DB_SSL_CA を書けば DB_SSL を書かなくても TLS
# DB_SSL=true
# DB_SSL_CA="/etc/rproxy-ui/db-ca.pem"

# Keycloak
KEYCLOAK_CLIENT_ID="[client_id]"
KEYCLOAK_CLIENT_SECRET="[client_secret]"
KEYCLOAK_ISSUER="https://[keycloak-host]/realms/[realm]"
# Keycloak の代わりに（か、一緒に）トークンでサインインするとき（README の「トークンでのサインイン（Keycloak なし）」）
# RPROXY_UI_AUTH="token"                 # keycloak（既定）・token・both
# RPROXY_UI_TOKENS_FILE="/home/me/rproxy-ui-tokens.yaml"   # npm run token:new -- --name me --role admin --file ... で作る

# rproxy
RPROXY_API_URL="http://127.0.0.1:8080"
RPROXY_API_TOKEN="[token]"
# トークンをファイルから読むとき（RPROXY_API_TOKEN が優先。最初の空でない・# でない行。ファイルを書き換えれば次の問い合わせから使う）
# RPROXY_API_TOKEN_FILE="/etc/rproxy/tokens"
# https:// の制御 API にクライアント証明書（mTLS。rproxy-api v0.4 の --tls-client-auth）で接続するとき。CA は rproxy の証明書を確かめる（省略時は OS の CA）
# RPROXY_API_TLS_CERT="/etc/rproxy-ui/tls/client.pem"
# RPROXY_API_TLS_KEY="/etc/rproxy-ui/tls/client.key"
# RPROXY_API_TLS_CA="/etc/rproxy-ui/tls/rproxy-ca.pem"
# 利用量の集計（README の「利用量」。db/migrations/010_usage.sql と 011_usage_attr.sql が要る）：間隔（秒。0 で止める）と残す日数
# RPROXY_UI_USAGE_SECS=300
# RPROXY_UI_USAGE_HOURLY_DAYS=32
# RPROXY_UI_USAGE_DAILY_DAYS=400
# 複数の rproxy（README の「複数の rproxy（ノードとグループ）」）。指定すると RPROXY_API_URL / RPROXY_API_TOKEN は使わない
# RPROXY_UI_NODES="/etc/rproxy-ui/nodes.yaml"
# セッション（README の「セキュリティ」）：サインインからの長さ（秒。既定 8 時間）と、Keycloak でロールを確かめ直す間隔（秒。0 で止める）
# RPROXY_UI_SESSION_MAX_AGE=28800
# RPROXY_UI_ROLE_REFRESH_SECS=300
```

`RPROXY_API_URL` は `http://` / `https://` の URL か、`unix:/run/rproxy/api.sock`（rproxy-api の `RPROXY_API_SOCKET` の Unix ソケット。HTTP の Host は `localhost`）。
Unix ソケットは rproxy-api の既定でモード 660 なので、UI を動かすユーザーを `RPROXY_API_SOCKET_GROUP` のグループに入れておく（トークンは TCP と同じく要る）。

Keycloak のレルムは `keycloak/realm-rproxy-dev.json` から作れる（管理コンソールの「Create realm」→「Resource file」で読み込む）。
このファイルにはクライアントシークレットとユーザーが入っていないので、読み込んだあと、クライアント `rproxy-ui` の「Credentials」でシークレットを確認して `KEYCLOAK_CLIENT_SECRET` に設定する。URL は con0 の開発環境（`http://con0.dev.home:3001`）向け。
このファイルは開発用（パスワードの決まり・OTP なし、http の URI）。本番の土台にするなら [docs/PRODUCTION.md](docs/PRODUCTION.md) の「3. Keycloak」のとおりに直す。

Keycloak クライアントの「Valid redirect URIs」には `${NEXTAUTH_URL}/api/auth/callback/keycloak` を登録してください。

## トークンでのサインイン（Keycloak なし）

Keycloak を置かずに、UI・MariaDB・rproxy だけ（最小構成）で使うときは、管理者が発行するアクセストークンでサインインする（NextAuth の Credentials。#179）。

| `RPROXY_UI_AUTH` | サインイン |
|---|---|
| `keycloak`（既定） | 今までどおり Keycloak だけ（`RPROXY_UI_AUTH` がなく、`KEYCLOAK_ISSUER` がなく `RPROXY_UI_TOKENS_FILE` があれば `token`） |
| `token` | トークンだけ。`KEYCLOAK_*` は要らない |
| `both` | サインインのページ（`/signin`）にトークンの欄と「Keycloak でサインイン」のボタン |

トークンのファイル（`RPROXY_UI_TOKENS_FILE`、YAML）にはトークンの SHA-256 だけを書く（平文のトークンは置かない）。

```yaml
tokens:
  - name: admin            # 英数字で始まる 64 文字までの英数字・. _ -（重ならないこと）
    sha256: 9f86d0...      # トークンの SHA-256（16 進 64 文字）。トークンは rproxy-ui-token で作る（下）
    role: admin            # admin（RPROXY_UI_ADMIN_ROLE）か user（RPROXY_UI_USER_ROLE）
  - name: alice
    sha256: 2c26b4...
    role: user
    sub: 0b6f2c1e-...      # 任意。ルールの持ち主と履歴の auth_id（既定は token:<name>）。Keycloak の sub にすれば同じ人のルールになる
```

- トークンは `rproxy-ui-token` で作る（.deb では `rproxy-ui-token`、リポジトリでは `npm run token -- ...`、イメージでは `node rproxy-ui-token.mjs`）。トークンは 1 回だけ表示し、ファイルには sha256 だけを書く（なければ 0600 で作る。置き換えは rename）。
  ```shell
  sudo rproxy-ui-token new --name admin --role admin --file /etc/rproxy-ui/tokens.yaml --owner rproxy-ui
  sudo rproxy-ui-token list --file /etc/rproxy-ui/tokens.yaml
  sudo rproxy-ui-token remove --name admin --file /etc/rproxy-ui/tokens.yaml
  rproxy-ui-token new --name admin --role admin --stdout    # ファイルに書かずに、トークンと tokens: の行を出す（Kubernetes の Secret）
  ```
- ファイルは UI のユーザーの持ち物で、group・other の権限がないこと（600・400）。Kubernetes の Secret のボリューム（root の持ち物、group は fsGroup、440）のように root の持ち物なら group が読めるのはよい。ほかの持ち主・権限のファイルは読まずに起動を止める（動いている間に変わったときは止めずに、どのトークンも通さない）。中身の誤り（知らない項目・平文の `token:`・重なる name / sha256 など）も同じ。
- ファイルは変わったら読み直す（再起動は要らない）。トークンのセッションは確かめるたびにファイルを見て（`RPROXY_UI_ROLE_REFRESH_SECS` によらない）、行が消えた・sha256 が変わった（入れ替え）・`role` や `sub` が変わったら、次の確認で無効になる（画面はサインインへ、API は 401）。
- `role: user` は `RPROXY_UI_USER_ROLE` のロールになる。`RPROXY_UI_USER_ROLE` が空（既定）なら利用者はいないので、`role: user` のトークンでは使えない（403 `no_role`。起動時に警告）。利用者の制限（`RPROXY_UI_USER_*`）は Keycloak の利用者と同じに効く（`RPROXY_UI_USER_CERTS_BY_SUB` のキーはそのトークンの sub）。
- セッションの長さは Keycloak と同じ `RPROXY_UI_SESSION_MAX_AGE`（サインインから。使い続けても延びない）。クッキーも同じ（httpOnly・SameSite=Lax、`NEXTAUTH_URL` が https:// なら Secure）。トークンそのものはクッキーにもログにも入れない（セッションには行の name と sha256 から作った印だけ）。
- 照合は sha256 をすべての行と一定時間で比べる。同じ送信元から誤ったトークンが 15 分の間に 5 回を超えると、その送信元の誤ったトークンは 15 分間 429（`Retry-After`）になる（`RPROXY_UI_TOKEN_LOCKOUT_ATTEMPTS`・`RPROXY_UI_TOKEN_LOCKOUT_SECS`。既定 5・900 秒）。正しいトークンは締め出し中でも通す（同じ送信元に見えるほかの利用者を、誤りを送り続ける人が締め出せないように）。成功しても誤りの数は戻さない。IPv6 は /64 ごと。数えるのは UI のプロセスごと。HTTP のプロキシ（nginx・Ingress・Gateway）の後ろでは、そのアドレスをできるだけ狭く `RPROXY_UI_TRUSTED_PROXIES`（CIDR をカンマで）に書く（X-Forwarded-For を右から見て、信じるプロキシでない最初のアドレスを送信元にする。広く書くと、その範囲から X-Forwarded-For を偽って送信元を変えられる。書かなければ全員がプロキシの 1 つの送信元として数えられる。そのときに X-Forwarded-For の付いた要求が来ると、ログに 1 回警告を出す）。前の rproxy（L4）は X-Forwarded-For を付けないので要らない。
- 締め出しは誤ったトークンを送る送信元に印を付けてログに出す（429）だけで、正しいトークンを通すので推測の回数を限らず、遅くもしない。守りはトークンの強さだけ。トークンは必ず `rproxy-ui-token` で作る（256 ビットのランダムな値）。自分で作るなら 128 ビット以上のランダムな値（`openssl rand -base64 32` など）にし、パスワードや覚えられる文字列にしない（ファイルの sha256 からは強さを確かめられない）。
- サインインの要求（`POST /api/auth/callback/token`）は NextAuth の CSRF トークンに加えて、ほかのサイトからなら 403（API と同じ `Sec-Fetch-Site`・`Origin` の確認）。サインインのページは CSP（nonce）の下で動く。
- サインアウトは UI のセッションを消すだけ（Keycloak には何も送らない）。

## ロール（権限）

Keycloak のロール（トークンでは `role`）で、だれが何をできるかを決める（API route がリクエストごとに確かめる）。

| ロール | できること |
|---|---|
| `rproxy-admin` | すべての利用者のルールを一覧・詳細・変更・削除できる（一覧と詳細に所有者（Keycloak の ID）を出す）。どの待ち受けポートでも使える |
| `rproxy-user` | 自分のルールだけを作成・一覧・変更・削除できる（ファイルのパスと転送先に制限がある。下の「利用者の制限」）。`RPROXY_UI_USER_ROLE` で利用者のロールを決めたときだけ |
| どちらもない | 画面も API も使えない（403。「権限がありません」と出る）。`RPROXY_UI_USER_ROLE` が空（既定）なら、`rproxy-admin` のない人はすべてこれ |

- ロールはアクセストークンの `realm_access.roles`（realm ロール）から読む。クライアントロールを使うなら `RPROXY_UI_ROLES_CLAIM=resource_access.rproxy-ui.roles` のようにクレームの位置（ドット区切り）を変える。
- ロールの名前は `RPROXY_UI_ADMIN_ROLE`（既定 `rproxy-admin`）と `RPROXY_UI_USER_ROLE`（既定は空）で決める。利用者に使わせるなら `RPROXY_UI_USER_ROLE=rproxy-user` にして、そのロールを付ける。
- **v0.4.9 で既定を変えた**：`RPROXY_UI_USER_ROLE` が空（既定）なら、`rproxy-admin` のない人は使えない（403 `no_role`）。v0.4.8 までは、空ならサインインできる人がだれでも `rproxy-user` と同じ扱いだった。ロールを使わずに利用者に使わせていたなら、上げる前に `RPROXY_UI_USER_ROLE=rproxy-user` にして、利用者にそのロールを付ける。
- `RPROXY_UI_USER_PORTS=1024-65535` のように書くと、`rproxy-user` が使える待ち受けポートを制限できる（範囲の外は 403 `port_not_allowed`。`rproxy-admin` は制限されない）。既定は制限なし。
- 複数の rproxy では `RPROXY_UI_USER_NODES=node1,node2` で `rproxy-user` が触れるノードを絞れる（下の「複数の rproxy（ノードとグループ）」）。
- ロールはサインインしたときに読み、そのあとも `RPROXY_UI_ROLE_REFRESH_SECS`（既定 300 秒）ごとに Keycloak に聞き直す（下の「セキュリティ」）。Keycloak でロールを外すと、遅くともその間隔のあとで反映される。

### 利用者の制限（ファイルのパス・転送先）

`rproxy-user`（`rproxy-admin` でない人）のルールは、API route が次のように確かめる（画面はファイルの欄を読み取り専用にし、注意を出すだけ）。`rproxy-admin` は今までどおり制限されない。

- **サーバのファイルを指す項目は書けない**（403 `file_not_allowed`）：`tls.certificates[]` の `cert_file`・`chain_file`・`key_file`、`tls.client_auth` の `ca_file`・`chain_file`、`tls.upstream` と `tls.routes[].upstream` の `ca_file`・`cert_file`・`chain_file`・`key_file`、L7 のサービスの `tls` のファイル、`basic_auth` の `users_file`、`oidc` の `client_secret_file`・`cookie_secret_file`・`ca_file` など、`*_file` の項目すべて（JSON で書くミドルウェアも同じ）。rproxy は自分が読めるどの鍵でも使えるので、利用者がダッシュボードの鍵で別のポートに TLS を終端すると、管理者の cookie を盗めるため。
- **TLS の証明書は登録済みの名前から選ぶ**：rproxy-api v0.4.2 の証明書の API（`PUT /certs/{name}`。`features.cert_store`）に管理者が登録した証明書を、`tls.certificates[]` の `{"cert": "<名前>"}` で使う。フォームの「＋ 登録済みの証明書を追加」は `/api/forward/certs`（rproxy の `GET /certs`。UI のトークンに `certs:read` が要る。名前・名前の一覧・期限だけ）から選ばせる。`RPROXY_UI_USER_CERTS=tenant-,shared-` のように名前の先頭を書くと、利用者が選べる名前を絞れる（外は 403 `cert_not_allowed`。空（既定）ならすべての名前）。先頭は区切りを見ずに文字の先頭だけで比べるので、`-`・`.`・`_` のどれかで終える（`tenant-a` だと `tenant-ab-www` にも一致するため。ほかの終わり方は起動時に止める。`RPROXY_UI_USER_CERTS_BY_*` の先頭も同じ）。ダッシュボードの証明書を証明書の API に置くなら、必ずこれで外す。`?target=` で聞くノードも `RPROXY_UI_USER_NODES` の内だけ。
  - **利用者・ロールごとの割り当て**（#160）：`RPROXY_UI_USER_CERTS` は利用者みんなで共通なので、tenant-a の利用者が `tenant-b-www` を選び、同じ IP の自分のポートで TLS を終端できてしまう（cookie はポートで分かれない）。テナントを分けるなら、`RPROXY_UI_USER_CERTS_BY_ROLE=tenant-a:tenant-a-,tenant-b:tenant-b-`（Keycloak のロール:先頭）か `RPROXY_UI_USER_CERTS_BY_SUB=<sub>:alice-`（Keycloak の `sub`:先頭）で割り当てる。カンマで区切り、同じロール・`sub` を並べれば先頭を足せる（ロールの名前に `:` があってもよい。最後の `:` の後ろが先頭）。
  - 割り当てのある利用者は、その `sub` とロールに割り当てた先頭を合わせたものだけを選べ、`RPROXY_UI_USER_CERTS` は使わない。どちらかの割り当てを書いたら、割り当てのない利用者は何も選べない（`RPROXY_UI_USER_CERTS` には戻らない）。共通の `RPROXY_UI_USER_CERTS` が効くのは、割り当てをどちらも書かないとき（既定。今までどおり）だけ。
  - 割り当ては `/api/forward/certs` の一覧と、証明書の名前を受け取るすべての経路（追加・変更・差分・インポート・巻き戻し・コピー・移動・ノードごとの上書き）で確かめる。自分のルールに前からある名前は、変えなければそのまま残せる。
- **OIDC のミドルウェアは足せない・変えられない**（403 `middleware_not_allowed`）：rproxy は `issuer` の discovery が返す `token_endpoint`・`jwks_uri` にもつなぐが、UI はその先を確かめられないため。前からある同じ設定はそのまま残せる（秘密のファイルも書けないので、利用者が新しく作ることはもともとできない）。
- **応答のキャッシュ（cache）は上限の内で、共有の設定は使えない**（#175）：rproxy のメモリは利用者みんなで共有なので、利用者の cache の `max_memory` は `RPROXY_UI_USER_CACHE_MAX_MEMORY`（バイト数。`16MiB` のように KiB・MiB・GiB も書ける。既定 16 MiB）まで、`max_entries` は `RPROXY_UI_USER_CACHE_MAX_ENTRIES`（既定 1024）まで（超えると 403 `cache_limit`）。上限は cache のミドルウェアごとで、利用者ごとの合計ではない。書かないと rproxy の既定（`max_memory` 64 MiB・`max_entries` 1024）で比べるので、既定の上限のままなら `max_memory` を書く必要がある（利用者のフォームで新しく足す cache には、上限の値を入れておく）。`share_after_auth`・`share_credentials` は、管理者の置いた認証の後で利用者ごとの答えを共有させうるので使えない（403 `middleware_not_allowed`）。前からある設定は、同じ名前で同じ設定のときだけ残せる。共有の設定は、さらに使うルート（名前・match・転送先の service か to・cache より前のミドルウェアと設定）が増えないときだけ残せ、ほかのルート・名前・ルールへのコピーや移動では使えない。認めたサービスそのものの転送先（servers）を変えるのはよい（管理者はそのサービスで共有することを認めたため）。
- **転送先**（`remote_addr`・`targets`・宛先の死活確認（`health_check.port`）・`tls.routes[]` の宛先・L7 のサービスの `url`・ルートの `to`・`forward_auth` の `address`・`oidc` の `issuer`、ノードごとの上書きの転送先）（403 `target_not_allowed`）：
  - URL は厳しく読む（だれでも）：ホストは名前・IPv4・`[IPv6]`（ゾーン ID は不可）、ポートは 1〜65535 の数字だけ、userinfo（`@`）は不可。読めない URL は保存の前に 400 `invalid`、前から保存してある読めない URL は利用者には 403。
  - `RPROXY_UI_USER_TARGETS=10.0.0.0/8,2001:db8::/32,backend.example.com,*.svc.example.com` のように CIDR・IP アドレス・ホスト名（`*.example.com` は下の名前すべて）を書くと、その中だけ。名前は一致するか、解決したアドレスがすべて CIDR の中のとき使える。既定（空）は許可リストなし（下の断る宛先だけを断る）。本番では書くことを勧める。
  - 既定で断る：ループバック（`127.0.0.0/8`・`::1`）・リンクローカル（`169.254.0.0/16`（クラウドのメタデータ `169.254.169.254` を含む）・`fe80::/10`）・未指定（`0.0.0.0/8`・`::`）・マルチキャスト・ブロードキャスト・`fd00:ec2::254`。許可リストにその範囲の中だけの CIDR（例 `127.0.0.1/32`）を書けば使える（`0.0.0.0/0` のような広い範囲では使えない）。
  - いつも断る（許可リストに書いても）：rproxy の制御 API（`RPROXY_API_URL`・`RPROXY_UI_NODES` の URL と、各 rproxy の `GET /interfaces` の予約済みのアドレス）、この UI（`PORT` と `HOSTNAME`、`NEXTAUTH_URL`）、データベース（`DB_HOST` の解決先と `DB_PORT`）のアドレスとポート。ループバックで待ち受けているものは、そのホストのほかのアドレスも断る。
  - ほかに守るもの（別のホストの DB・レプリカ・管理用のサービスなど）は `RPROXY_UI_PROTECTED_TARGETS=10.0.0.5:3306,10.96.0.0/12,[fd00::/8]:5432` のように CIDR か CIDR:ポートで書く（許可リストに書いても断る）。Kubernetes では DB などの Pod の IP は入れ替わると変わるので、Pod と Service の CIDR を書くか、NetworkPolicy で rproxy からの通信を絞る（`DB_HOST` が Service の名前なら、断るのは Service の IP だけで、Pod の IP へ直接つなぐのは止まらない）。
  - ホスト名は UI のホストで名前解決し、解決したアドレスもすべて確かめる（解決できない名前は断る）。rproxy が後で解決し直したときに向き先が変わる（DNS rebinding）ことまでは防げないので、許可リストの名前は管理者が持つものにする。
  - ノードごとの上書きの転送先は、ルールの転送先と別の置き場所として比べる（前からある値をルールと上書きの間で動かすと新しい値として確かめる）。
- **前からある値はそのまま残せる**：自分のルールの変更では、今のルールにあるファイルのパス・証明書の名前・転送先は、変えなければそのまま保存できる（項目の位置と値の組で比べる。配列の順番やサービス・ミドルウェアの名前を変えても同じ値なら残せる）。新しく書いた値・変えた値だけを断る。インポートの置き換えと巻き戻しは今のルールと比べ、新しく作るルール（追加・インポートの追加・ほかのノードへのコピー・移動）は前の値がないので全部を確かめる。上げる前からある利用者のルールは動いたままなので、管理者は利用者のルールのファイルのパスと転送先を見直す。
- **ほかの人のルールのパスを伏せる**：固定ルール（rproxy の設定ファイルのルール）を利用者に見せるとき（ダッシュボード・詳細）、`*_file` の値・証明書の期限のファイル・誤りの文の中のそのパスを `<hidden>` にする。
- 状態を変える API（`POST /api/forward/*`）は、ほかのサイトからの要求（`Sec-Fetch-Site` が same-origin でない、`Origin`（なければ `Referer`）の host が要求の `Host`・`X-Forwarded-Host`・`NEXTAUTH_URL` のどれとも違う）を 403 `csrf` で断る（SameSite=Lax の cookie に加えた CSRF の対策）。前に置くリバースプロキシは `Host` か `X-Forwarded-Host` を渡すか、`NEXTAUTH_URL` を利用者が開く URL にしておく。
  - `Sec-Fetch-Site` も `Origin`・`Referer` もない要求も 403 `csrf`（v0.4.10 から。今のブラウザは画面からの POST に必ずどれかを付ける）。サインインのクッキーを使ってスクリプトから API を呼ぶなら（文書にした使い方ではない）、`Origin: <NEXTAUTH_URL の origin>` を付ける。keepalived の口（`/api/forward/ha/*`。Bearer のトークン）はこの確認を通らないので、そのまま使える。前に置くリバースプロキシは `Origin`・`Referer`・`Sec-Fetch-*` を落とさない。
- 履歴（`forward_rules_log`）の `auth_id` は操作した利用者（管理者がほかの人のルールを変えたら管理者）。

## セキュリティ

### レスポンスのヘッダ

UI はすべての応答（画面・API・静的なファイル）に次のヘッダを付ける（`proxy.ts`・`components/securityheaders.ts`）。`X-Powered-By` は出さない。

| ヘッダ | 値 |
|---|---|
| `Content-Security-Policy` | `default-src 'self'; script-src 'self' 'nonce-<要求ごと>' 'strict-dynamic'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self' <KEYCLOAK_ISSUER の origin>; frame-ancestors 'none'` |
| `X-Frame-Options` | `DENY` |
| `X-Content-Type-Options` | `nosniff` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `camera=(), microphone=(), geolocation=(), payment=(), usb=()` |
| `Cross-Origin-Opener-Policy` | `same-origin` |
| `Cross-Origin-Resource-Policy` | `same-origin` |
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains`（`NEXTAUTH_URL` が `https://` のときだけ） |

- スクリプトは要求ごとの nonce の付いたものだけが動く（Next.js 16 の本番の HTML には inline の `<script>` があるため `'self'` だけにはできない）。`style-src` の `'unsafe-inline'` は画面の `style` 属性のため。
- `form-action` の Keycloak の origin は `KEYCLOAK_ISSUER` から作る（サインインのフォームが Keycloak へ移るため）。
- `next dev`（開発）では `script-src` に `'unsafe-eval'`、`connect-src` に `ws:`・`wss:` を足す。
- 前に置く rproxy は L4（TCP と TLS の終端）なので HTTP のヘッダを足せない。UI が自分で付けるので、前段でヘッダを足す設定は要らない（HTTP のリバースプロキシを置くなら、同じヘッダを重ねて付けないこと）。

### DB への接続（TLS）

DB が別のホストにあるなら、UI と DB の間を TLS にする（`components/dbtls.ts`。`db/migrate.mjs` も同じ環境変数を読む）。

| 環境変数 | 内容 |
|---|---|
| `DB_SSL` | `true` で TLS を使い、DB の証明書を確かめる（`DB_SSL_CA` がなければ Node.js が持つ公開の CA（Mozilla の一覧）と `NODE_EXTRA_CA_CERTS`。OS の CA の一覧は使わない。名前は `DB_HOST` と比べる）。既定 `false` |
| `DB_SSL_CA` | DB の証明書を確かめる CA（PEM）のファイル。書けば `DB_SSL` を書かなくても TLS を使う（`rproxy-ui` ユーザーが読めること） |
| `DB_SSL_VERIFY` | `false` で証明書を確かめない（試験用。勧めない） |

- 値の誤り・読めない CA は起動時に止める（`journalctl -u rproxy-ui` に理由）。
- MariaDB 側は `require_secure_transport=ON` か、UI のユーザーに `ALTER USER 'rproxy_ui'@'%' REQUIRE SSL` で TLS を強いる。
- 同じホストの MariaDB（`DB_HOST=127.0.0.1`）なら TLS は要らない。

### セッション

- サインインの長さは `RPROXY_UI_SESSION_MAX_AGE`（秒。既定 28800 = 8 時間）。Keycloak で実際に認証した時刻（ID トークンの `auth_time`）から数え、使い続けても延びない。過ぎたらサインインし直す。
  - 認可の要求に `max_age=<RPROXY_UI_SESSION_MAX_AGE>` を付けるので、Keycloak の SSO のセッションが残っていても、認証がそれより古ければ Keycloak がもう一度認証を求める（SSO で黙ってサインインし直して 8 時間を延ばすことはない）。
  - Keycloak のレルムの「SSO Session Max」は `RPROXY_UI_SESSION_MAX_AGE` 以下にしておく（`keycloak/realm-rproxy-dev.json` は 8 時間）。
- `RPROXY_UI_ROLE_REFRESH_SECS`（秒。既定 300。`0` で止める。止めると Keycloak でロールを外す・利用者を無効にしても、セッションが切れるまで（最大 `RPROXY_UI_SESSION_MAX_AGE`）UI には反映されない）ごとに、サインインのときに受け取った refresh token で Keycloak のトークンのエンドポイントに聞き直し、ロールを新しいアクセストークンのものに置き換える。
  - Keycloak が断ったら（利用者を無効にした・SSO のセッションが終わった・管理コンソールでセッションを消した）、UI のセッションもその場で無効になる（画面はサインインへ、API は 401）。
  - 断りとして扱うのは `invalid_grant` と 400・401・403 だけ。Keycloak に届かない・408・429・5xx・404（`KEYCLOAK_ISSUER` の誤り。ログに出す）のときは今のロールのまま使い、1 分おきに聞き直す。最後に確かめてから間隔の 3 回分（既定 15 分）を過ぎたらセッションを無効にする。
  - Keycloak の「SSO Session Idle」（既定 30 分）より長く何もしないと refresh token が切れ、次に開いたときにサインインし直しになる。
- サインアウトでは Keycloak の end_session（`/protocol/openid-connect/logout`）にも refresh token を送り、Keycloak の SSO のセッションも終わらせる。Keycloak に届かないなどで失敗しても UI のサインアウトは済むが、Keycloak の SSO のセッションは残る（UI のログに `Keycloak の SSO のセッションを終わらせられませんでした` と出る。必要なら Keycloak の管理コンソールでセッションを消す）。
- この版より前のセッション（サインインの時刻を持たないもの）は使えず、更新のあとは一度サインインし直す。

## L7（HTTP）のルール

rproxy-api v0.3.1 以降（`GET /capabilities` の `features.http` が true）では、TCP のルールの「基本」タブで「L7（HTTP）で振り分ける」を選ぶと、
「L7 (HTTP)」タブでルート（Traefik と同じ `match` の式。よく使う条件は選んで組み立てられる）・サービス（転送先と重み）・ミドルウェア（リダイレクト、レート制限、CrowdSec など。rproxy が使える種類だけ）・一致しないときの応答を編集できる。
プロファイルの「HTTPS リバースプロキシ（L7）」「HTTP→HTTPS リダイレクト（80 番、L7）」がひな形になる。L4 と L7 の切り替えは作成時だけ（rproxy が PATCH で切り替えられないため）。
「詳細」タブの「CrowdSec の判定で接続元を遮断する（L4）」は、rproxy の設定ファイルに `global.crowdsec` があるときに使える（rproxy-api v0.3.2 以降）。

本番環境の構築（apt、DB のユーザーと権限、Keycloak、HTTPS での公開、更新とバックアップ）は [docs/PRODUCTION.md](docs/PRODUCTION.md)。

テーブル定義とマイグレーションは `db/` にあります（`db/README.md` を参照）。既存の環境では `db/migrations/005_ranges_and_tls.sql`（ポート範囲と TLS の列）を適用してください。
rproxy-api との HTTP API の取り決めは `../rproxy-api/docs/API.md` です。

## Gateway API 向けの L7・TLS の項目

rproxy-api の Gateway API 向けの項目（rproxy-api #237。`GET /capabilities` の `features` で使えると言うものだけ編集できる）も、フォームで作成・編集できます。
使えない rproxy では欄を出さず、すでに値があるルールは読み取り専用の注記で残してそのまま送ります。詳細画面の L7 の表示にも出します。

| 項目 | 場所 | features |
|---|---|---|
| ルートの時間の上限（リクエスト全体・転送先への 1 回） | L7 タブのルート | `http_options` の `route_timeouts` |
| Host の書き換え・CORS・ミラー（百分率か分数） | ミドルウェアの種類（`replace_host`・`cors`・`mirror`） | `middlewares` |
| ミラーが同時に送る写しの上限（`mirror` の `max_in_flight`、1〜10000、既定 64。rproxy-api v0.4.20） | `mirror` の「同時に送る写しの上限」（使えない rproxy では読み取り専用で残して送る） | `http_stream_limits` |
| ヘッダを足す（`headers` の `request` / `response` の `add`） | `headers` の JSON | `http_options` の `headers_add` |
| リダイレクトの状態コード（301・302・303・307・308） | `redirect_scheme`・`redirect_regex` | `http_options` の `redirect_status` |
| 状態コードでの送り直し（`500`・`502-504`） | `retry` | `http_options` の `retry_status` |
| 転送先ごとのミドルウェア（`headers`・`replace_host`・パスの書き換えだけ） | サービスの転送先の行 | `http_options` の `server_middlewares` |
| 固定の状態コードで答える転送先（重みの割合で答える） | サービスの転送先の種類「状態コードで答える」 | `http_options` の `server_status` |
| 転送先との HTTP の版（`http1`・`h2`・`h2c`・`auto`。gRPC は h2 か h2c） | サービス | `services` の `protocol` |
| サービスごとの転送先の TLS（サーバ名・CA・SAN・クライアント証明書・確かめない） | サービス | `services` の `tls` |
| サーバ名ごとの複数の宛先と振り分け方 | TLS タブの「サーバ名ごとの転送先」の「複数の宛先」 | `tls_route_targets` |
| サーバ名ごとの転送先への TLS（`tls.routes[].upstream`。BackendTLSPolicy。rproxy-api v0.4.7） | TLS タブの「サーバ名ごとの転送先」の各行の「転送先への TLS」 | `tls_route_upstream` |

サーバ名ごとの転送先への TLS は、TCP の終端のルールで rproxy が終端する名前（「終端しない」にしていない名前）にだけ指定でき、その名前ではルールの「転送先へ TLS で再暗号化する」の代わりに使います（項目ごとには混ぜません）。「ルールと同じ」（省略）・「この名前は平文」（`{}`。ルールが再暗号化していても、この名前だけ平文）・「この名前だけの設定で再暗号化する」（検証するサーバ名・CA・検証しない・クライアント証明書とその中間 CA・秘密鍵。ルールの欄と同じ）から選びます。詳細画面のサーバ名ごとの転送先にも出ます。rproxy-gateway が作ったルールの値も、保存で消えません。

保存の前に rproxy と同じ規則で確かめます（URL と状態コードはどちらか一方、`h2` は https:// の転送先・`h2c` は http:// の転送先、転送先ごとのミドルウェアの種類、ミラーの送り先のサービス、CORS のオリジン、サービスの TLS の組み合わせ、サーバ名ごとの転送先への TLS を書ける名前とクライアント証明書・秘密鍵・中間 CA の組み合わせなど）。

## 応答のキャッシュ（cache）

rproxy-api の `cache` ミドルウェア（rproxy-api #340。`GET /capabilities` の `features.middlewares` に `cache` があるときだけ）は、L7 タブのミドルウェアの種類「応答のキャッシュ」で作成・編集できます。
GET の応答をメモリに持ち、持つ時間（`ttl`、100ms〜24h。必須）のあいだは転送先へ送らずに答えます。多くのクライアントが同じ JSON を数秒おきに取りに来る構成で、転送先へのリクエストを減らすためのものです。

| 欄 | 項目 | 既定 |
|---|---|---|
| 持つ時間 | `ttl` | （必須） |
| 転送先が落ちたときに古い答えを返す時間 | `stale_on_error` | `0s` |
| 持つ本文の上限（バイト。64 MiB まで） | `max_body` | 1 MiB |
| 持つ答えの数の上限 | `max_entries` | 1024 |
| メモリの上限（バイト） | `max_memory` | 64 MiB |
| キーに入れるリクエストのヘッダ | `vary` | なし |
| 持つ状態コード（200・203・204・300・301・308・404・410） | `status` | `[200]` |
| Cookie・Authorization のあるリクエストも共有する | `share_credentials` | false |
| 認証の後でも答えを共有する | `share_after_auth` | false |
| 結果（HIT・MISS・STALE・BYPASS）を知らせる応答のヘッダ（付けないこともできる。`Connection`・`Content-Length`・`Transfer-Encoding`・`Age`・`Vary`・`Set-Cookie` などは不可） | `header` | `X-Cache` |

保存の前に rproxy と同じ規則で確かめます：ルートで `cache` より後ろに `ip_allow`・`geoip`・`crowdsec`・`basic_auth`・`forward_auth`・`oidc` を置けない（キャッシュから答えると通らない）、前に `basic_auth`・`forward_auth`・`oidc` があれば `share_after_auth` が要る（`oidc` はセッションの Cookie が付くので `share_credentials` も。rproxy は `--check-config` で警告するだけだが、ないとどのリクエストもキャッシュを使わないので UI は保存の前に止める）、1 つのルートに `cache` は 1 つ。
使えない rproxy では種類を選べず、すでにある `cache` の設定は読み取り専用で残します。
詳細画面の「HTTP のリクエスト」に、ヒット・ミス・古い値・対象外の数とキャッシュから答えた割合（ルートごとにはミドルウェアごとの数）を出します。

## 宛先を複数にする

「基本」タブの「宛先を追加」で宛先を複数にでき、振り分け方を選べる（rproxy-api v0.3.3 以降。L4 の TCP / UDP のルール）。

| 振り分け方 | 動き |
|---|---|
| ラウンドロビン | 重みの比率で順番に回す |
| 最少接続 | いまの接続数（UDP はセッション数）÷ 重みが一番小さい宛先へ送る |
| フェイルオーバー | 上から順に、生きている最初の宛先だけを使う（上の宛先が戻ったら新しい接続から戻す） |

- 「予備」にした宛先は、予備でない宛先がすべて落ちたときだけ使う。
- ヘルスチェック（TCP の接続で確かめる。間隔・タイムアウト・ポート）を付けられる。UDP のルールでは確かめる TCP のポートが必須。ヘルスチェックがなくても、接続に失敗した宛先は rproxy がしばらく外す。
- 詳細画面に宛先ごとの状態（稼働 / 停止、接続数）を出す（rproxy が返すとき）。
- L7 のルールでは、サービスの「振り分け方」で同じ 3 つを選べる（フェイルオーバーは転送先の上から順）。
- 宛先ごとの同時接続の上限（`max_connections`。rproxy-api v0.4.19、`features.target_max_connections`）：宛先の行の「上限」（空欄は上限なし）。上限に達した宛先は落ちた宛先と同じく飛ばし、すべての宛先がいっぱいなら新しい接続を断る（「制限で断った接続」に数える）。フェイルオーバーと組むと上から順に上限まで使う。TLS タブのサーバ名ごとの複数の宛先と、L7 のサービスの転送先（同時に処理するリクエストの数。状態コードで答える転送先には付けられない）にも付けられる。ノードごとの上書きの宛先の欄では `max=200` と書く。詳細画面に「接続数 / 上限」（サーバ名ごとの宛先も。L7 は処理中の数）といっぱいの印「上限」（宛先が 1 つでヘルスチェックのないルールは、rproxy が生死を報告しないので状態の欄は「-」）、いっぱいで断っているルール（生きている宛先がすべていっぱい。生きている宛先がなければすべていっぱい。L7 で状態コードで答える転送先のあるサービスは、その転送先が答えるので断らない）はダッシュボードの「要確認」に出る。上限はノードごとなので、グループのルールはノードごとに確かめて断っているノードの名前を出し、詳細の「全体」は接続数の合計と「上限 N・ノードごと」を分けて出す。対応していない rproxy では値を読み取り専用で残して送る。

## IPv4 と IPv6 を同時に待ち受ける

「基本」タブの「追加の待ち受けアドレス」で、同じポート（範囲）をほかのアドレスでも待ち受けられる（rproxy-api v0.3.3 以降。最大 16 件）。
代表の IPv4 と GUA の IPv6 を並べたり、`0.0.0.0` と `::` を一緒に指定したりできる。統計とログは 1 つのルールにまとめる。一覧には「203.0.113.5:443 ほか 1 件（2001:db8::5）」と出す。

## 一部のサーバ名だけ終端せずに流す（SNI の passthrough）

TLS を終端するルール（L7 のルールを含む）の TLS タブ「サーバ名ごとの転送先」で「終端しない」にした名前は、rproxy で TLS を終端せずに、ClientHello ごと転送先へ流す（証明書は転送先のもの。rproxy-api v0.3.3 以降）。
`:443` で cdn・gitlab は rproxy が終端して L7 で振り分け、registry と `**.tenant.example.com` は Kubernetes（cert-manager の証明書）へそのまま流す、といった使い方ができる。

- 1 行にサーバ名をカンマ区切りで複数書ける（rproxy の `server_names`）。
- `*.example.com` は 1 階層だけ、`**.example.com` は何階層でも一致する（`example.com` 自体には一致しない）。複数に一致するときは、完全一致 → `*.` → `**.`（長い方）→ 上の行の順。
- L7 のルールでは「終端しない」の行だけを使える（ほかの名前は L7 のルートで振り分ける）。「どのサーバ名にも一致しない接続」の「切断する」も使えない。
- `allow_from`・CrowdSec・統計は、passthrough の接続にも効く。

## 前段の PROXY protocol を受け取る・名前ごとに送信元 IP の渡し方を変える

rproxy-api v0.4.13 の 2 つの項目（`../rproxy-api/docs/SOURCE-IP.md`）。rproxy が `GET /capabilities` の `features` で使えると言うときだけ編集でき、使えない rproxy では、値があれば読み取り専用で残してそのまま送ります（保存しても消えません）。

| 項目 | 画面 | `features` |
|---|---|---|
| PROXY protocol の受け取り（ルールの `proxy_protocol`） | 「詳細」タブの「PROXY protocol の受け取り」 | `proxy_protocol_in` |
| サーバ名ごとの送信元 IP の渡し方（`tls.routes[].source_ip`） | TLS タブの「サーバ名ごとの転送先」の各行の「送信元 IP」 | `route_source_ip` |

- **PROXY protocol の受け取り**：rproxy の前のロードバランサ・別の rproxy・Kubernetes の Gateway などが PROXY protocol（v1 / v2）のヘッダを付けて送ってくるとき、そのヘッダのアドレスを本当のクライアントとして扱います（`allow_from`・GeoIP・CrowdSec・制限・ログ・`X-Forwarded-For`・転送先への `source_ip` に使う）。TCP のルールだけ。
  - 「ヘッダを信じる前段」（`from`）に、すぐ前の段（TCP の接続元）のアドレスを 1 行に 1 件、CIDR か IP で書きます（最大 64 件。空にはできず、`0.0.0.0/0`・`::/0` は書けません。rproxy と同じ規則で保存の前に確かめます）。ほかの接続元からヘッダで始まる接続は rproxy が断ります。
  - 「ヘッダを必須にする」（`required`、既定でオン）を外すと、前段からのヘッダのない接続も前段のアドレスのまま通します。
  - 詳細画面の「詳細」と、一覧の「PROXY 受信」のバッジに出ます。チェックを外して保存すると rproxy からも外します（`PATCH` の `proxy_protocol: {}`）。
- **サーバ名ごとの送信元 IP の渡し方**：TLS を終端しない名前（sni のルールの名前と、terminate のルールで「終端しない」にした名前。L7 のルールの「終端しない」名前も）にだけ、その名前の転送先への渡し方を `proxy`・`proxy_v1`・`proxy_v2` から選べます（UDP の sni では `proxy_v1` は選べません）。空欄ならルールの送信元 IP の扱い。`transparent` はルールの単位だけです。
  - 例：`:443` の L7 のルールはそのまま L7 で扱い、Kubernetes へそのまま流す `**.tenant.example.com` だけ `proxy_v2` を付ける。
  - ルールの送信元 IP の扱いと違い、作成後も変えられます（接続を切らずに次の接続から）。詳細画面のサーバ名ごとの転送先に「送信元 IP」のバッジで出ます。

## TCP の中継の時間切れ（idle_timeout・half_close_timeout）

rproxy-api v0.4.20（#353）の L4 の TCP のルールの項目（rproxy-api の docs/API.md「中継の時間切れと keepalive」）。「詳細」タブの「TCP の中継の時間切れ」で、rproxy が `GET /capabilities` の `features.tcp_idle_timeout` を返すときだけ編集できます。使えない rproxy では、値があれば読み取り専用で残してそのまま送ります（保存しても消えません）。UDP（アイドルタイムアウトの `udp_idle_secs`）と L7 のルール（rproxy の設定ファイルの `global.http.timeouts`）には出しません。

- 「何も運ばない接続」（`idle_timeout`、既定 `1h`）：どちらの向きにも何も運ばない時間がこれを超えたら、rproxy が両側をリセットして閉じます。
- 「片側が送り終えた後」（`half_close_timeout`、既定 `1m`）：片側が送り終えた（半分閉じた）後、残りの向きが何も運ばない時間がこれを超えたら閉じます。
- `30s`・`10m`・`1h` のように書きます。`0s` は上限なし、ほかは `1s` 以上です（rproxy と同じ規則で保存の前に確かめます）。空欄は既定で、既定と同じ値（`60m` など）は書かずに省きます。
- TCP の keepalive のプローブでは延びないので、長く黙る接続（DB のコネクションプール・SSH・MQTT など）は長めの値か `0s` に、送り終えてから返事を長く待つもの（`nc -N`・バックアップの道具など）は `half_close_timeout` を `0s` か長めの値にします。v0.4.19 までと同じにするには両方を `0s` にします。
- DB の `options` 列にも書くので、rproxy を再起動して UI の DB から戻したルールも同じ値（`0s` を含む）になります（rproxy-api v0.4.20 以上）。空欄に戻して保存すると、rproxy へは既定（`1h`・`1m`）を送ります。
- 詳細画面の「詳細」に出し（省いたものは「既定（1h）」）、変更の履歴に前と後の値、ずれ（複数の rproxy）にも出します。エクスポート・インポートでも残ります。

## UDP をサーバ名で振り分ける（DTLS・QUIC）

UDP のルールでも、TLS タブのモードを「sni」にすると、最初のパケットのサーバ名で転送先を選べます（rproxy v0.3.8 から）。v0.3.18 以降の rproxy は版を返すので、v0.3.8 より古ければ「sni」を選べません（版を返さない古い rproxy では選べますが、v0.3.7 以前なら保存のときに断られるので、その旨を出します）。終端しないので証明書は要りません（転送先が持ちます）。プロファイル「HTTP/3（QUIC）をサーバ名で振り分ける（UDP 443）」「TURN の DTLS をサーバ名で振り分ける（UDP 5349）」から始められます。

- 振り分けられるのは DTLS と QUIC（HTTP/3 など）だけです。IKE（IPsec）・WireGuard・RTP・ゲームなど、パケットにサーバ名が入っていない UDP は「一致しないとき」の扱い（基本の転送先へ送る／捨てる）になります。
- 同じアドレス・ポートで、HTTP/3 を受ける L7 のルール（http3）とは併用できません（フォームで警告します）。
- QUIC の接続の移動（クライアントのアドレスの変化）は追いかけず、ECH の接続は本当のサーバ名を読めません。

## ACME で証明書を取る

rproxy-api v0.3.21 から、rproxy が ACME（Let's Encrypt など）で証明書を取り、期限の前に自分で更新できます（`../rproxy-api/docs/ACME.md`）。
TLS / DTLS タブで「終端」を選び、「＋ ACME の証明書を追加」で resolver と名前（カンマか空白で区切る）を指定します。ファイルの証明書と並べることもできます。

- アカウント・DNS のプロバイダ・resolver・取ってよい名前（`allowed_names`）と秘密（DNS の API キーなど）は、rproxy の設定ファイル（`RPROXY_CONFIG`）の `global.acme` にだけ書きます。
  画面は rproxy の `GET /acme` から resolver の名前・challenge・許可する名前だけを読み（秘密は rproxy も返しません）、選ばせるだけです。アカウントの作成・無効化や今すぐの更新（`POST /acme/...`）は画面にありません（rproxy の Unix ソケットから行います）。
- 選べるのは TCP の終端で、rproxy が ACME に対応し（`GET /capabilities` の `features.acme`）、設定ファイルに `global.acme` があるときだけです。古い rproxy では ACME の証明書を読み取り専用で残し、「この rproxy は ACME に対応していない」と出します。
- 保存する前に、rproxy と同じ規則で名前を確かめます：ワイルドカード（`*.example.com`）は `dns-01` の resolver だけ、名前は resolver のアカウント（と DNS のプロバイダ）の `allowed_names` の内だけ。rproxy が断ったとき（`400 invalid`）も、理由を画面の言葉で出します。
- UI のトークンに `acme:write` のスコープが要ります（ないと rproxy が 403 で断り、画面がそう説明します）。
- 取れるまでは、rproxy が自己署名の仮の証明書（`rproxy ACME placeholder`）を返します。詳細画面の証明書の欄に、状態（取得待ち・有効・更新中・失敗）・期限・更新の予定（CA が更新の窓（ARI）を出していればその窓も）・次の試み・最後の誤りと、仮の証明書を返しているかを出します。
- dns-01 の resolver では、DNS のプロバイダの種類（PowerDNS・汎用の REST・RFC 2136・acme-dns。知らない種類はそのままの名前）と注意を出します（acme-dns は初めての名前で CNAME を作るまで取れません）。秘密を補助プロセス（`rproxy-api acme-helper`）が持っているときはそう出します（秘密そのものは出しません）。
- 取れない・更新に失敗している証明書は、ダッシュボードの「要確認」に出ます（失敗の理由と次の試みの時刻。更新できないまま期限まで 14 日以内なら残りの日数）。一覧には「ACME 失敗」「ACME 取得待ち」のバッジが付きます。
- エクスポート・インポートは ACME の証明書（`{"acme": "<resolver>", "domains": [...]}`）をそのまま書き出し・読み込みます。

## v0.4 のルールの項目（制限・帯域・GeoIP・ラベル）

rproxy-api v0.4 の項目（`../rproxy-api/docs/API.md` の「v0.4 の設定」）は、フォームの「制限・GeoIP」タブで編集します。rproxy が `GET /capabilities` の `features` で使えると言う項目だけを編集でき、使えない rproxy では説明だけを出します（その項目に値があれば読み取り専用で残し、そのまま送ります）。どれも省略でき、接続を切らずに変えられます。

| 項目 | 内容 |
|---|---|
| ラベル（`labels`） | `tenant=act` のような印（16 個まで）。動きには使わず、rproxy のログ・`/metrics` と、UI の利用量の集計に使う |
| L4 の制限（`limits`） | ルール全体と送信元ごとの同時接続数（UDP はセッション数）、送信元ごとの新しい接続の速さ、UDP のデータグラムの速さ。超えた接続は TLS より前に閉じ、統計の「制限で断った接続」に数える |
| 帯域の上限（`bandwidth`） | ルール全体と送信元ごとの上り・下り（`10Mbps` の形）。TCP は待たせ、UDP は超えた分を捨てる |
| GeoIP（`geoip`） | 国（ISO 3166-1 alpha-2）と AS の許可・拒否のリスト。rproxy の設定ファイルの `global.geoip`（MaxMind の mmdb）が要る。L7 のルールではミドルウェアの `geoip` も選べる |
| 受け身のヘルスチェック（`outlier_detection`） | 続けて失敗した転送先をしばらく外す（L4 のルール）。L7 のルールは「L7 (HTTP)」タブのサービスごと |

- 保存の前に、rproxy と同じ規則で値を確かめます（範囲・単位・組み合わせ。最終的な判定は rproxy）。DB の `options` 列にも rproxy の API と同じ形で書くので、rproxy を再起動しても同じ内容に戻ります。
- rproxy が `features.dry_run` を返すときは、追加・変更の画面に「差分を見る」が出ます。保存する前に、ノードごとに rproxy で何が変わるか（作成・変更、接続を切らずに変わるか・待ち受けを作り直すか、項目ごとの前と後）を rproxy の `?dry_run=true` で確かめます（DB も rproxy も変えません）。
- 詳細画面に、設定した項目、制限で断った数、数え始めの時刻（`counters_since`）、宛先ごとの外している状態と回数、rproxy の `conditions`（Gateway API の形の状態）を出します（rproxy が返すとき）。
- 「rproxy の機能と設定」（`/system`）に、ノードごとの rproxy-api の版、v0.4 の機能の印、設定ファイルの `global.performance` で効く項目、設定ファイルの状態を読み取り専用で出します。performance・GeoIP のデータベース・制御 API の守りは rproxy の設定ファイルと引数で変えます（画面からは変えません）。設定ファイルのパスと誤りの中身・バイナリの SHA-256・問い合わせの失敗の理由は管理者だけに出し（利用者には誤り・失敗があることだけ）、`RPROXY_UI_USER_NODES` の利用者には触れるノードだけを出します（ダッシュボードの設定ファイルの注意も同じ）。
- 「global の設定」（`/global`。管理者だけ。`/system` から開く）に、rproxy-api v0.4.19 の `GET /config/global` で、プロセス全体の設定の項目ごとに今の値・出どころ（設定ファイル / 環境変数 / API / 既定）・変え方（すぐ効く / 再起動が要る）を出します。設定ファイル・環境変数に書いた項目は読み取り専用（「設定ファイルで固定」。API の値があっても効かないときはその旨）、起動のときだけ読む項目は表示だけです。書いていない、すぐ効く項目（`udp_max_sessions`・`http.timeouts` など。どれを変えられるかは rproxy が返す `settable`・`unix_only` と、ノードへの道（Unix ソケットか TCP か）で決めます）は、「差分を確かめる」（`?dry_run=true`）で変わる値を見てから「適用する」で `PATCH /config/global` を送ります（「API の値を消す」で既定に戻せます）。複数の rproxy ではノードごとに出し、グループを選ぶと全ノードに送ります（1 台でも断るか答えが時間切れで分からなければ、適用したノードを前の値に戻し、ノードごとの結果（戻したか・戻せなかったか）を出します）。`http.timeouts` の `write_stall`・`upgraded_idle`・`http2_max_streams`（rproxy-api v0.4.20。`http2_max_streams` は時間ではなく 1〜10000 の数で送ります）の欄は、選んだノードのすべてが `features.http_stream_limits` を返すときだけ出します（API の値にあれば、使えない rproxy でも欄に出して丸ごとの置き換えで落としません）。再起動が要る項目（`acme` など）の中身は出しません。rproxy は値を DB の `rproxy_global`（migration 013）に保存し、再起動しても残します。守りに関わる項目（`trusted_proxies`・`access_log`・`crowdsec`。rproxy の `unix_only`）は rproxy の Unix ソケットからだけ受け付けるので、TCP で聞いているノードでは変えられません（変えるときは、UI のそのノードの url を rproxy-api の `RPROXY_API_SOCKET` のソケット（`unix:/…`）にします）。API で入れるアクセスログは、そのノードの rproxy-api の `RPROXY_API_ACCESS_LOG_DIR` のすぐ下のファイルだけです（既定はなく、設定しなければ API では入れられません。rproxy のアクセスログだけのディレクトリにします）。rproxy が起動のときに保存した値を 読めていない間（`loaded: false`。DB に届かない・行が読めない形）は警告を出し、適用できません。UI のトークンに rproxy の `admin` のスコープが要ります。`features.global_api` のない rproxy では項目を出しません。
- 制御 API をクライアント証明書（mTLS）で守るときは、`RPROXY_API_TLS_CERT`・`RPROXY_API_TLS_KEY`（と、rproxy の証明書を確かめる `RPROXY_API_TLS_CA`）、複数の rproxy では `nodes.yaml` の `tls_cert`・`tls_key`・`tls_ca` を書きます（`https://` の URL だけ。トークンファイルのエントリが `client_cert` だけならトークンは要りません）。`RPROXY_API_TLS_*` を `http://`・`unix:` の `RPROXY_API_URL` と一緒に書くと、トークンが平文で流れるので UI は起動しません（問い合わせもしません）。
- UI の認証が続けて失敗して rproxy が UI を一時的に止めた（`429 locked_out`）ときは、トークン・証明書を確かめるように画面とログに出します（止める時間が過ぎると自動で解けます）。

## 使い方

| 画面 | 内容 |
|---|---|
| ダッシュボード（`/`） | rproxy に接続できるか、ルールの件数（固定ルールを含む）、TCP / UDP ごとのカード（稼働中・失敗・未登録・不明のドーナツ、接続数、累計の接続、rx / tx、TLS 失敗、拒否）、TLS の内訳、要確認のルール、全ルールの表（プロトコル・状態・検索で絞り込み。行を選ぶと詳細へ。固定ルールには「固定」、送信元を絞ったルールには「IP 制限」の印）。5 秒ごとに自動更新します（切り替えられます） |
| 新規ルール（`/rules/new`） | 追加フォーム |
| ルールの詳細（`/rules/{tcp\|udp}/{待ち受けアドレス}/{ポート}`） | 設定と稼働状態・統計。「編集」「削除」（固定ルールにはありません） |
| 編集（詳細の URL + `/edit`） | 変更フォーム |
| インポート（`/rules/import`） | YAML / JSON のルールを読み込む（下の「エクスポートとインポート」） |
| 変更の履歴（`/history`） | ルールの追加・変更・削除の履歴と、前の版への巻き戻し（下の「変更の履歴と巻き戻し」）。ルールの詳細画面にも、そのルールの履歴が出ます |
| 利用量（`/usage`） | 月か日ごとの通信量の集計表（所有者・ラベル・ノード・ルールでまとめる）と CSV、通信量の推移（下の「利用量」） |
| rproxy の機能と設定（`/system`） | ノードごとの rproxy-api の版、v0.4 の機能の印、`global.performance` で効く項目、設定ファイルの状態（読み取り専用） |
| global の設定（`/global`） | rproxy の `global` の項目ごとの今の値・出どころ・変え方と、API で変えられる項目の変更（差分を見てから適用。管理者だけ） |

rx はクライアントから転送先へ、tx は転送先からクライアントへのバイト数です（rproxy がルールを開始してからの累計。rproxy を再起動すると 0 に戻ります）。
「拒否」は、接続を許可する送信元（allow_from）の範囲外か、どのサーバ名にも一致しない接続を切断する設定（unmatched: reject）のために切断した接続の数です。

固定ルールは rproxy の起動時のファイル（`RPROXY_STATIC_RULES` / `--static-rules`。`../rproxy-api/docs/API.md` の「固定ルール」）にあるルールで、DB には入りません。
ログインしていればだれにでもダッシュボードと詳細画面に表示されますが、画面からは変更・削除できません（ファイルを書き換えて rproxy を再起動します）。

フォームはタブに分かれています。

| タブ | 内容 |
|---|---|
| 基本 | プロファイル（用途別のひな形）、プロトコル、待ち受けアドレス、ポート（範囲の終わりは任意）、転送先 |
| L7 (HTTP) | ルート・サービス・ミドルウェア・どのルートにも一致しないとき（L7 のルール。TCP で、rproxy が L7 に対応しているとき） |
| TLS / DTLS | passthrough / sni / 終端（UDP では DTLS）、サーバ名ごとの転送先（TLS を終端しない名前は送信元 IP の渡し方、rproxy が終端する名前は転送先への TLS も）と、どのサーバ名にも一致しない接続の扱い（基本の転送先へ送る / 切断する）、証明書、TLS のオプション（最小バージョンと暗号スイート。TCP の終端）、クライアント証明書の検証（mTLS）、ALPN、転送先への再暗号化 |
| メール (STARTTLS) | SMTP / IMAP / POP3 の STARTTLS（TCP で「終端」のときだけ） |
| 制限・GeoIP | ラベル、L4 の制限、帯域の上限、GeoIP、受け身のヘルスチェック（rproxy-api v0.4。上の「v0.4 のルールの項目」） |
| 詳細 | 送信元 IP の扱い（source_ip）、UDP のアイドルタイムアウト、TCP の中継の時間切れ（idle_timeout・half_close_timeout。L4 の TCP）、接続を許可する送信元（allow_from）、PROXY protocol の受け取り（proxy_protocol。TCP） |

- プロファイルは `../rproxy-api/docs/PROFILES.md` の推奨設定をフォームに入れるだけです。アドレスと証明書のパスは環境に合わせて入力してください。
- 証明書・秘密鍵・CA のパスは rproxy-api のサーバ上のパスです。読めないと `tls_config` のエラーになります。
- rproxy-api は、証明書・秘密鍵・CA・秘密（htpasswd など）のファイルを、rproxy-api を動かす OS のユーザー（パッケージでは `rproxy-api`）が持つものだけ読みます（ほかの利用者の鍵のパスを書いて、その身元で接続・待ち受けできないように）。グループ `rproxy` の読み取りは構いませんが、グループとほかの人が書けるファイルと、ほかの人が読める秘密鍵・秘密も断ります（例: `chown rproxy-api:rproxy`、`chmod 0640`。鍵は 0600 か 0640）。持ち主・モードが違うと rproxy が断り、画面はその理由と直し方を出します。
- 証明書は、ファイル（certbot や cert-manager などで取得したもの）か ACME（rproxy-api v0.3.21 から。下の「ACME で証明書を取る」）を指定します。
  ファイルの場合、rproxy はファイルが変わったかを 60 秒ごと（rproxy の `RPROXY_CERT_CHECK_SECS`）に確かめ、更新された証明書を自動で読み直すので、更新のたびにルールを編集する必要はありません。
- 中間 CA（任意）は、サーバ証明書を発行した CA からルートへ向かう順に 1 つの PEM ファイルに並べます（ルートは不要）。順番が違うと rproxy が `tls_config` で拒否します。
  クライアント証明書の検証では、CA ファイルにルート CA（信頼の起点）を、中間 CA にクライアント証明書を発行した中間 CA を指定します。転送先へのクライアント証明書にも中間 CA を指定できます。
- ポート範囲（例 `8000-8001`）は各ポートを転送先ポートから順に転送します。上限は rproxy の `max_range_ports`（既定 20000）。範囲と送信元 IP の扱いは作成後に変更できません（TLS の設定は変更できます）。
- WebRTC のメディアは DTLS を終端すると接続できません。passthrough の範囲ルールにしてください。
- 接続を許可する送信元（allow_from）は 1 行に 1 件、CIDR（`172.16.0.0/16`、`fd00::/8`）か単一の IP を書きます（最大 64 件）。空欄ならすべて許可します。
  範囲外からの TCP 接続は TLS より前に切断し（PROXY protocol を受け取るルールでは、前段からの接続はヘッダのクライアントで判定）、UDP では範囲外の送信元のデータグラムを捨てます。保存すると `10.0.0.5` → `10.0.0.5/32` のように正規化します。
- 「どのサーバ名にも一致しない接続」は、sni（TCP / UDP）か TCP の終端で、サーバ名ごとの転送先があるときだけ選べます。「切断する」にすると、一致しない名前や SNI のない接続を切断します（終端ではハンドシェイクを完了せずに切断）。

## rproxy の API で作ったルール

rproxy の API を直接呼んで作ったルール（CI・スクリプト・Kubernetes のコントローラなど。UI の DB にないもの）は、管理者（`rproxy-admin`）のダッシュボードと詳細画面に「API」のバッジで出ます（#76。利用者には出しません）。

- rproxy-api v0.4 は、`persist: true` のトークンで作ったルールを自分のテーブル `rproxy_rules`（`db/migrations/009_rproxy_rules.sql`。UI の DB）に保存し、`origin: "api"` と作ったトークン・時刻を返します。UI は rproxy の `GET /rules` と `rproxy_rules` を読み、rproxy で動いていない保存済みのルールも「未登録」で出します。保存していないルールは「API（保存なし）」（rproxy を再起動すると消える）。
- 編集・削除は rproxy の API（`PATCH` / `DELETE`）で行います（UI の DB には入れず、UI の履歴にも残りません。一時停止・コピー・送り直しはありません）。保存してあるルール（`origin: "api"`）への変更・削除は、UI のトークンに `persist` がなくても rproxy が `rproxy_rules` に書きます（rproxy はルールの出どころで決める）。rproxy が保存できなかった（応答の `persisted: false`）ときだけ「再起動で前の内容に戻る」と知らせます。rproxy が `features.dry_run` を返すときは「差分を見る」も使えます。
- ルールの組（`ruleset`。Kubernetes のコントローラなどが `PUT /rulesets/{name}` で丸ごと渡すもの）のルールは「組: 名前」のバッジで読み取り専用です（rproxy も個別の変更を `409 owned` で断ります）。
- UI のルールと同じキーを rproxy で API のルール・組のルールが使っている（UI のルールが動いていない）ときは、詳細画面に注意を出します。rproxy は起動時に UI のテーブルを優先するので、どちらかを消すかキーを変えてください。
  その間、UI のルールの変更・再開・送り直し・差分は rproxy に送らずに `409 shadowed` で断り、停止・削除は UI の DB だけを変えます（UI のルールの操作で API のルールを書き換えたり消したりしない）。act / stb の自動の送り直しも、そのキーには送らず「API のルールと重なる」と出すだけです（昇格の判定は止めません）。管理者でない利用者には、そのキーで動いているルールの宛先・統計・状態・作ったトークンの名前・組の名前を見せません。
- 複数の rproxy では、rproxy の `RPROXY_NODE_NAME` を `RPROXY_UI_NODES` のノードの名前に揃えます（`rproxy_rules` の `node` 列）。ノードごとのビュー（`db/node-view.mjs`）は、そのノードの行だけを書ける `rproxy_rules` のビューも作ります。

## ルールの一時停止

ルールの詳細画面の「一時停止」（一覧の行の「一時停止」でも）で、ルールを消さずに止められます。「再開」で同じ内容のまま動かします。

- 止めると、DB にルールを残したまま rproxy から外します（待ち受けが閉じ、既存の接続は切れます）。rproxy を再起動しても、停止中のルールは作りません（rproxy-api v0.3.5 から。DB の `options` の `"enabled": false` を読んで飛ばします）。
- 停止中のルールも編集できます（DB だけを変え、再開のときにその内容で作ります）。削除も DB だけです。
- 一覧・詳細・ダッシュボードでは「停止中」と表示し、集計も分けます。
- 停止・再開は履歴に「変更」として残ります（内容の違いに停止中かどうかが出ます）。
- エクスポートでは停止中のルールに `enabled: false` を付けます（インポートすると停止中のまま戻ります）。この項目は UI のエクスポートの形の中でだけ使えます。
- インポートの「置き換える」と、履歴の巻き戻しでは、今の停止・再開の状態を保ちます（内容だけを変えます）。削除したルールを巻き戻すときは、その版の状態（停止中なら停止中のまま）で作り直します。

## エクスポートとインポート

ダッシュボードの「エクスポート（JSON）」で、自分のルール（`rproxy-admin` はすべての利用者のルール）を JSON で書き出します（UI のバックアップ・移行用）。

```json
{"format": "rproxy-ui-export", "version": 1, "exported_at": "...", "rules": [{"protocol": "tcp", "listen_addr": "0.0.0.0", ...}]}
```

- 各ルールの項目は rproxy の API・設定ファイルと同じ名前（`remote_addr`・`tls`・`http`・`targets`・`proxy_protocol`、`tls.routes[].source_ip` など）。既定値の項目（`source_ip: proxy`、TCP の `udp_idle_secs`、passthrough の `tls` など）は省きます。停止中のルールには `enabled: false` が付きます。
- 先頭の `format` で、rproxy の設定ファイルと区別します。rproxy はこの項目を知らないので、書き出したファイルを `RPROXY_CONFIG` に置いても誤って読み込まず、断ります（設定ファイルに移すときは `rules` の中身を使い、停止中のルールと `enabled` を除いてください）。
- `rproxy-admin` は `/api/forward/export?owner=<利用者の ID>` で、特定の利用者のルールだけを書き出せます。

「インポート」（`/rules/import`）では、UI のエクスポート（JSON）と、rproxy の設定ファイル（YAML / JSON。`version: 1` と `rules:`、またはルールの配列）を読み込みます。設定ファイルで書いていたルールを UI の管理に移すときにも使えます。

1. 「確かめる」で 1 件ずつ、画面から追加するときと同じ検証をして、結果（追加 / 同じキーがある / 誤り）を表で見せます。まだ何も変えません。
2. 同じキー（プロトコル・待ち受けアドレス・ポート）のルールがあるものは、行ごとに「置き換える」を選べます（選ばなければスキップ）。
   ほかの利用者のルールと同じキー、rproxy の固定ルールと同じキー、読み込む内容の中で重なるキーは誤りになります。
3. 「インポートする」で 1 件ずつ追加・置き換えます。途中で失敗しても、成功した分は残ります（行ごとに結果を表示）。

- `global`（CrowdSec・trusted_proxies など）は rproxy 側の設定なので読み飛ばします。
- 置き換えで、送信元 IP の扱い・ポート範囲・L4 / L7 が違うルールは、削除して作り直します（既存の接続は切れます）。
- `RPROXY_UI_USER_PORTS` の制限は、インポートでも同じです。
- 追加・置き換えは、画面からの操作と同じく履歴に残ります。

## 変更の履歴と巻き戻し

「変更の履歴」（`/history`）で、ルールの追加・変更・削除の履歴（いつ・だれが・何を）を見られます。変更には、1 つ前の版からの違い（転送先・TLS のモード・接続を許可する送信元など）を出します。
プロトコル・待ち受けアドレス・ポート・操作・期間（`rproxy-admin` は操作した利用者も）で絞り込めます。ルールの詳細画面にも、そのルールの履歴が出ます。

- 見られる範囲：利用者は、自分が操作した履歴と、今自分が持っているルールの履歴。`rproxy-admin` はすべて。
  - **前の持ち主の版も見える**：履歴の行には持ち主の列がなく、ルールはキー（プロトコル・待ち受けアドレス・ポート・ノードを設定していればノード／グループ）で結ぶ。ほかの人が消したルールと同じキーのルールを作ると、その人が持っていたときの版（操作した人の ID・転送先・登録済みの証明書の名前・ファイルのパス・接続を許可する送信元・ラベルなど。伏せない）も「今自分が持っているルールの履歴」として見え、「この版に戻す」で同じ内容を作れる（利用者の制限は新しい値と同じように確かめる）。利用者の間で見せたくない古い版は、管理者が DB の管理者のユーザーで `forward_rules_log` から消す（例 `DELETE FROM forward_rules_log WHERE protocol = 'tcp' AND src_addr = '0.0.0.0' AND src_port = 8443 AND updated_at < '2026-10-01'`）。
- 「この版に戻す」で、その時点の内容に戻せます。変更・追加の行はその操作のあとの内容に、削除の行は削除する直前の内容に戻します。
  ルールが今もあれば置き換え（送信元 IP の扱い・ポート範囲・L4 / L7 が違う版は作り直し）、削除されていれば作り直します。巻き戻しも履歴に残ります。
- rproxy の固定ルールは DB にないので、履歴にも出ません（同じキーの固定ルールがあるときは巻き戻せません）。
- 履歴は DB の `forward_rules_log` です。列の追加はないので、migration は要りません。

## 利用量（通信量の集計）

rproxy の統計（接続数・rx / tx）は rproxy を再起動すると 0 に戻るので、UI が `RPROXY_UI_USAGE_SECS`（既定 300 秒、0 で止める）ごとに各ノードの `GET /rules` を取り、前に見た数との差を DB に貯めます（#101。`db/migrations/010_usage.sql`。適用しなければ集計しません）。

- 時間ごと（`usage_hourly`、`RPROXY_UI_USAGE_HOURLY_DAYS` 日。既定 32）と日ごと（`usage_daily`、`RPROXY_UI_USAGE_DAILY_DAYS` 日。既定 400）に、ルール・ノードごとに貯め、月ごとは日ごとをまとめます。時刻は UTC の区切りです。古い行は UI が消します。
- rproxy v0.4 の `stats.counters_since`（数え始め）が変わったら数え直したとみなし、今の数を全部足します（引き継ぎ（handoff）では変わらないので続けて数える）。古い rproxy では `started_at` で見分けます。
- 各行に、そのときのルールの所有者（UI のルールを作った利用者）・ノード／グループ・ラベル（`labels`）・出どころ（UI・固定・API）を書きます。所有者・印が変われば（同じ日に別の人が同じキーでルールを作った・管理者が付け替えた・ラベルを変えた）別の行に足し、前の分を新しい所有者の行にしません（`db/migrations/011_usage_attr.sql`）。
- 集計の失敗の理由（ノードの rproxy への接続の失敗など）は管理者だけに出します（利用者には失敗していることだけ）。CSV は、表計算ソフトが式として読む値（先頭の空白のあとの `=`・`+`・`-`・`@`・`|`・`%`、全角の `＝`・`＋`・`－`・`＠` など）の前に `'` を付けます。
- ルールの詳細とダッシュボードに通信量のグラフ（24 時間・7 日・30 日・12 か月。rx と tx を積み上げ、表でも見られる。「簡易」は時間の推移で 24 時間が 1 時間ごと・7 日と 30 日が 1 日ごと・12 か月が 1 か月ごとの合計、「詳細」は期間の合計を待ち受けのポートごとに多い順の縦棒で（上位 20、残りは「その他」。表ではすべて）。ルールの詳細のグラフは時間の推移だけ）、「利用量」（`/usage`）に月か日ごとの集計表（所有者・ラベルのキー・ノード・ルールでまとめる）と CSV。管理者はすべてのルール、利用者は自分のルールだけです。
- UI を複数動かしても、1 回の集計は DB のロックで 1 つの UI だけが行います。

## 複数の rproxy（ノードとグループ）

複数の rproxy（**ノード**）を 1 つの UI で管理できる（#98。今の版はその土台）。同じルールを持つノードのまとまりを**グループ**にする（active / standby もグループの 1 つ。役割の表示は後の版）。
ルールはノードかグループに属し、グループのルールの追加・変更・削除・一時停止・再開・インポート・巻き戻しはグループの全ノードに送る。1 台でも失敗したら、成功したノードの変更も元に戻して DB は変えない（応答の `nodes` にノードごとの結果）。

`RPROXY_UI_NODES` を指定しなければ、今までどおり `RPROXY_API_URL` / `RPROXY_API_TOKEN` の 1 台だけで動く（設定も DB も変えなくてよい。画面も今と同じ）。

```yaml
# /etc/rproxy-ui/nodes.yaml（RPROXY_UI_NODES=/etc/rproxy-ui/nodes.yaml。YAML か JSON）
nodes:
  - name: node1                      # 英小文字・数字・_ の 32 文字まで（ノードとグループで重ならないこと）
    url: http://10.0.0.11:8080       # http(s):// か unix:/run/rproxy/api.sock
    token_file: /etc/rproxy-ui/tokens/node1   # トークンはファイルから読む（DB には置かない）
    # tls_cert: /etc/rproxy-ui/tls/node1.pem  # https:// でクライアント証明書（mTLS）を使うとき（tls_key と両方。tls_ca は rproxy の CA）
    # tls_key: /etc/rproxy-ui/tls/node1.key
  - name: node2
    url: http://10.0.0.12:8080
    token_file: /etc/rproxy-ui/tokens/node2
groups:
  - name: ha
    nodes: [node1, node2]
    mode: active_standby             # single（既定）か active_standby
    vip: 192.0.2.10                  # active_standby の VIP（省略可。配列も可。下の「act / stb の表示」）
    auto_resend: true                # ずれた stb に UI が自動で送り直す（既定 true。#109）
default_target: ha                   # 追加の画面で最初に選ぶもの（省略可。ノードが 1 つなら自動）
```

- ファイルは UI の起動時に確かめ、誤りがあれば理由をログに出して起動しない。変えたら UI を再起動する。トークンファイルは UI を動かすユーザー（.deb では `rproxy-ui`）が読めるようにする。
- ノードが 2 つ以上あると、追加の画面に「ノード／グループ」の選択、一覧と詳細にノード／グループが出る。グループのルールの状態は悪いほう（失敗 > 未登録 > 不明 > 稼働中）、接続数と転送量は合計。
- ダッシュボードとルールの詳細は「全体 / ノードごと」のタブになる（ノードが 1 つならタブは出ない）。ノードのタブはそのノードの状態・接続数・rx / tx・拒否・HTTP のリクエスト数・証明書の期限、「全体」は合計と、ノードごとの値を並べた表（act と stb の通信量を比べる。ダッシュボードではつながるか・ルール数・失敗数・ずれの数も）。
- **ずれ**：各ノードで動いているルール（`GET /rules`）を UI の定義（DB）と比べ、違う項目（転送先・TLS・allow_from など。稼働情報は比べない）を「ずれ」と出す。ルールの詳細のノードのタブの「このノードに送り直す」で、そのノードだけに UI の定義を送る（PATCH で直せない違い（送信元 IP の扱い・ポート範囲・L4 / L7）は作り直す。ノードにないルール（未登録）は作る。停止中なのに動いていれば消す）。ルールの所有者と管理者だけが使え、履歴に「送り直し」（`RESEND`）とノードが残る。
- **act / stb の表示**：active_standby のグループでは、各ノードの `GET /interfaces` に VIP があるノードを act、ないノードを stb と出す。VIP はグループの `vip`、書いていなければルールの待ち受けアドレス（`0.0.0.0`・`::`・ループバック以外のとき）。stb は VIP を持たないので、ルールは普通 `0.0.0.0` で待ち受ける（`ip_nonlocal_bind` なしでは stb が VIP に bind できない）ため、`vip` を書くのがおすすめ。だれも VIP を持っていない・複数のノードが持っているときは警告を出す。
- ダッシュボードの rproxy の設定ファイルの注意は、すべてのノードのものを「ノード名: 」付きでまとめて出す。ノードの一覧に、そのノードに最後に反映した時刻（履歴から）も出す。
- **ノードごとの上書き**：グループのルールでも、ルールの詳細のノードのタブ「このノードだけの設定（上書き）」で、待ち受けアドレス（追加の待ち受けアドレスも）・転送先（1 つか複数の宛先）・接続を許可する送信元を変え、このノードだけ一時停止できる（TLS・L7・送信元 IP の扱い・ポート範囲はグループで同じ）。保存するとそのノードにだけすぐ反映し、履歴に「ノードの上書き」（`OVERRIDE`）とノードが残る。ずれの確認と送り直しは上書きを重ねた内容で比べる。ノードごとのビューも上書きを重ねるので、rproxy を再起動しても同じ内容に戻る。エクスポートに `overrides`（UI のエクスポートだけの項目）として入り、グループに読み込むと戻る。
- **コピー・移動**：ルールの詳細の「コピー・移動」で、ほかのノード／グループに同じルールを作る（移動は元を消す）。ノードが重なる先へのコピーは 409 `target_conflict`、重なる先への移動は元を消してから作る（作れなければ元を戻す）。上書きは先にもあるノードの分だけ引き継ぎ、ノードに置くときはそのノードの上書きをルールの内容にする。履歴は先の追加（移動なら元の削除も）。
- **ノード単位**：ダッシュボードのノードのタブの「すべて一時停止 / すべて再開」で、そのノードのルールをまとめて止める・再開する（そのノードに置いたルールはルールごと、グループのルールはそのノードだけ）。「エクスポート」の横で範囲（ノード／グループ）を選べる。
- **act / stb の昇格の前に揃える**（#109）：stb が act（= DB の定義）とずれたまま昇格しないように、
  - UI が active_standby のグループを `RPROXY_UI_HA_SYNC_SECS`（既定 30 秒、0 で止める）ごとに調べ、ずれ・未登録のルールを自動で送り直す（履歴は「送り直し」、操作者は `system`）。グループに `auto_resend: false` を書くと、ずれの表示だけにする。続けて 3 回失敗したらダッシュボードに注意を出す。UI を複数動かしても、1 回の見回りは DB のロックで 1 つの UI だけが行う。
  - keepalived と組む口（Keycloak のセッションの代わりに `RPROXY_UI_HA_TOKEN_FILE` のトークン（1 行に 1 つ）を `Authorization: Bearer` で送る。設定しなければ 404。Bearer のない要求は 401、ファイルを読めなければ 500 `ha_token_file`（パスと理由は UI のログだけに出す））：`GET /api/forward/ha/ready?node=`（揃っていれば 200、揃っていなければ 503 とその中身）と `POST /api/forward/ha/notify?node=&state=MASTER`（昇格した直後に、そのノードへすぐ送り直す）。
  - スクリプトと設定の例は `contrib/keepalived/`（.deb では `/usr/share/doc/rproxy-ui/examples/keepalived/`）。track_script は 503 のときだけ優先度を下げ、UI に届かないときは何もしない（act が落ちたら、揃っていなくても昇格する）。
  - 画面の「act / stb」（`/ha`。管理者だけ。ダッシュボードのノードの一覧から開く）で、グループの act と、ノードごとに揃っているかを確かめ、「このノードを揃える」で送り直せる。元の act に戻す（failback）手順の案内もここにある。VIP を動かすのは keepalived。
- **ノードに限ったロール**：`RPROXY_UI_USER_NODES=node1,node2` で、`rproxy-user` が触れるノードを絞れる（グループはそのノードがすべて入っているときだけ。外は 403 `node_not_allowed`。追加の画面の選択肢も絞る）。`rproxy-admin` は制限されない。既定は制限なし。
- 同じキー（プロトコル・アドレス・ポート）のルールは、ノードが重ならないノード／グループどうしなら別々に置ける（重なると 409 `target_conflict`）。
- 使う前に DB に `db/migrations/006_nodes.sql`・`007_log_node.sql`（送り直しの履歴のノード）・`008_overrides.sql`（ノードごとの上書き。適用したらノードごとのビューを作り直す）・`009_rproxy_rules.sql`（rproxy-api v0.4 の API のルール）を適用する（`forward_rules` と `forward_rules_log` に `target` 列、`forward_rule_targets` 表）。既存のルールは `default` に属するので、設定ファイルのノードの名前を `default` にするか、`UPDATE forward_rules SET target = 'node1' WHERE target = 'default'` で付け替える。

### rproxy の起動時の復元（ノードごとのビュー）

rproxy は起動時に `forward_rules` を丸ごと読むので、ノードごとにデータベースを分け、その中に「自分のノードと、自分を含むグループの行だけ」の `forward_rules` という名前のビューを作る（rproxy は変えない）。
SQL は `db/node-view.mjs` が出す（.deb では `/usr/share/rproxy-ui/db/node-view.mjs`）。UI のテーブルを読める管理者で流す。

```bash
node db/node-view.mjs node1 --database rproxy --host 10.0.0.11 --password '<password>' | mariadb -u root -p
# node1 の rproxy: RPROXY_DATABASE_URL=mysql://rproxy_node1:<password>@<DB のホスト>/rproxy_node_node1
```

ビューは `forward_rule_targets`（UI が設定ファイルに合わせて書き直す）で絞るので、グループの構成を変えてもビューは作り直さなくてよい（ノードを足したときだけ、そのノードの分を流す）。詳しくは `db/README.md`。

## バックアップと復旧

UI のルールの正は DB の `forward_rules`（履歴は `forward_rules_log`）です。DB に加えて、`/etc/rproxy-ui/rproxy-ui.env`（`NEXTAUTH_SECRET`・`KEYCLOAK_CLIENT_SECRET`・`DB_PASSWORD`・`RPROXY_API_TOKEN`）と rproxy 側の `/etc/rproxy` も取ります。
取り方（`mariadb-dump --single-transaction`、systemd の timer の例）、戻す順番、戻した後の確認（rproxy の `GET /rules` と DB の比べ方）、新しいホストへの移し方、DB が壊れたときに rproxy だけで動かす方法は、rproxy-api の [docs/BACKUP.md](https://github.com/max3584/rproxy-api/blob/master/docs/BACKUP.md) にまとめています。
「エクスポート（JSON）」もルールの控えとして使えます（上の「エクスポートとインポート」）。

## テスト

```bash
npm test
```

テストの一覧と、本物の MariaDB と rproxy-api を使う E2E（`RUN_E2E=1`）の動かし方は `docs/TESTING.md` にあります。
